﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.DAORequest.Bank
{
    public class BankInfoRequest
    {
        public String BankCode { set; get; }
        public List<String> BankCodes { set; get; }
        public String BankName { set; get; }
        public String BankFullName { set; get; }
        public String BankEnglishName { set; get; }
        public Int32? SortNo { set; get; }
        public String BankUrl { set; get; }
        public String BankRemark { set; get; }
        public String BankTel { set; get; }
        public String BankAddress { set; get; }
    }
}
