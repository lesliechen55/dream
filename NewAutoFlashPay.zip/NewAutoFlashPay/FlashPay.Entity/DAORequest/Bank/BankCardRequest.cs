﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.DAORequest.Bank
{
    public class BankCardRequest
    {
        public List<Int32> CompanyIds { set; get; }
        public Int32 NotEnableStatus { set; get; }
    }
}
