﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.DAORequest.User
{
    public class UserRequest
    {
        public List<Int32> UserID { set; get; }
        public String UserName { set; get; }
        public List<Int32> CompanyID { set; get; }
        public SByte NotUserStatus { set; get; }
    }
}