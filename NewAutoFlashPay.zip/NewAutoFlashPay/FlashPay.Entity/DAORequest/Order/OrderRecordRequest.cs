﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.DAORequest.Order
{
    public class OrderRecordRequest
    {
        public Int64? OrderNo { set; get; }
        public String DeliveryNo { set; get; } //快递单号
        //public Int32 CMID { set; get; }
        public List<Int32> CMID { set; get; }  //一个卡商名称，可能对应多个CMID
        public Int32 Status { set; get; }

        public DateTime? OrderDate { set; get; }
        public DateTime? EndOrderDate { set; get; }

        public DateTime? PayDate { set; get; }
        public DateTime? EndPayDate { set; get; }

        public List<Int32> PayUID { set; get; }

        public List<Int32> DepositUID { set; get; }

        public List<Int32> CreateUID { set; get; }

        public Boolean ExactMatch { get; set; }
    }
}