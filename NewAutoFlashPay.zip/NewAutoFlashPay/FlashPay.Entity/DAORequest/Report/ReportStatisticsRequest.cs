﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.DAORequest.Report
{
    public class ReportStatisticsRequest
    {
        public List<Int32> CompanyID { set; get; }
        public List<Int32> BankCardID { set; get; }

        public SByte ReportType { set; get; }

        public DateTime? ReportDate { set; get; }
        public DateTime? EndReportDate { set; get; }
    }
}
