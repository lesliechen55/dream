﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.DAORequest.Company
{
    public class CompanyRequest
    {
        public Int32 CompanyId { set; get; }
        public List<Int32> CompanyIds { set; get; }
        public Int32 CompanyPid { set; get; }
        public String CompanyName { set; get; }
        public SByte CompanyStatus { set; get; }
        public SByte NotCompanyStatus { set; get; }
        public String CompanyTel { set; get; }
        public String CompanyNameEn { set; get; }
        public Boolean ExactMatch { set; get; }
    }
}