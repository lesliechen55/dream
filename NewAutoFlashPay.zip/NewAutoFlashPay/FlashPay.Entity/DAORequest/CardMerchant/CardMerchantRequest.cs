﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.DAORequest.CardMerchant
{
    public class CardMerchantRequest
    {
        public List<Int32> CMID { set; get; }
        public String CMName { get; set; }             //卡商名称
    }
}
