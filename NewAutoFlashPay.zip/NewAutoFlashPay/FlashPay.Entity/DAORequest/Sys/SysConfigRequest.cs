﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.DAORequest.Sys
{
    public class SysConfigRequest
    {
        public String ConfigCode { set; get; }
        public Int32 ConfigValue { set; get; }
        public String ConfigContent { set; get; }
        public List<Int32> CompanyID { set; get; }
        public String Description { set; get; }
    }
}
