﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Entity.Config
{
    /// <summary>
    /// 上传配置
    /// </summary>
    public class UploadConfig
    {
        /// <summary>
        /// 路径
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// 路径
        /// </summary>
        public string SavePath { get; set; }

        /// <summary>
        /// 最大数量
        /// </summary>
        public int Maximum { get; set; }
    }
}
