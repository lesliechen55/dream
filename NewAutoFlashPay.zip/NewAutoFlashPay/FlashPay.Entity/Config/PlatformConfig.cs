﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Config
{
    /// <summary>
    /// 平台配置
    /// </summary>
    public class PlatformConfig
    {
        /// <summary>
        /// 类型(B2B = 1,B2C = 2)
        /// </summary>
        public int Type { get; set; }
    }
}
