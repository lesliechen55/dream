﻿namespace FlashPay.Entity.Enum
{
    /// <summary>
    /// 平台类型
    /// </summary>
    public enum PlatformType
    {
        B2B = 1,
        B2C = 2,
    }

    /// <summary>
    /// 銀行卡狀態
    /// </summary>
    public enum BankCardEnableStatus
    {
        启用 = 1,
        禁用 = 2,
        删除 = 3,
        未授权 = 4
    }
    
    /// <summary>
    /// 用户状态枚举
    /// </summary>
    public enum UserInfoStatus
    {
        禁用 = 2,
        启用 = 1,
        删除 = 3,
    }

    /// <summary>
    /// Google验证枚举
    /// </summary>
    public enum UserInfoLoggedIn
    {
        开起 = 1,
        关闭 = 2
    }

    /// <summary>
    /// 日志来源枚举
    /// </summary>
    public enum SourceStatus
    {
        前台 = 10,
        后台 = 20,
    }

    /// <summary>
    /// 公司状态枚举
    /// </summary>
    public enum CompanyStatus
    {
        开起 =1,
        关闭 =2,
        删除 =3
    }

    /// <summary>
    /// 菜单状态枚举
    /// </summary>
    public enum MenuStatus
    {
        显示 = 1,
        隐藏 = 2
    }

    /// <summary>
    /// 资源类型 菜单（1） 权限（2）
    /// </summary>
    public enum AuthorizeType
    {
        菜单 = 1,
        权限 = 2
    }

    /// <summary>
    /// 角色状态
    /// </summary>
    public enum RoleStatus
    {
        显示 = 1,
        隐藏 = 2
    }

    /// <summary>
    /// 功能权限状态枚举
    /// </summary>
    public enum PermissionStatus
    {
        显示 = 1,
        隐藏 = 2
    }

    /// <summary>
    /// 菜单类型枚举
    /// </summary>
    public enum MenuType
    {
        卡管后台 = 1,
        秒付宝存款 = 2,
        秒付宝付款 = 3
    }

    /// <summary>
    /// 银行卡类型枚举(1.收款卡、2.中转卡、3.付款卡、4.备用卡)
    /// </summary>
    public enum CardType
    {
        收款卡 = 1,
        中转卡 = 2,
        付款卡 = 3,
        备用卡 = 4,
        储备卡=5,
        下发储备卡=6,
        付款储备卡=7,
        作废卡 =99
    }

    /// <summary>
    /// 网盾类型(1.手工、2.自动)
    /// </summary>
    public enum UsbType
    {
        手工 = 1,
        自动 = 2
    }

    /// <summary>
    /// 银行卡使用状态(1.有效、2.冻结)
    /// </summary>
    public enum UsingStatus
    {
        有效 = 1,
        冻结 = 2
    }

    /// <summary>
    /// 跨行转账(1.同行、2.跨行、3.全部)
    /// </summary>
    public enum CrossBankPay
    {
        同行 = 1,
        跨行 = 2,
        全部 = 3,
    }

    /// <summary>
    /// 银行卡启用状态(1.启用、2.禁用、3.删除、4.未授权)
    /// </summary>
    public enum EnableStatus
    {
        有效 = 1,
        禁用 = 2,
        删除 = 3,
        未授权 = 4,
    }

    /// <summary>
    /// 银行卡授权状态
    /// </summary>
    public enum AuthStatus
    {
        已分配公司 = 1,
        未分配公司 = 0
    }

    /// <summary>
    /// 日志类型枚举
    /// </summary>
    public enum LogLevel {
        Success =1,
        Failure =2,
        Error =3
    }

    /// <summary>
    /// 報表类型枚举  
    /// </summary>
    public enum ReportStatisticsType
    {
        存款 = 1,
        付款 = 2
    }

    /// <summary>
    /// 存付类型
    /// </summary>
    public enum PaymentType
    {
        存款 = 1,
        付款 = 2
    }

    /// <summary>
    /// 余额变化状态
    /// </summary>
    public enum AdjustStatus
    {
        收款 = 1,
        付款 = 2
    }

    /// <summary>
    /// 确认状态(未处理 = 1，自动审核通过 = 2，人工审核通过 = 3，人工审核拒绝 = 4)
    /// </summary>
    public enum PaymentRecordConfirmStatus
    {
        未处理 = 1,
        自动审核通过 = 2,
        人工审核通过 = 3,
        人工审核拒绝 = 4
    }

    /// <summary>
    /// 付款状态(未付款 = 1，付款成功 = 2，付款失败 = 3，付款中 = 4，取消付款 = 5)
    /// </summary>
    public enum PaymentRecordPaymentStatus
    {
        未付款 = 1,
        付款成功 = 2,
        付款失败 = 3,
        付款中 = 4,
        取消付款 = 5,
    }

    /// <summary>
    /// 通知状态(未通知 = 1，通知成功 = 2，通知失败 = 3，通知中 = 4)
    /// </summary>
    public enum PaymentRecordNoticeStatus
    {
        未通知 = 1,
        通知成功 = 2,
        通知失败 = 3,
        通知中 = 4
    }

    /// <summary>
    /// 付款记录—交易公司ID
    /// </summary>
    public enum ReceiptTrans
    {
        TranCompanyId = 2
    }

    /// 每天执行
    /// </summary>
    public enum LimitRepeat
    {
        启用 = 1,
        禁用 = 2
    }

    /// <summary>
    /// 转付款
    /// </summary>
    public enum LimitChangetoPay
    {
        启用 = 1,
        禁用 = 2
    }

    /// <summary>
    /// 转收款
    /// </summary>
    public enum LimitChangetoDeposit
    {
        启用 = 1,
        禁用 = 2
    }

    /// <summary>
    /// 状态
    /// </summary>
    public enum LimitStatus
    {
        启用 = 1,
        禁用 = 2
    }

    /// <summary>
    /// 状态
    /// </summary>
    public enum PaymentInterfaceStatus
    {
        启用 = 1,
        禁用 = 2,
        删除=3
    }

    /// <summary>
    /// 授权类型
    /// </summary>
    public enum ExtApiCompatType
    {
        存款 =1,
        付款 = 2,
        虚拟机客户端=3,
        中转=4
    }

    /// <summary>
    /// 授权状态
    /// </summary>
    public enum ExtApiCompatStatus
    {
        启用 = 1,
        停用 = 2
    }

    /// <summary>
    /// 推送类型
    /// </summary>
    public enum ExtApiPushUrlType
    {
        存款主 = 1,
        存款副 = 2,
        付款主 = 3,
        付款副 = 4,
        中转主 = 5,
        中转副 = 6
    }

    /// <summary>
    /// 推送状态
    /// </summary>
    public enum ExtApiPushUrlStatus
    {
        启用 = 1,
        禁用 = 2,
        删除=3
    }

    /// <summary>
    /// 匹配规则
    /// </summary>
    public enum MatchRule
    {
        姓名 = 1,
        金额 = 2,
        卡号 = 3,
        附言 = 4,
    }

    /// <summary>
    /// 收款Or付款
    /// </summary>
    public enum RecordType
    {
        存款 = 1,
        付款 = 2
    }

    /// <summary>
    /// 收款明细
    /// </summary>
    public enum DepositRecordNoticeStatus
    {
        未通知 = 1,
        通知成功 = 2,
        通知失败 = 3,
        通知中 = 4,
    }

    /// <summary>
    /// 使用接口生成中转订单
    /// </summary>
    public enum ApiTransport
    {
        启用 = 1,
        禁用 = 2
    }

    /// <summary>
    /// 转入卡类别
    /// </summary>
    public enum LimitCardType
    {
        收款卡 = 1,
        中转卡 = 2,
        付款卡 = 3,
        储备 = 5,
        下发储备 = 6,
        存储 = 7
    }

    /// <summary>
    /// 报表统计类型
    /// </summary>
    public enum ReportType
    {
        存款 = 1,
        付款 = 2
    }
    
    /// <summary>
    /// 日志类型枚举
    /// </summary>
    public enum LogRecordLogType
    {
        //登陆		
        SysEroor = 0,
        //登陆		
        AccountLoginSuccess = 1,
        AccountLoginFail = 2,

        //用户		
        User_Add = 10,
        User_Update = 11,
        User_Delete = 12,
        User_ResetPwd = 13,
        UserIPRecord_Delete = 14,

        //存款		
        DepositRecord_Add = 20,
        DepositRecord_ResetNotice = 21,

        //付款		
        PaymentRecord_Add = 30,

        PaymentRecord_Audit = 31,
        PaymentRecord_Reject = 32,
        PaymentRecord_ResetAudit = 33,

        PaymentRecord_ResetNotice = 34,

        PaymentRecord_ResetUnpaid = 35,

        PaymentRecord_TurnCancel = 36,
        PaymentRecord_TurnSuccess = 37,
        PaymentRecord_TurnFail = 38,
        PaymentRecord_TurnUnpaid = 39,

        //余额调整		
        AdjustBalance_Add = 40,
        AdjustBalance_Reject = 41,
        AdjustBalance_Complete = 42,

        //模块		
        Permission_Add = 50,
        Permission_Update = 51,
        Permission_Delete = 52,

        //菜单		
        Menu_Add = 55,
        Menu_Update = 56,
        Menu_Delete = 57,

        //角色		
        Role_Add = 60,
        Role_Update = 61,
        Role_Delete = 62,

        //角色权限		
        RolePermission = 70,

        //用户角色		
        UserRole_Add = 80,
        UserRole_Update = 81,
        UserRole_Delete = 82,

        //集团公司		
        GroupCompany_Add = 90,
        GroupCompany_Update = 91,

        //公司		
        BranchCompany_Add = 100,
        BranchCompany_Update = 101,
        BranchCompany_PaymentInterface_Update = 102,
        BranchCompany_DepositInterface_Update = 102,
        BranchCompany_Delete = 103,

        //存付款卡		
        BankCard_Add = 110,
        BankCard_Update = 111,
        BankCard_Delete = 112,
        BankCard_State = 113,

        //库存卡		
        BankCardPare_Add = 114,
        BankCardPare_Update = 115,
        BankCardPare_Delete = 116,
        BankCardPare_State = 117,

        //银行		
        BankInfo_Add = 120,
        BankInfo_Update = 121,
        BankInfo_Delete = 122,

        //系统配置		
        SysConfig_Add = 130,
        SysConfig_Update = 131,
        SysConfig_Delete = 132,

        SysInterface_Update=133,
        SysInterface_Delete = 134,
        SysInterface_UpdateStatus = 135,
        SysInterface_Get = 136,

        //卡订单		
        CardOrder_Add = 150,
        CardOrder_Update = 151,
        CardOrder_Delete = 152,
        CardOrder_DepositConfirm = 153,
        CardOrder_PayConfirm = 154,
        CardOrder_ReceiptConfirm = 155,

        //卡商
        CardMerchant_Add = 160,
        CardMerchant_Update = 161,
        CardMerchant_Delete = 162,

        CardOrder_Child_Add = 170,
        CardOrder_Child_Update = 171,
        CardOrder_Child_Delete = 172,

        //日志
        Log_Add = 180,

        DepositMatchRecord_Set=190,
        DepositMatchRecord_Detail = 191,

        UnknowError = 1000,

        //2000收款人错误		
        WithdrawlAccountNameError = 2000,
        //2001余额不足,		
        PaymentBalanceLess = 2001,
        //2002收款人账号错误,		
        WithdrawlCardNoError = 2002,
        //2003交易失败,		
        PaymentFail = 2003,
        //2004其他失败,		
        PaymentOtherFail = 2004,
        //2005成功		
        PaymentSuccess = 2005
    }
}
