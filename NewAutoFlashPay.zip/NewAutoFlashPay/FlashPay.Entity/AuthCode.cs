﻿namespace FlashPay.Entity
{
    /// <summary>
    /// 权限码
    /// </summary>
    public enum AuthCode
    {
        #region 空授权码
        /// <summary>
        /// 空授权码
        /// 使用此授权码时不进行登录和权限检查
        /// </summary>
        None,

        /// <summary>
        /// 允许修改(弹窗)
        /// </summary>
        AllowEdit,

        /// <summary>
        /// 忽略权限
        /// </summary>
        EmptyCode,
        #endregion

        #region 菜单
        /// <summary>
        /// 菜单管理_查看
        /// </summary>
        Menu0001,

        /// <summary>
        /// 菜单管理_新增
        /// </summary>
        Menu0002,

        /// <summary>
        /// 菜单管理_编辑
        /// </summary>
        Menu0003,

        /// <summary>
        /// 菜单管理_状态
        /// </summary>
        Menu0004,

        /// <summary>
        /// 菜单管理_删除
        /// </summary>
        Menu0005,
        #endregion

        #region 角色
        /// <summary>
        /// 角色管理_查看
        /// </summary>
        Role0001,

        /// <summary>
        /// 角色管理_新增
        /// </summary>
        Role0002,

        /// <summary>
        /// 角色管理_编辑
        /// </summary>
        Role0003,

        /// <summary>
        /// 角色管理_状态
        /// </summary>
        Role0004,

        /// <summary>
        /// 角色管理_删除
        /// </summary>
        Role0005,
        #endregion

        #region 功能权限
        /// <summary>
        /// 权限管理_查看
        /// </summary>
        Permission0001,

        /// <summary>
        /// 权限管理_新增
        /// </summary>
        Permission0002,

        /// <summary>
        /// 权限管理_编辑
        /// </summary>
        Permission0003,

        /// <summary>
        /// 权限管理_状态
        /// </summary>
        Permission0004,

        /// <summary>
        /// 权限管理_删除
        /// </summary>
        Permission0005,
        #endregion

        #region 用户
        /// <summary>
        /// 用户管理_查看
        /// </summary>
        User0001,

        /// <summary>
        /// 用户管理_新增
        /// </summary>
        User0002,

        /// <summary>
        /// 用户管理_编辑
        /// </summary>
        User0003,

        /// <summary>
        /// 用户管理_状态
        /// </summary>
        User0004,

        /// <summary>
        /// 用户管理_密码
        /// </summary>
        User0005,

        /// <summary>
        /// 用户管理_删除
        /// </summary>
        User0006,

        /// <summary>
        /// 用户管理_谷歌验证
        /// </summary>
        User0007,

        /// <summary>
        /// 用户管理_卡管功能
        /// </summary>
        //User0008,

        /// <summary>
        /// 用户管理_收款功能
        /// </summary>
        //User0009,

        /// <summary>
        /// 用户管理_付款功能
        /// </summary>
        //User0010,

        /// <summary>
        /// 用户管理_收付款功能
        /// </summary>
        //User0011,

        /// <summary>
        /// 用户管理_重设密码
        /// </summary>
        User0012,
        #endregion

        #region 日志
        /// <summary>
        /// 日志管理_查看
        /// </summary>
        Log0001,
        #endregion

        #region 卡商管理
        /// <summary>
        /// 卡商管理_查看
        /// </summary>
        CardMerchant0001,

        /// <summary>
        /// 卡商管理_新增
        /// </summary>
        CardMerchant0002,

        /// <summary>
        /// 卡商管理_编辑
        /// </summary>
        CardMerchant0003,

        /// <summary>
        /// 卡商管理_状态
        /// </summary>
        CardMerchant0004,

        /// <summary>
        /// 卡商管理_删除
        /// </summary>
        CardMerchant0005,
        #endregion

        #region 银行卡管理
        /// <summary>
        /// 银行卡管理_查看
        /// </summary>
        BankCard0001,

        /// <summary>
        /// 银行卡管理_新增
        /// </summary>
        BankCard0002,

        /// <summary>
        /// 银行卡管理_编辑
        /// </summary>
        BankCard0003,

        /// <summary>
        /// 银行卡管理_状态
        /// </summary>
        BankCard0004,

        /// <summary>
        /// 银行卡管理_删除
        /// </summary>
        BankCard0005,
        #endregion

        #region 库存卡管理
        /// <summary>
        /// 库存卡管理_查看
        /// </summary>
        BankCardSpare0001,

        /// <summary>
        /// 库存卡管理_新增
        /// </summary>
        BankCardSpare0002,

        /// <summary>
        /// 库存卡管理_编辑
        /// </summary>
        BankCardSpare0003,

        /// <summary>
        /// 库存卡管理_授权
        /// </summary>
        BankCardSpare0004,

        /// <summary>
        /// 库存卡管理_删除
        /// </summary>
        BankCardSpare0005,

        /// <summary>
        /// 全部已完成订单卡（√） （包母公司及子公司已完成订单的卡）
        /// </summary>
        BankCardSpare0006,

        /// <summary>
        /// 全部未完成订单卡（√） （包母公司及子公司未完成订单的卡）【付款审核之前】
        /// </summary>
        BankCardSpare0007,

        /// <summary>
        /// 库存卡管理-作废
        /// </summary>
        BankCardSpare0008,

        /// <summary>
        /// 作废卡管理-查看
        /// </summary>
        BankCardSpare0009,
        #endregion

        #region 公司管理
        /// <summary>
        /// 公司管理_查看
        /// </summary>
        Company0001,

        /// <summary>
        /// 公司管理_新增
        /// </summary>
        Company0002,

        /// <summary>
        /// 公司管理_编辑
        /// </summary>
        Company0003,

        /// <summary>
        /// 公司管理_状态
        /// </summary>
        Company0004,

        /// <summary>
        /// 修改公司功能类型
        /// </summary>
        //Company0005,

        /// <summary>
        /// 公司管理_删除
        /// </summary>
        Company0006,
        #endregion

        #region 公司接口授权
        /// <summary>
        /// 公司推送接口列表查看(存款)
        /// </summary>
        GetExtApi001,

        /// <summary>
        /// 公司推送接口列表查看(付款)
        /// </summary>
        GetExtApi002,

        /// <summary>
        /// 生成(存款)ApiKey和SecretKey
        /// </summary>
        GetExtApi003,

        /// <summary>
        /// 生成(付款)ApiKey和SecretKey
        /// </summary>
        GetExtApi004,

        /// <summary>
        /// 公司推送接口列表查看(中转)
        /// </summary>
        GetExtApi005,

        /// <summary>
        /// 生成(中转)ApiKey和SecretKey
        /// </summary>
        GetExtApi006,
        #endregion

        #region 推送地址
        /// <summary>
        /// 推送地址列表查看
        /// </summary>
        //PushAddressList0001,

        /// <summary>
        /// 推送地址编辑
        /// </summary>
        //PushAddressList0002,

        /// <summary>
        /// 删除推送地址
        /// </summary>
        //PushAddressList0004,
        #endregion

        #region 订单管理
        /// <summary>
        /// 订单管理_查看(舍弃)
        /// </summary>
        //Order0001,

        /// <summary>
        /// 订单管理_新增
        /// </summary>
        Order0002,

        /// <summary>
        /// 订单管理_编辑
        /// </summary>
        Order0003,

        /// <summary>
        /// 订单管理_编辑_收货日期
        /// </summary>
        Order0004,

        /// <summary>
        /// 订单管理_编辑_付款日期
        /// </summary>
        Order0005,

        /// <summary>
        /// 订单管理_状态
        /// </summary>
        Order0006,

        /// <summary>
        /// 订单管理_押金审核_查看金额
        /// </summary>
        Order0007,

        /// <summary>
        /// 订单管理_付款审核_查看金额
        /// </summary>
        Order0008,

        /// <summary>
        /// 订单管理_删除
        /// </summary>
        Order0009,

        /// <summary>
        /// 订单管理_确认收货
        /// </summary>
        Order0010,

        /// <summary>
        /// 订单管理_查看_押金收款卡号
        /// </summary>
        Order0011,

        /// <summary>
        /// 订单管理_查看_尾款收款卡号
        /// </summary>
        Order0012,

        /// <summary>
        /// 是否可以查看押金金额(舍弃)
        /// </summary>
        //Order0013,

        /// <summary>
        /// 是否可以查看付款金额(舍弃)
        /// </summary>
        //Order0014,

        /// <summary>
        /// 订单管理_查看_已完成订单
        /// </summary>
        Order0015,

        /// <summary>
        /// 订单管理_查看_未完成订单
        /// </summary>
        Order0016,

        /// <summary>
        /// 订单管理_查看_全部订单
        /// </summary>
        Order0017,
        #endregion

        #region 子订单管理
        /// <summary>
        /// 子订单管理_查看
        /// </summary>
        OrderDetail0001,

        /// <summary>
        /// 子订单管理_新增
        /// </summary>
        OrderDetail0002,

        /// <summary>
        /// 子订单管理_编辑
        /// </summary>
        OrderDetail0003,

        /// <summary>
        /// 子订单管理_删除
        /// </summary>
        OrderDetail0004,

        /// <summary>
        /// 子订单管理_编编_实际单价数量
        /// </summary>
        OrderDetail0005,
        #endregion

        #region 系统配置(SysConfig)

        /// <summary>
        /// 系统配置_查看
        /// </summary>
        SysConfig0001,

        /// <summary>
        /// 系统配置_新增
        /// </summary>
        SysConfig0002,

        /// <summary>
        /// 系统配置_编辑
        /// </summary>
        SysConfig0003,

        /// <summary>
        /// 系统配置_删除
        /// </summary>
        SysConfig0004,

        #endregion

        #region 收款卡管理
        /// <summary>
        /// 收款卡管理_查看
        /// </summary>
        ReceiptCard0001,

        /// <summary>
        /// 收款卡_机器位置_显示
        /// </summary>
        ReceiptCard0002,
        #endregion

        #region 收款记录
        /// <summary>
        /// 收款记录_查看
        /// </summary>
        ReceiptRecord0001,

        /// <summary>
        /// 收款记录_通知_重置
        /// </summary>
        ReceiptRecord0002,
        #endregion

        #region 收款卡余额变化
        /// <summary>
        /// 收款卡余额变化_查看
        /// </summary>
        ReceiptBalance0001,
        #endregion

        #region 未入账付款记录
        /// <summary>
        /// 未入账付款记录_查看
        /// </summary>
        ReceiptAccounted0001,
        /// <summary>
        /// 未入账付款记录_补单
        /// </summary>
        ReceiptAccounted0002,
        #endregion

        #region 付款卡管理
        /// <summary>
        /// 付款卡管理_查看
        /// </summary>
        PaymentCard0001,
        /// <summary>
        /// 付款卡管理_编辑
        /// </summary>
        PaymentCard0002,
        /// <summary>
        /// 付款卡管理_状态
        /// </summary>
        PaymentCard0003,
        /// <summary>
        /// 付款卡管理_机器位置_显示
        /// </summary>
        PaymentCard0004,
        #endregion

        #region 付款记录
        /// <summary>
        /// 付款记录_查看
        /// </summary>
        PaymentRecord0001,

        /// <summary>
        /// 付款记录_付款_新增
        /// </summary>
        PaymentRecord0002,

        /// <summary>
        /// 付款记录_通知_重置
        /// </summary>
        PaymentRecord0003,

        /// <summary>
        /// 付款记录_付款_取消
        /// </summary>
        PaymentRecord0004,

        /// <summary>
        /// 付款记录_匹配_查看
        /// </summary>
        PaymentRecord0005,

        /// <summary>
        /// 付款记录_付款结果_编辑
        /// </summary>
        PaymentRecord0006,

        /// <summary>
        /// 付款记录转失败
        /// </summary>
        //PaymentRecord0007,

        /// <summary>
        /// 付款记录_付款_审核
        /// </summary>
        PaymentRecord0008,
        #endregion

        #region 实际付款记录
        /// <summary>
        /// 已实际付款记录_查看
        /// </summary>
        RecordReal0001,
        #endregion

        #region 付款卡余额变化表
        /// <summary>
        /// 付款卡余额变化表_查看
        /// </summary>
        PaymentAdjustBalance0001,
        #endregion

        #region 银行管理
        /// <summary>
        /// 银行管理_查看
        /// </summary>
        Bank0001,

        /// <summary>
        /// 银行管理_新增
        /// </summary>
        Bank0002,

        /// <summary>
        /// 银行管理_编辑
        /// </summary>
        Bank0003,

        /// <summary>
        /// 银行管理_删除
        /// </summary>
        Bank0004,
        #endregion

        #region 报表管理
        /// <summary>
        /// 公司年报表_查看
        /// </summary>
        CompanyYear0001,

        /// <summary>
        /// 公司月报表_查看
        /// </summary>
        CompanyMonth0001,
        /// <summary>
        /// 公司银行卡报表_查看
        /// </summary>
        CompanyBankCard0001,
        #endregion

        #region 第三方接口

        /// <summary>
        /// 第三方接口_查看
        /// </summary>
        PaymentInterface0001,

        /// <summary>
        /// 第三方接口_修改
        /// </summary>
        PaymentInterface0002,

        /// <summary>
        /// 第三方接口_删除
        /// </summary>
        PaymentInterface0003,

        /// <summary>
        /// 第三方接口_状态
        /// </summary>
        PaymentInterface0004,

        #endregion

        #region 中转卡管理
        /// <summary>
        /// 中转卡管理_查看
        /// </summary>
        TransferCard0001,
        /// <summary>
        /// 中转卡管理_状态
        /// </summary>
        TransferCard0002,
        #endregion

        #region 中转记录
        /// <summary>
        /// 中转记录_查看
        /// </summary>
        TransferCardRecord0001,
        #endregion

        #region 收款匹配规则
        /// <summary>
        /// 收款匹配规则_查看
        /// </summary>
        DepositMatchRule001,
        /// <summary>
        /// 收款匹配规则_新增
        /// </summary>
        DepositMatchRule002,
        /// <summary>
        /// 收款匹配规则_编辑
        /// </summary>
        DepositMatchRule003,
        /// <summary>
        /// 收款匹配规则_删除
        /// </summary>
        DepositMatchRule004,
        #endregion

        #region 收款匹配记录
        /// <summary>
        /// 收款匹配记录_查看
        /// </summary>
        ReceiptMatchList001,

        /// <summary>
        /// 新增收款匹配记录
        /// </summary>
        //ReceiptMatchList002,

        /// <summary>
        /// 修改收款匹配记录
        /// </summary>
        //ReceiptMatchList003,

        /// <summary>
        /// 删除收款匹配记录
        /// </summary>
        //ReceiptMatchList004,

        /// <summary>
        /// 收款匹配记录_匹配_查看
        /// </summary>
        ReceiptMatchList005,

        /// <summary>
        /// 收款匹配记录列表_补推送
        /// </summary>
        ReceiptMatchList006,
        #endregion
    }
}
