﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 查询参数
    /// </summary>
    public class MenuPermissionQuery : Condition
    {
        public int NodeType { get; set; }

        public string pName { get; set; }
    }
}
