﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 订单明细查询
    /// </summary>
    public class OrderRecordDetailQuery : Condition
    {
        /// <summary>
        /// 系统编号
        /// </summary>
        public int DetailId { get; set; }

        /// <summary>
        /// 系统编号
        /// </summary>
        //不等于
        public int? NoEqualDetailId { get; set; }

        /// <summary>
        /// 订单编号
        /// </summary>
        public long OrderNo { get; set; }

        /// <summary>
        /// 银行编码
        /// </summary>
        public string BankCode { get; set; }

        /// <summary>
        /// 当前用户编号
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// 用户权限
        /// </summary>
        public List<String> userPermission { get; set; }
    }
}
