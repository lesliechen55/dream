﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
   public class BankCardTypeRecordQuery
    {
        public int Id { get; set; }
        public string CardNumber { get; set; }
        public sbyte BeforeCardType { get; set; }
        public sbyte AfterCardType { get; set; }
        public sbyte RecordType { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDbdate { get; set; }
    }
}
