﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 查询
    /// </summary>
    public class DepositMatchRuleQuery : Condition
    {
        /// <summary>
        /// 不等于
        /// </summary>
        public long? NotEqualId { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 匹配时间
        /// </summary>
        public int MatchMinute { get; set; }

        /// <summary>
        /// 匹配银行
        /// </summary>
        public string MatchBankCode { get; set; }
        
    }
}
