﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 角色查询
    /// </summary>
    public class SysRoleQuery : Condition
    {
        /// <summary>
        /// 角色编号
        /// </summary>
        public int? RId { get; set; }

        /// <summary>
        /// 角色状态
        /// </summary>
        public int? RStatus { get; set; }

        /// <summary>
        /// 角色编号
        /// </summary>
        public int? NoEqualRId { get; set; }

        /// <summary>
        /// 角色名称
        /// </summary>
        public string RName { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        public int? RoleCompanyId { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 创建人编号
        /// </summary>
        public int? CreateUId { get; set; }

        /// <summary>
        /// 创建人公司编号
        /// </summary>
        public int? CreateCID { get; set; }

    }
}
