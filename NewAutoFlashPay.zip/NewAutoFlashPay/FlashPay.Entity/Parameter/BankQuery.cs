﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Response.BankCard
{
    public class BankQuery : Condition
    {
        /// <summary>
        /// 编号
        /// </summary>
        public int? NoEqualBcId { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 卡号
        /// </summary>
        public long? OrderNo { get; set; }

        /// <summary>
        /// 银行名称
        /// </summary>
        public string BankName { get; set; }

        /// <summary>
        /// 卡号
        /// </summary>
        public string CardNumber { get; set; }

        /// <summary>
        /// 卡用户名
        /// </summary>
        public string CardName { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// 卡类型
        /// </summary>
        public List<sbyte> CardTypes { get; set; }

        /// <summary>
        /// 卡类型
        /// </summary>
        public sbyte? CardType { get; set; }

        /// <summary>
        /// 银行卡使用状态
        /// </summary>
        public sbyte? UsingStatus { get; set; }

        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        public sbyte? EnableStatus { get; set; }

        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        public List<sbyte> EnableStatusArray { get; set; }

        /// <summary>
        /// 银行卡使用状态
        /// </summary>
        public int? AuthStatus { get; set; }
        
        /// <summary>
        /// 网类型
        /// </summary>
        public sbyte? UsbType { get; set; }

        /// <summary>
        /// 用户编号
        /// </summary>
        public int? UserID { get; set; }
        

    }
}
