﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 付款卡查询参数
    /// </summary>
    public class PaymentCardQuery : Condition
    {
        /// <summary>
        /// 公司
        /// </summary>
        [Description("公司")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        [Description("开始时间")]
        public string StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        [Description("结束时间")]
        public string EndTime { get; set; }

        /// <summary>
        /// 公司名字
        /// </summary>
        [Description("公司名字")]
        public string CompanyName { get; set; }

        /// <summary>
        /// 銀行名称
        /// </summary>
        [Description("銀行卡号")]
        public string BankName { get; set; }

        /// <summary>
        /// 銀行卡号
        /// </summary>
        [Description("銀行卡号")]
        public string CardNumber { get; set; }

        /// <summary>
        /// 银行卡类型
        /// </summary>
        [Description("银行卡类型")]
        public sbyte CardType { get; set; }

        /// <summary>
        /// 銀行卡用戶名
        /// </summary>
        [Description("銀行卡用戶名")]
        public string CardName { get; set; }

        /// <summary>
        /// 银行卡使用状态
        /// </summary>
        [Description("银行卡使用状态")]
        public sbyte? UsingStatus { get; set; }

        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        [Description("银行卡启用状态")]
        public sbyte? EnableStatus { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        [Description("收款=1,付款=2")]
        public sbyte? AdjustStatus { get; set; }

        /// <summary>
        /// 功能权限
        /// </summary>
        public List<string> UserPermission { get; set; }
    }
}
