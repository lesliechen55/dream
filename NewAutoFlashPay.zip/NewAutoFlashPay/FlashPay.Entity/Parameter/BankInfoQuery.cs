﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    public class BankInfoQuery : Condition
    {
        public int BankBcid { get; set; }
        public string BankCode { get; set; }
        public string BankName { get; set; }
        public string BankFullName { get; set; }
        public string BankEnglishName { get; set; }
    }
}
