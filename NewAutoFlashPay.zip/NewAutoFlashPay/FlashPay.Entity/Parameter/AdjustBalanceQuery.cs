﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 余额变化查询
    /// </summary>
    public class AdjustBalanceQuery : Condition
    {
    }
}
