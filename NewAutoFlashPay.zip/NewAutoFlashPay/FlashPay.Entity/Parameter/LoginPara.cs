﻿using System;
using System.ComponentModel;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 登录参数
    /// </summary>
    public class LoginPara
    {
        /// <summary>
        /// 登录名称
        /// </summary>
        [Description("登录名称")]
        public string LoginName { get; set; }

        /// <summary>
        /// 登录密码
        /// </summary>
        [Description("登录密码")]
        public string PassWord { get; set; }

        /// <summary>
        /// 验证码
        /// </summary>
        [Description("验证码")]
        public string VerifyCode { get; set; }
    }
}
