﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 中转卡记录
    /// </summary>
    public class TransferCardRecordQuery : DataGridCondition
    {
        /// <summary>
        /// 公司
        /// </summary>
        [Description("公司")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        [Description("开始时间")]
        public string StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        [Description("结束时间")]
        public string EndTime { get; set; }

        /// <summary>
        /// 银行卡类型
        /// </summary>
        [Description("银行卡类型")]
        public sbyte CardType { get; set; }
    }
}
