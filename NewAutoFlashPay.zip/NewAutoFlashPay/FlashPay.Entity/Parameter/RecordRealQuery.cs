﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 实体付款变化查询
    /// </summary>
    public class RecordRealQuery : DataGridCondition
    {
        /// <summary>
        /// 开始时间
        /// </summary>
        public string StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public string EndTime { get; set; }

        /// <summary>
        /// 收款=1，付款=2
        ///  <summary>
        public sbyte RecordType { get; set; }

        #region 新增参数
        /// <summary>
        /// 公司名称
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// 收款卡用户名
        /// </summary>
        public string CardName { get; set; }

        /// <summary>
        /// 收款开始金额
        /// </summary>
        public decimal StartAmount { get; set; }

        /// <summary>
        /// 收款结束金额
        /// </summary>
        public decimal EndAmount { get; set; }

        /// <summary>
        /// 客户姓名
        /// </summary>
        public string ClientAccountName { get; set; }

        /// <summary>
        /// 付款卡用户名
        /// </summary>
        public string PaymentCradName { get; set; }

        /// <summary>
        /// 付款金额
        /// </summary>
        public string Amount { get; set; }

        /// <summary>
        /// 客户姓名
        /// </summary>
        public string WithdrawalAccountName { get; set; }
        #endregion

        /// <summary>
        /// 公司ID集合
        /// </summary>
        public List<int> CompanyIds { get; set; }
    }
}
