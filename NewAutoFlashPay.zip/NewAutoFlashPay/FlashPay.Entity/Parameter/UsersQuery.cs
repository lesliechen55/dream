﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 查询
    /// </summary>
    public class UsersQuery : Condition
    {
        /// <summary>
        /// 用户编号
        /// </summary>
        [Description("用户编号")]
        public int? UId { get; set; }
        /// <summary>
        /// 公司编号
        /// </summary>
        [Description("公司编号")]
        public List<int> CompanyIds { get; set; }
        /// <summary>
        /// 用户编号
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 公司名称
        /// </summary>
        public string UCompanyName { get; set; }
        /// <summary>
        /// 登陆名称
        /// </summary>
        public string ULoginName { get; set; }
        /// <summary>
        /// 联络电话
        /// </summary>
        public string UTelephone { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public List<sbyte> UStatus { get; set; }

        /// <summary>
        /// 功能权限
        /// </summary>
        public List<string> UserPermission { get; set; }
    }
}
