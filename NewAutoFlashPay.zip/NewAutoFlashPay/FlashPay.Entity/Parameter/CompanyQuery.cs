﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Parameter
{
   public class CompanyQuery : Condition
    {
        /// <summary>
        /// 公司编号
        /// </summary>
        public List<int> CompanyIds { get; set; }

        //public int CompanyId { get; set; }
        public int CompanyPid { get; set; }
        public string CompanyName { get; set; }
        public sbyte CompanyStatus { get; set; }
        public string CompanyBossName { get; set; }
        public string CompanyTel { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyNameEn { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }
        public int? UpdateUid { get; set; }
        public DateTime? UpdateDate { get; set; }
        public decimal? DepositRate { get; set; }
        public decimal? PayRate { get; set; }
    }
}
