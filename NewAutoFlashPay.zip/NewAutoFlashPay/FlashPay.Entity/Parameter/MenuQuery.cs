﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 菜单查询
    /// </summary>
    public class MenuQuery : Condition
    {
    }
}
