﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 付款卡余额变化查询
    /// </summary>
    public class PaymentAdjustBalanceQuery : Condition
    {
        /// <summary>
        /// 公司
        /// </summary>
        [Description("公司")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// 银行名称
        /// </summary>
        public string BankName { get; set; }

        /// <summary>
        /// 银行卡用户名
        /// </summary>
        public string CardName { get; set; }

        /// <summary>
        /// 银行卡号
        /// </summary>
        public string CardNumber { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public string StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public string EndTime { get; set; }

        /// <summary>
        /// 类别
        /// </summary>
        public int AdjustStatus { get; set; }
    }
}
