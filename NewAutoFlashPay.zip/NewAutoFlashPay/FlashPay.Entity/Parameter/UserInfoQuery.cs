﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 用户查询
    /// </summary>
    public class UserInfoQuery: Condition
    {
        /// <summary>
        /// 用户编号
        /// </summary>
        [Description("用户编号")]
        public int? Id { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        [Description("公司编号")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        [Description("公司名称")]
        public string uCompanyName { get; set; }

        /// <summary>
        /// 登录名称
        /// </summary>
        [Description("登录名称")]
        [StringLength(40, MinimumLength = 0, ErrorMessage = "登陆名称长度必须在{2}到{1}位之间")]
        public string uLoginName { get; set; }

        /// <summary>
        /// 联络电话
        /// </summary>
        [Description("联络电话")]
        public string uTelephone { get; set; }

        /// <summary>
        /// 联络邮箱
        /// </summary>
        [Description("联络邮箱")]
        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9]+\.[A-Za-z]{2,4}", ErrorMessage = "联络邮箱格式不正确")]
        public string uEmail { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        [Description("状态")]
        public int uStatus { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        [Description("创建时间")]
        public System.DateTime CreateDate { get; set; }

        ///角色Id
        public System.Collections.Generic.List<int> userRole { get; set; }

        ///旧密码
        public string uAgainPwd { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        [Description("密码")]
        [StringLength(40, MinimumLength = 0, ErrorMessage = "密码长度必须在{2}到{1}位之间")]
        public string uPwd { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        [Description("描述")]
        [StringLength(50, MinimumLength = 0, ErrorMessage = "说明内容长度不能超过50个字符")]
        public string uDescription { get; set; }

        public int UCreateId { get; set; }
    }
}
