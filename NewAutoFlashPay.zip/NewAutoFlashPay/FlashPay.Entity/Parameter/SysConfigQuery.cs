﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 参数查询
    /// </summary>
    public class SysConfigQuery : Condition
    {
        /// <summary>
        /// 公司编号
        /// </summary>
        public int? CompanyId { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// 分类代码
        /// </summary>
        public string ConfigCode { get; set; }

        /// <summary>
        /// 分类值
        /// </summary>
        public int ConfigValue { get; set; }

        /// <summary>
        /// 分类名称
        /// </summary>
        public string ConfigContent { get; set; }

        /// <summary>
        /// 分类说明
        /// </summary>
        public string Description { get; set; }


    }
}
