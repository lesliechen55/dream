﻿using FlashPay.Entity.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 收付款记录查询
    /// </summary>
    public class PaymentRecordQuery : DataGridCondition
    {
        /// <summary>
        /// 收付款类型
        /// </summary>
        public PaymentType PaymentType { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        [Description("开始时间")]
        public string StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        [Description("结束时间")]
        public string EndTime { get; set; }

        /// <summary>
        /// 公司
        /// </summary>
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 公司名字
        /// </summary>
        [Description("公司名字")]
        public string CompanyName { get; set; }

        /// <summary>
        /// 订单编号
        /// </summary>
        [Description("订单编号")]
        public long? OrderNo { get; set; }

        /// <summary>
        /// 付款名称
        /// </summary>
        [Description("付款名称")]
        public string CardName { get; set; }
        
        /// <summary>
        /// 客户姓名
        /// </summary>
        [Description("客户姓名")]
        public string WithdrawalAccountName { get; set; }

        /// <summary>
        /// 客户卡号
        /// </summary>
        [Description("客户卡号")]
        public string WithdrawalCardNumber { get; set; }

        /// <summary>
        /// 客户单号
        /// </summary>
        [Description("客户单号")]
        public string WithdrawalOrderNo { get; set; }
        

        /// <summary>
        /// 付款结果(未付款 = 1，付款成功 = 2，付款失败 = 3，付款中 = 4，取消付款 = 5)
        /// </summary>
        [Description("付款结果")]
        public sbyte? PaymentStatus { get; set; }

        /// <summary>
        /// 通知状态(未通知 = 1，通知成功 = 2，通知失败 = 3，通知中 = 4，状态为”通知中”时，旁边加”重置”按键 ex：，用于”重置”通知状态为”未通知”)
        /// </summary>
        [Description("通知状态")]
        public sbyte? NoticeStatus { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        [Description("创建时间")]
        public DateTime? CreateDbdate { get; set; }

        #region 新增字段
        /// <summary>
        ///银行卡编号
        ////// </summary>
        public string BankCode { get; set; }

        /// <summary>
        ///收款金额
        ////// </summary>
        public decimal DepositAmount { get; set; }

        /// <summary>
        /// Type=1代表DepositMatchID为null)
        /// </summary>
        public int Type { get; set; }

        #endregion
    }
}
