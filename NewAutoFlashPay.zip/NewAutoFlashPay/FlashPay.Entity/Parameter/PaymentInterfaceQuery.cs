﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    public class PaymentInterfaceQuery : Condition
    {
        /// <summary>
        /// 接口类型
        /// </summary>
        [Description("接口类型")]
        public sbyte PaymentType { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        [Description("公司名称")]
        public string CompanyName { get; set; }

        /// <summary>
        /// 接口公司名称
        /// </summary>
        [Description("接口公司名称")]
        public string InterfaceCompanyName { get; set; }

        ///秘钥
        [Required(AllowEmptyStrings = false, ErrorMessage = "秘钥不能为空")]
        [StringLength(64, MinimumLength = 0, ErrorMessage = "秘钥长度必须在{2}位和{1}位之间")]
        public string SecretKey { get; set; }

        /// <summary>
        /// 付款区间起
        /// </summary>
        [Description("付款区间起")]
        public decimal PaymentStart { get; set; }

        /// <summary>
        /// 付款区间起
        /// </summary>
        [Description("付款区间迄")]
        public decimal PaymentEnd { get; set; }

        /// <summary>
        /// 收款银行
        /// </summary>
        [StringLength(40,MinimumLength =0,ErrorMessage ="收款银行长度必须在{2}位和{1}位之间")]
        [Description("收款银行")]
        public string WithdrawalBank { get; set; }

        /// <summary>
        /// 存款等级
        /// </summary>
        [Required(AllowEmptyStrings =false,ErrorMessage = "存款等级不能为空")]
        [Description("存款等级")]
        public string DepositType { get; set; }

        /// <summary>
        /// 付款卡数量
        /// </summary>
        [Description("付款卡数量")]
        public int PaymentMax { get; set; }

        /// <summary>
        /// 开启时间
        /// </summary>
        [Description("开启时间")]
        public string LimitOpenDate { get; set; }

        /// <summary>
        /// 关闭时间
        /// </summary>
        [Description("关闭时间")]
        public string LimitCloseDate { get; set; }

        /// <summary>
        /// 每天执行
        /// </summary>
        [Description("每天执行")]
        public sbyte? LimitRepeat { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        [Description("状态")]
        public sbyte LimitStatus { get; set; }

        //区别是修改还是增加
        public int Type { get; set; }

        /// <summary>
        /// 公司ID集合
        /// </summary>
        public List<int> CompanyIds { get; set; }
    }
}
