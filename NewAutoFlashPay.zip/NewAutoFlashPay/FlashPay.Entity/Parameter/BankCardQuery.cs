﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 銀行卡信息查詢
    /// </summary>
    public class BankCardQuery: Condition
    {
        /// <summary>
        /// 系统编号
        /// </summary>
        [Description("系统编号")]
        public int? BCId { get; set; }

        /// <summary>
        /// 系统编号
        /// </summary>
        [Description("系统编号")]
        public int? NoEqualBCId { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        [Description("公司名称ID")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        [Description("公司名称")]
        public string CompanyName { get; set; }

        /// <summary>
        /// 銀行卡號
        /// </summary>
        [Description("銀行卡號")]
        public string CardNumber { get; set; }

        /// <summary>
        /// 订单号
        /// </summary>
        [Description("订单号")]
        public long OrderNo { get; set; }

        /// <summary>
        /// 银行名称
        /// </summary>
        [Description("银行名称")]
        public string BankName { get; set; }

        /// <summary>
        /// 银行卡类型
        /// </summary>
        [Description("银行卡类型")]
        public sbyte? CardType { get; set; }

        /// <summary>
        /// 銀行卡用戶名
        /// </summary>
        [Description("銀行卡用戶名")]
        public string CardName { get; set; }

        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        [Description("银行卡启用状态")]
        public sbyte? EnableStatus { get; set; }

        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        [Description("银行卡启用状态")]
        public List<sbyte> EnableStatusList { get; set; }

        /// <summary>
        /// 权限
        /// </summary>
        [Description("权限")]
        public List<string> UserPermission { get; set; }

        /// <summary>
        /// 创建人ID
        /// </summary>
        [Description("创建人ID")]
        public int CreateUid { get; set; }

        /// <summary>
        /// 作废开始时间
        /// </summary>
        [Description("作废开始时间")]
        public string StartTime { get; set; }

        /// <summary>
        /// 作废结束时间
        /// </summary>
        [Description("作废结束时间")]
        public string EndTime { get; set; }
    }
}
