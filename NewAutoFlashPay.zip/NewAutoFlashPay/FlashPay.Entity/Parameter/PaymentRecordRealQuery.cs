﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 查询条件
    /// </summary>
    public class PaymentRecordRealQuery
    {
        /// <summary>
        /// 付款记录订单号
        /// </summary>
        public long OrderNo { get; set; }

        /// <summary>
        /// 银行卡Id
        /// </summary>
        public int? PaymentCardID { get; set; }

        /// <summary>
        /// 分钟
        /// </summary>
        public int Minutes { get; set; }
    }
}
