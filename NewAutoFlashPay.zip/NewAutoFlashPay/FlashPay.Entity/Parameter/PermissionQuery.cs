﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    public class PermissionQuery: Condition
    {
        //不等于
        public int? NoEqualId { get; set; }

        public string PName { get; set; }
        public string PCode { get; set; }
        public int? NodeType { get; set; }
    }
}
