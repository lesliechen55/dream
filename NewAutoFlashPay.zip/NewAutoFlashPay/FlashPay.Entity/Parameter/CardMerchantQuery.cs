﻿using System.Collections.Generic;
using System.ComponentModel;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 卡商查询
    /// </summary>
    public class CardMerchantQuery : Condition
    {
        /// <summary>
        /// 公司编号
        /// </summary>
        [Description("公司编号")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 卡商ID
        /// </summary>
        [Description("卡商ID")]
        public int? CMID { get; set; }

        /// <summary>
        /// 卡商名称
        /// </summary>
        [Description("卡商名称")]
        public string CMName { get; set; }

        /// <summary>
        /// 卡商代号
        /// </summary>
        [Description("卡商代号")]
        public string CMCode { get; set; }

        /// <summary>
        /// 银行账号
        /// </summary>
        [Description("银行账号")]
        public string BankNumber { get; set; }

        /// <summary>
        /// 信用度
        /// </summary>
        [Description("信用度")]
        public string CMCredit { get; set; }

        /// <summary>
        /// 延迟率
        /// </summary>
        [Description("延迟率")]
        public sbyte DelayRate { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        [Description("备注")]
        public string Remark { get; set; }

        /// <summary>
        /// 创建用户ID
        /// </summary>
        [Description("创建用户ID")]
        public int CreateUid { get; set; }

        /// <summary>
        /// 卡管专员ID
        /// </summary>
        [Description("卡管专员ID")]
        public int? CardCommissionerUid { get; set; }

        /// <summary>
        /// 卡管专员名称
        /// </summary>
        [Description("卡管专员名称")]
        public string ULoginName { get; set; }
    }
}
