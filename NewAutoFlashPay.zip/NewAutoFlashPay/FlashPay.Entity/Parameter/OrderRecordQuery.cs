﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 订单查询参数
    /// </summary>
    public class OrderRecordQuery : Condition
    {
        /// <summary>
        /// 公司编号
        /// </summary>
        [Description("公司编号")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 押金审核人
        /// </summary>
        public int? DepositUid { get; set; }

        /// <summary>
        /// 收货审核人
        /// </summary>
        public int? ReceiptUid { get; set; }

        /// <summary>
        /// 付款审核人
        /// </summary>
        public int? PayUid { get; set; }
        
    }
}
