﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Parameter
{
   public class DepositMatchRecordQuery : DataGridCondition
    {
        /// <summary>
        /// ID
        /// </summary>
        [Description("ID")]
        public long ID { get; set; }

        /// <summary>
        /// 公司名字
        /// </summary>
        [Description("公司名字")]
        public string CompanyName { get; set; }

        /// <summary>
        /// 订单编号
        /// </summary>
        [Description("订单编号")]
        public long? OrderNo { get; set; }

        /// <summary>
        /// 订单开始时间
        /// </summary>
        [Description("订单开始时间")]
        public string StartTime { get; set; }

        /// <summary>
        /// 订单结束时间
        /// </summary>
        [Description("订单结束时间")]
        public string EndTime { get; set; }

        /// <summary>
        /// 银行名称
        /// </summary>
        [Description("银行名称")]
        public string ClientBankName { get; set; }

        /// <summary>
        /// 用户名称
        /// </summary>
        [Description("用户名称")]
        public string ClientAccountName { get; set; }

        ///// <summary>
        ///// 银行卡号
        ///// </summary>
        //[Description("银行卡号")]
        //public string ClientCardNumber { get; set; }

        //匹配分钟数
        public int MatchMinutes { get; set; }

        /// <summary>
        /// 公司ID集合
        /// </summary>
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 功能权限
        /// </summary>
        public List<string> UserPermission { get; set; }
    }
}
