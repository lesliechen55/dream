﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 授权查询
    /// </summary>
    public class ExtApiCompatQuery
    {
        /// <summary>
        /// 编号
        /// </summary>
        public int? Id { get; set; }

        /// <summary>
        /// 类型（收款 = 1，付款 = 2）
        /// </summary>
        public sbyte? Type { get; set; }

        /// <summary>
        /// 公司
        /// </summary>
        public int? CompanyId { get; set; }
    }
}
