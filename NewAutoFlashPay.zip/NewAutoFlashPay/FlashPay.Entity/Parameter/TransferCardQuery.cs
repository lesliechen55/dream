﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 中转卡管理
    /// </summary>
    public class TransferCardQuery : Condition
    {
        /// <summary>
        /// 公司
        /// </summary>
        [Description("公司")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 银行卡类型(1.存款卡、3.中转卡)
        /// </summary>
        public List<sbyte> CardType { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// 银行卡用户名
        /// </summary>
        public string CardName { get; set; }

        /// <summary>
        /// 银行卡号
        /// </summary>
        public string CardNumber { get; set; }

        /// <summary>
        /// 银行卡启用状态(1.启用、2.禁用)
        /// </summary>
        public sbyte? EnableStatus { get; set; }
    }
}
