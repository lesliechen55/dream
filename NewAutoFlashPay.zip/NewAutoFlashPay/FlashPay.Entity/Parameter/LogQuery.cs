﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 日志查询参数
    /// </summary>
    public class LogQuery : Condition
    {
        /// <summary>
        /// 日志编号
        /// </summary>
        [Description("编号")]
        public int? Id { get; set; }

        /// <summary>
        /// IP
        /// </summary>
        [Description("IP")]
        public string IP { get; set; }

        /// <summary>
        /// 日志类型
        /// </summary>
        [Description("日志类型")]
        public string LogType { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        [Description("创建人")]
        public string CreateName { get; set; }

        /// <summary>
        /// 创建人ID
        /// </summary>
        [Description("创建人ID")]
        public int CreateUID { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        [Description("创建时间")]
        public System.DateTime CreateDate { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        [Description("备注")]
        public string LogRemark { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        [Description("公司名称")]
        public string CompanyName { get; set; }


        /// <summary>
        /// 回调地址
        /// </summary>
        [Description("回调地址")]
        public string RequestUrl { get; set; }

        ///返回数据
        [Description("返回数据")]
        public string RequestData { get; set; }
    }
}
