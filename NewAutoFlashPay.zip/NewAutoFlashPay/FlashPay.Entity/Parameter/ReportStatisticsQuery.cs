﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    /// <summary>
    /// 报表查询参数
    /// </summary>
    public class ReportStatisticsQuery
    {
        /// <summary>
        /// 公司编号
        /// </summary>
        [Description("公司编号")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 公司
        /// </summary>
        [Description("公司")]
        public int? CompanyId { get; set; }

        /// <summary>
        /// 银行卡编号
        /// </summary>
        [Description("银行卡编号")]
        public List<int> BankCardIds { get; set; }

        /// <summary>
        /// 收付款类型
        /// </summary>
        [Description("收付款类型")]
        public sbyte? ReportType { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        [Description("开始时间")]
        public string StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        [Description("结束时间")]
        public string EndTime { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        [Description("创建时间")]
        public DateTime CreateDate { get; set; }
    }
}
