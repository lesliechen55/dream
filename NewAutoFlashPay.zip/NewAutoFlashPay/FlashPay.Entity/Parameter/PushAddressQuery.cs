﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace FlashPay.Entity.Parameter
{
    public class PushAddressQuery : Condition
    {
        public int ID { get; set; }
        /// <summary>
        /// 公司名称
        /// </summary>
        [Description("公司名称")]
        public string CompanyName { get; set; }

        /// <summary>
        /// 接口类型
        /// </summary>
        [Required]
        [Description("类型")]
        public sbyte Type { get; set; }

        /// <summary>
        /// 顺序
        /// </summary>
        [Description("顺序")]
        public int SortNo { get; set; }

        /// <summary>
        /// 接收地址
        /// </summary>
        [Required]
        [Description("接收地址")]
        public string Url { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        [Description("描述")]
        public string Description { get; set; }
    }
}
