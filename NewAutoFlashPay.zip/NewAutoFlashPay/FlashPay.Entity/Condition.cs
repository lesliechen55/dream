﻿namespace FlashPay.Entity
{
    using System.ComponentModel;

    /// <summary>
    /// 分页条件(所有分页查询必须继承此类)
    /// </summary>
    public class Condition
    {
        protected Condition()
        {
            CurrentPageIndex = CurrentPageIndex ?? 1;
            PageSize = 10;
        }

        /// <summary>
        /// 开始索引页
        /// </summary>
        [Description("当前页索引")]
        public int? CurrentPageIndex { get; set; }

        /// <summary>
        /// 页码
        /// </summary>
        [Description("页码")]
        public int? PageSize { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        [Description("公司编号")]
        public int? CompanyId { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        [Description("状态")]
        public int? Status { get; set; }
 
    }

    /// <summary>
    /// EasyUI分页条件
    /// </summary>
    public class DataGridCondition
    {
        /// <summary>
        /// 开始索引页
        /// </summary>
        [Description("当前页索引")]
        public int? Page { get; set; }

        /// <summary>
        /// 页码
        /// </summary>
        [Description("页码")]
        public int? Rows { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        [Description("公司编号")]
        public int? CompanyId { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        [Description("状态")]
        public int? Status { get; set; }
    }
}
