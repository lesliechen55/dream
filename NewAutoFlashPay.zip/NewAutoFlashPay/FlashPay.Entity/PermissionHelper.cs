﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity
{
    public class PermissionHelper
    {
        public class PermissionExtApiViewModel
        {
            public PermissionExtApiViewModel()
            {
                CanTransfer = false;
                CanPayment = false;
                CanDeposit = false;
                CanTransferAdd = false;
                CanPaymentAdd = false;
                CanDepositAdd = false;
            }
            public bool CanTransfer { set; get; }     //公司推送接口_中转_查看
            public bool CanPayment { set; get; }      //公司推送接口_付款_查看
            public bool CanDeposit { set; get; }      //公司推送接口_存款_查看
            public bool CanTransferAdd { set; get; }  //公司推送密钥_中转_新增
            public bool CanPaymentAdd { set; get; }   //公司推送密钥_付款_新增
            public bool CanDepositAdd { set; get; }   //公司推送密钥_存款_新增
        }
    }
}
