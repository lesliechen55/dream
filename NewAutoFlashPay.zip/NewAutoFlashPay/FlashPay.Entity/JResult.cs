﻿using System.Collections.Generic;
using static FlashPay.Entity.PermissionHelper;

namespace FlashPay.Entity
{
    #region 基础结果返回

    /// <summary>
    /// 基础结果返回
    /// </summary>
    public class JResult
    {
        /// <summary>
        /// 状态
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// 成功消息
        /// </summary>
        public string SuccessMessage { get; set; }

        /// <summary>
        /// 状态代码
        /// </summary>
        public string StatusCode { get; set; }

        /// <summary>
        /// 错误编码
        /// </summary>
        public string ErrorCode { get; set; }

        /// <summary>
        /// 错误消息
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// 错误消息
        /// </summary>
        public string Callback { get; set; }
        
    }

    #endregion

    #region 数据结果返回

    /// <summary>
    /// 数据结果返回
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class JResult<T> : JResult
    {
        /// <summary>
        /// 数据
        /// </summary>
        public T Data { get; set; }

        /// <summary>
        /// 权限值
        /// </summary>
        //public List<string> PermissionData { get; set; }
        public PermissionExtApiViewModel PermissionData { get; set; }
    }
    #endregion
}