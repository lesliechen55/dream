﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Role
{
    /// <summary>
    /// 角色
    /// </summary>
    public class RoleRequest:Request
    {
        public int RId { get; set; }
        public int RCompanyId { get; set; }
        public List<int> CompanyIds { get; set; }
        public string RName { get; set; }
        public DateTime CreateDate { get; set; }
        public sbyte RStatus { get; set; }
        public int CreateUid { get; set; }
        public int CreateCid { get; set; }

        public List<int> PermissionId { get; set; }
        /// <summary>
        /// 当前登录用户企业编号
        /// </summary>
        public int? CurrentUserCompanyId { get; set; }
    }
}
