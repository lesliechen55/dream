﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlashPay.Entity.Request.Role
{
    /// <summary>
    /// 菜单权限视图
    /// </summary>
    public class PermissionExtResponse
    {
        public int Pid { get; set; }
        public int? PParent { get; set; }
        public string PName { get; set; }
        public string PCode { get; set; }
        public int NodeType { get; set; }
        public int SortNo { get; set; }
        public sbyte Hide { get; set; }

        /// <summary>
        /// 系统编号
        /// </summary>
        [Description("系统编号")]
        public int MpMid { get; set; }
    }
}
