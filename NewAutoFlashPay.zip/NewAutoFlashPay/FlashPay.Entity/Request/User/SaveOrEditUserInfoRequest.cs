﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace FlashPay.Entity.Request.User
{
    /// <summary>
    /// 新增、编辑
    /// </summary>
    public class SaveOrEditUserInfoRequest
    {
        /// <summary>
        /// 用户编号
        /// </summary>
        [Description("用户编号")]
        public int Id { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        [Description("公司编号")]
        public int CompanyId { get; set; }

        /// <summary>
        /// 登录使用所属公司编号
        /// </summary>
        [Description("公司编号")]
        public int LoginUserCompanyId { get; set; }

        /// <summary>
        /// 登录名称
        /// </summary>
        [Description("登录名称")]
        [StringLength(40, MinimumLength = 0, ErrorMessage = "登陆名称长度必须在{2}到{1}位之间")]
        public string LoginName { get; set; }

        /// <summary>
        /// 联络邮箱
        /// </summary>
        [Description("联络邮箱")]
        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9]+\.[A-Za-z]{2,4}", ErrorMessage = "联络邮箱格式不正确")]
        public string Email { get; set; }

        /// <summary>
        /// 旧密码
        /// </summary>
        public string OldPassWord { get; set; }

        /// <summary>
        /// 新密码
        /// </summary>
        [Description("新密码")]
        [StringLength(40, MinimumLength = 0, ErrorMessage = "密码长度必须在{2}到{1}位之间")]
        public string NewPassWord { get; set; }

        /// <summary>
        /// 确认新密码
        /// </summary>
        [Description("确认新密码")]
        [StringLength(40, MinimumLength = 0, ErrorMessage = "密码长度必须在{2}到{1}位之间")]
        public string ConfirmNewPassWord { get; set; }

        /// <summary>
        /// 联络电话
        /// </summary>
        [Description("联络电话")]
        public string Telephone { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        [Description("描述")]
        [StringLength(50, MinimumLength = 0, ErrorMessage = "说明内容长度不能超过50个字符")]
        public string Description { get; set; }

        /// <summary>
        /// 角色编号
        /// </summary>
        public List<int> RoleIds { get; set; }

        /// <summary>
        /// 创建人编号
        /// </summary>
        public int UCreateId { get; set; }

        /// <summary>
        /// 创建人编号
        /// </summary>
        public int LoginUserId { get; set; }
    }
}
