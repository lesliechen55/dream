﻿using System;
using System.ComponentModel;

namespace FlashPay.Entity.Request.User
{
    /// <summary>
    ///  登录参数
    /// </summary>
    public class LoginRequest:Request
    {
        /// <summary>
        /// 帐号名称
        /// </summary>
        [Description("帐号名称")]
        public string Account { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        [Description("密码")]
        public string Password { get; set; }

        /// <summary>
        /// 验证码
        /// </summary>
        [Description("验证码")]
        public string VerifyCode { get; set; }
    }
}
