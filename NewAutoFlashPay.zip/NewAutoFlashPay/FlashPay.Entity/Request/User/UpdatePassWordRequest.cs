﻿using System;
using System.ComponentModel;

namespace FlashPay.Entity.Request.User
{
    /// <summary>
    ///  更新密码参数
    /// </summary>
    public class UpdatePassWordRequest
    {
        /// <summary>
        /// 编号
        /// </summary>
        [Description("编号")]
        public int Id { get; set; }

        /// <summary>
        /// 旧密码
        /// </summary>
        [Description("旧密码")]
        public string OldPassword { get; set; }
        /// <summary>
        /// 新密码
        /// </summary>
        [Description("新密码")]
        public string NewPassword { get; set; }
        /// <summary>
        /// 确认新密码
        /// </summary>
        [Description("确认新密码")]
        public string ConfirmNewPassword { get; set; }
        
    }
}
