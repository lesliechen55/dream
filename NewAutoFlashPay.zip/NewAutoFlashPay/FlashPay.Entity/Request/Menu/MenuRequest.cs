﻿namespace FlashPay.Entity.Request.Menu
{
    /// <summary>
    /// 菜单
    /// </summary>
    public class MenuRequest: Request
    {
        /// <summary>
        /// 编号
        /// </summary>
        public int? Mid { get; set; }

        /// <summary>
        /// 父ID
        /// </summary>
        public int? MParent { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string MName { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        public string MUrl { get; set; }

        /// <summary>
        /// 节点类型
        /// </summary>
        public int? NodeType { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int SortNo { get; set; }

        /// <summary>
        /// 功能分类
        /// </summary>
        public int MType { get; set; }

        /// <summary>
        /// 隐藏
        /// </summary>
        public sbyte Hide { get; set; }
    }
}
