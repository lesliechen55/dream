﻿namespace FlashPay.Entity.Request.Menu
{
    /// <summary>
    /// 菜单查询
    /// </summary>
    public class MenuQueryRequest : Condition
    {
        /// <summary>
        /// 编号
        /// </summary>
        public int? Mid { get; set; }

        /// <summary>
        /// 编号
        /// </summary>
        public int? NotEqualMid { get; set; }

        /// <summary>
        /// 父类
        /// </summary>
        public int? MParent { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string MName { get; set; }

        /// <summary>
        /// 节点类型
        /// </summary>
        public int? NodeType { get; set; }

        /// <summary>
        /// 功能分类
        /// </summary>
        public int? MType { get; set; }

        /// <summary>
        /// 隐藏
        /// </summary>
        public sbyte? Hide { get; set; }
    }
}
