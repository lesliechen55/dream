﻿namespace FlashPay.Entity.Request.Payment
{
    /// <summary>
    /// 付款卡编辑
    /// </summary>
    public class PaymentCardEditRequest
    {
        /// <summary>
        /// 银行卡类型
        /// </summary>
        public int BcId { get; set; }

        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        public sbyte? EnableStatus { get; set; }

        /// <summary>
        /// 付款区间起
        /// </summary>
        public string PaymentStart { get; set; }

        /// <summary>
        /// 付款区间迄
        /// </summary>
        public string PaymentEnd { get; set; }

        /// <summary>
        /// 跨行转账
        /// </summary>
        public sbyte? CrossBankPay { get; set; }

        /// <summary>
        /// 存款等级
        /// </summary>
        public string DepositType { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}
