﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Payment
{
    /// <summary>
    /// 
    /// </summary>
    public class TurnReqeust
    {
        /// <summary>
        /// 用户编号
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// 订单号
        /// </summary>
        public long OrderNo { get; set; }

        /// <summary>
        /// 实际付款记录订单号
        /// </summary>
        public long RecordRealOrderNo { get; set; }
    }
}
