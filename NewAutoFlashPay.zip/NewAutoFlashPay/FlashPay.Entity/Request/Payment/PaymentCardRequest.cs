﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Payment
{
    public class PaymentCardRequest
    {
        /// <summary>
        /// 当前登录用户企业编号
        /// </summary>
        public int CompanyId { get; set; }

    }
}
