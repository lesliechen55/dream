﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Payment
{
    /// <summary>
    /// 补单
    /// </summary>
    public class ReceiptMakeUpRequest
    {
        /// <summary>
        /// RecordReal订单号
        /// </summary>
        public long OrderNo { get; set; }

        /// <summary>
        /// 存款类型
        /// </summary>
        public int Transstype { get; set; }
    }
}
