﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Payment
{
    /// <summary>
    /// 添加付款卡模型
    /// </summary>
    public class PaymentRecordAddRequest
    {
        public long OrderNo { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal FeeRatio { get; set; }
        public decimal FeeTotal { get; set; }
        public decimal? BeforeBalance { get; set; }
        public decimal? AfterBalance { get; set; }
        public int CompanyId { get; set; }
        public int CurrentCompanyId { get; set; }
        public string PaymentRemark { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime CreateDbdate { get; set; }
        public int? ConfirmUid { get; set; }
        public string ConfirmName { get; set; }
        public sbyte ConfirmStatus { get; set; }
        public DateTime? ConfirmDate { get; set; }
        public DateTime? ReadDate { get; set; }
        public sbyte PaymentStatus { get; set; }
        public DateTime? PaymentDate { get; set; }
        public string PaymentFailInfo { get; set; }
        public sbyte NoticeStatus { get; set; }
        public DateTime? NoticeLastDate { get; set; }
        public int? NoticeTimes { get; set; }
        public int? PaymentCardId { get; set; }
        public string CardNumber { get; set; }
        public string WithdrawalOrderNo { get; set; }
        public decimal WithdrawalAmount { get; set; }
        public string WithdrawalBankName { get; set; }
        public string WithdrawalBankAddress { get; set; }
        public string WithdrawalAccountName { get; set; }
        public string WithdrawalCardNumber { get; set; }
        public string WithdrawalCardBankFlag { get; set; }
        public string DepositType { get; set; }
    }
}
