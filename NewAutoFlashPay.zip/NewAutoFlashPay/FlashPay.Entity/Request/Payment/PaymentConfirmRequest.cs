﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Payment
{
    /// <summary>
    /// 付款确认参数
    /// </summary>
    public class PaymentConfirmRequest
    {
        /// <summary>
        /// 付款单号
        /// </summary>
        public long OrderNo { get; set; }

        /// <summary>
        /// 确认人编号
        /// </summary>
        public int ConfirmUID { get; set; }

        /// <summary>
        /// 确认人名称
        /// </summary>
        public string ConfirmName { get; set; }

        /// <summary>
        /// 确认状态
        /// </summary>
        public sbyte ConfirmStatus { get; set; }

        /// <summary>
        /// 付款状态
        /// </summary>
        public sbyte PaymentStatus { get; set; }

        /// <summary>
        /// 时间
        /// </summary>
        public DateTime ConfirmDate { get; set; }
    }
}
