﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Authorize
{
    /// <summary>
    /// 授权
    /// </summary>
    public class AuthorizeRequest
    {
        /// <summary>
        /// 角色编号
        /// </summary>
        public int AuthRid { get; set; }
        public int AuthPid { get; set; }
        public sbyte AuthType { get; set; }
    }
}
