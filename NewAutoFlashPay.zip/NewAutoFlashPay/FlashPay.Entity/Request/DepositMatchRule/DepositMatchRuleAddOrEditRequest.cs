﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.DepositMatchRule
{
    /// <summary>
    ///  收款匹配规则
    /// </summary>
    public class DepositMatchRuleAddOrEditRequest
    {
        /// <summary>
        /// 编号
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 公司
        /// </summary>
        public int CompanyId { get; set; }
        /// <summary>
        /// 匹配时间
        /// </summary>
        public string MatchMinute { get; set; }
        /// <summary>
        /// 匹配银行
        /// </summary>
        public List<string> MatchBankCode { get; set; }
        /// <summary>
        /// 匹配规则
        /// </summary>
        public List<int> MatchRule { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string MatchRemark { get; set; }
        /// <summary>
        /// 创建人
        /// </summary>
        public int CreateId { get; set; }
    }
}
