﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Sys
{
    /// <summary>
    /// 
    /// </summary>
    public class SysConfigAddOrEditRequest
    {
        /// <summary>
        /// 系统编号
        /// </summary>
        public int ConfigId { set; get; }

        /// <summary>
        /// 码
        /// </summary>
        public String ConfigCode { set; get; }

        /// <summary>
        /// 值
        /// </summary>
        public string ConfigValue { set; get; }

        /// <summary>
        /// 内容
        /// </summary>
        public String ConfigContent { set; get; }

        /// <summary>
        /// 公司编号
        /// </summary>
        public int CompanyId { set; get; }

        //public List<int> CompanyIdList { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        public String CompanyName { set; get; }

        /// <summary>
        /// 描述
        /// </summary>
        public String Description { set; get; }
    }
}
