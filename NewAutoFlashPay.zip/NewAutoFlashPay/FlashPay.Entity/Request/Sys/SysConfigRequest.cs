﻿using FlashPay.Util;
using System;

namespace FlashPay.Entity.Request.Sys
{
    public class SysConfigRequest<T> : BaseModel<T>
    {
        public String ConfigCode { set; get; }
        public Int32 ConfigValue { set; get; }
        public String ConfigContent { set; get; }
        public Int32 CompanyID { set; get; }
        public String Description { set; get; }

        /* 額外欄位，驗證用 */
        public Int32 UserCompanyID { set; get; }
    }
}
