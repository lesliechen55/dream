﻿using FlashPay.Util;
using System;
using System.Collections.Generic;

namespace FlashPay.Entity.Request.Report
{
    public class ReportStatisticsRequest
    {
        /// <summary>
        /// 公司编号
        /// </summary>
        public int CompanyId { get; set; }

        /// <summary>
        /// 银行卡编号
        /// </summary>
        public int CardBcId { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public sbyte ReportType { get; set; }

        /// <summary>
        /// 金额
        /// </summary>
        public decimal ReportAmount { get; set; }

        /// <summary>
        /// 数量
        /// </summary>
        public int ReportQuantity { get; set; }

        /// <summary>
        /// 时间
        /// </summary>
        public DateTime ReportDate { get; set; }

        /// <summary>
        /// 费率
        /// </summary>
        public decimal FeeRatio { get; set; }

        /// <summary>
        /// 费用
        /// </summary>
        public decimal FeeTotal { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateDate { get; set; }
    }
}
