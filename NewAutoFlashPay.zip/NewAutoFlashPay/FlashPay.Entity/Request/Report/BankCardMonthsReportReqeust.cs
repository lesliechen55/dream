﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace FlashPay.Entity.Request.Report
{
    /// <summary>
    /// 
    /// </summary>
    public class BankCardMonthsReportReqeust
    {
        /// <summary>
        /// 公司
        /// </summary>
        [Description("公司")]
        public int CompanyId { get; set; }

        /// <summary>
        /// 公司
        /// </summary>
        [Description("公司")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 报表时间
        /// </summary>
        [Description("报表时间")]
        public DateTime ReportDate { get; set; }

        /// <summary>
        /// 报表类型
        /// </summary>
        [Description("报表类型")]
        public sbyte ReportType { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        [Description("开始时间")]
        public string StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        [Description("结束时间")]
        public string EndTime { get; set; }
    }
}
