﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace FlashPay.Entity.Request.Report
{
    /// <summary>
    /// 公司银行卡报表查询
    /// </summary>
    public class BankCardDetailQuery
    {
        /// <summary>
        /// 公司编号
        /// </summary>
        [Description("公司编号")]
        public int CompanyId { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        [Description("公司编号")]
        public List<int> CompanyIds { get; set; }

        /// <summary>
        /// 卡类型
        /// </summary>
        public sbyte? CardType { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        [Description("开始时间")]
        public string StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        [Description("结束时间")]
        public string EndTime { get; set; }
    }
}
