﻿using FlashPay.Entity.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Log
{
    /// <summary>
    /// 创建日志参数
    /// </summary>
    public class LogRecordRequest
    {
        /// <summary>
        /// IP
        /// </summary>
        public string Ip { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public LogRecordLogType LogType { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public string CreateName { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int CreateUid { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string LogRemark { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        public int? CompanyId { get; set; }

        /// <summary>
        /// 请求Url
        /// </summary>
        public string RequestUrl { get; set; }

        /// <summary>
        /// 请求数据
        /// </summary>
        public string RequestData { get; set; }
    }
}
