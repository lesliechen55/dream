﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request
{
    public class Request
    {
        /// <summary>
        /// Ip地址
        /// </summary>
        public string Ip { get; set; }

        /// <summary>
        /// 创建人编号
        /// </summary>
        public int? CreateId { get; set; }

        /// <summary>
        /// 创建人名称
        /// </summary>
        public string CreateName { get; set; }

        /// <summary>
        /// 创建人编号
        /// </summary>
        public int? CompanyId { get; set; }
        
        /// <summary>
        /// 请求Url
        /// </summary>
        public string RequestUrl { get; set; }

        /// <summary>
        /// 请求数据
        /// </summary>
        public string RequestData { get; set; }
    }
}
