﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Bank
{
    public class DocumentRequest
    {
        /// <summary>
        /// 图片地址
        /// </summary>
        public string URL { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public string Sort { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        public string Description { get; set; }
    }
}
