﻿using FlashPay.Util;
using System;

namespace FlashPay.Entity.Request.Bank
{
    public class BankInfoRequest<T> : BaseModel<T>
    {
        public String BankCode { set; get; }
        public String BankName { set; get; }
        public String BankFullName { set; get; }
        public String BankEnglishName { set; get; }
        public Int32 SortNo { set; get; }
        public String BankUrl { set; get; }
        public String BankRemark { set; get; }
        public String BankTel { set; get; }
        public String BankAddress { set; get; }
    }
}
