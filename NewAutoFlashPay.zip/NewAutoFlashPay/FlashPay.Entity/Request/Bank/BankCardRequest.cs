﻿using FlashPay.Util;
using System;

namespace FlashPay.Entity.Request.Bank
{
    public class BankCardRequest<T> : BaseModel<T>
    {
        public Int32 UserCompanyID { set; get; }
        public Int32 NotEnableStatus { set; get; }
    }
}
