﻿using FlashPay.Entity.Response.BankCard;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace FlashPay.Entity.Request.Bank
{
    /// <summary>
    /// 银行卡
    /// </summary>
    public class StockCardAddOrEditRequest
    {
        /// <summary>
        /// 编号
        /// </summary>
        public int BCId { get; set; }
        /// <summary>
        /// 订单
        /// </summary>
        public string OrderNo { get; set; }
        /// <summary>
        /// 银行代码
        /// </summary>
        [Required(ErrorMessage = "请选择银行名称!")]
        public string BankCode { get; set; }
        /// <summary>
        /// 银行名称
        /// </summary>
        public string BankName { get; set; }
        /// <summary>
        /// 银行卡类型
        /// </summary>
        public sbyte CardType { get; set; }

        /// <summary>
        /// 银行卡号
        /// </summary>
        [Description("银行卡号")]
        [Required(ErrorMessage = "银行卡号不能为空!")]
        [StringLength(20, MinimumLength = 12, ErrorMessage = "银行卡号长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[0-9]*$", ErrorMessage = "银行卡号只能为数字")]
        public string CardNumber { get; set; }

        /// <summary>
        /// 银行副卡号
        /// </summary>
        public string SecCardNumber { get; set; }

        /// <summary>
        /// 银行卡用户名
        /// </summary>
        [DisplayName("银行卡用户名")]
        [Required(ErrorMessage = "银行卡用户名不能为空!")]
        [StringLength(40, MinimumLength = 2, ErrorMessage = "银行卡用户名长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "银行卡用户名由中文、英文、数字包括下划线")]
        public string CardName { get; set; }

        /// <summary>
        /// 银行卡使用状态
        /// </summary>
        public sbyte UsingStatus { get; set; }
        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        public sbyte EnableStatus { get; set; }

        /// <summary>
        /// 登陆名称
        /// </summary>
        [DisplayName("登陆名称")]
        [Required(ErrorMessage = "登陆名称不能为空!")]
        [StringLength(40, MinimumLength = 2, ErrorMessage = "登陆名称长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "登陆名称由中文、英文、数字包括下划线")]
        public string LoginName { get; set; }

        /// <summary>
        /// 登陆密码
        /// </summary>
        [DisplayName("登陆密码")]
        [Required(ErrorMessage = "登陆密码不能为空!")]
        [StringLength(40, MinimumLength = 6, ErrorMessage = "登陆密码长度必须介于 {2} 和 {1} 之间")]
        public string PasswordLogin { get; set; }

        /// <summary>
        /// 查询密码
        /// </summary>
        public string PasswordQuery { get; set; }
        /// <summary>
        /// 支付密码
        /// </summary>
        public string PasswordPay { get; set; }
        /// <summary>
        /// 网盾密码
        /// </summary>
        public string PasswordShield { get; set; }

        /// <summary>
        /// 网盾类型
        /// </summary>
        public sbyte UsbType { get; set; }

        /// <summary>
        /// 网盾序号
        /// </summary>
        public string UsbSerialNumber { get; set; }

        /// <summary>
        /// 原始密码
        /// </summary>
        [DisplayName("原始密码")]
        //[Required(ErrorMessage = "原始密码不能为空!")]
        //[StringLength(40, MinimumLength = 6, ErrorMessage = "原始密码长度必须介于 {2} 和 {1} 之间")]
        public string OriginalPassword { get; set; }

        /// <summary>
        /// 开户地
        /// </summary>
        [DisplayName("开户地")]
        [Required(ErrorMessage = "开户地不能为空!")]
        [StringLength(40, MinimumLength = 1, ErrorMessage = "开户地长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "开户地由中文、英文、数字包括下划线")]
        public string AccountBank { get; set; }

        /// <summary>
        /// 证件号码
        /// </summary>
        [DisplayName("证件号码")]
        //[Required(ErrorMessage = "证件号码不能为空!")]
        //[StringLength(40, MinimumLength = 3, ErrorMessage = "证件号码长度必须介于 {2} 和 {1} 之间")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// 手机号码
        /// </summary>
        [DisplayName("手机号码")]
        //[Required(ErrorMessage = "手机号码不能为空!")]
        //[RegularExpression(@"^\d{11}$", ErrorMessage = "请输入11位手机号码")]
        public string PhoneNumber { get; set; }

        #region 1.收款卡、2.中转卡、3.付款卡 使用
        /// <summary>
        /// 付款区间起
        /// </summary>
        public decimal PaymentStart { get; set; }
        /// <summary>
        /// 付款区间止
        /// </summary>
        public decimal PaymentEnd { get; set; }
        /// <summary>
        /// 付款费率
        /// </summary>
        public decimal PayFeeRatio { get; set; }
        /// <summary>
        /// 收款费率
        /// </summary>
        public decimal DepositFeeRatio { get; set; }
        /// <summary>
        /// 跨行转账
        /// </summary>
        public sbyte CrossBankPay { get; set; }
        /// <summary>
        /// 等级
        /// </summary>
        public string DepositType { get; set; }
        #endregion

        /// <summary>
        /// 公司编号
        /// </summary>
        public int CompanyId { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        [Required]
        public int CreateUid { get; set; }

        /// <summary>
        /// 图片
        /// </summary>
        public string BankPhoto { get; set; }

        /// <summary>
        /// 证件
        /// </summary>
        public DocumentResponse DocumentResponse { get; set; }

    }
}
