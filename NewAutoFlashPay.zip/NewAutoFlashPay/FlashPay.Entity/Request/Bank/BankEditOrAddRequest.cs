﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.Bank
{
    /// <summary>
    /// 银行卡修改、添加参数
    /// </summary>
    public class BankEditOrAddRequest
    {
        /// <summary>
        /// 银行卡类型
        /// </summary>
        public int BcId { get; set; }

        /// <summary>
        /// 银行卡类型
        /// </summary>
        public sbyte CardType { get; set; }

        /// <summary>
        /// 公司编号
        /// </summary>
        public int CompanyId { get; set; }

        /// <summary>
        /// 银行副卡号
        /// </summary>
        public string SecCardNumber { get; set; }

        /// <summary>
        /// 银行卡使用状态
        /// </summary>
        public sbyte? UsingStatus { get; set; }

        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        public sbyte? EnableStatus { get; set; }

        /// <summary>
        /// 查询密码
        /// </summary>
        public string PasswordQuery { get; set; }

        /// <summary>
        /// 原始密码
        /// </summary>
        public string OriginalPassword { get; set; }

        /// <summary>
        /// 网盾类型
        /// </summary>
        public sbyte? UsbType { get; set; }

        /// <summary>
        /// 付款区间起
        /// </summary>
        public string PaymentStart { get; set; }

        /// <summary>
        /// 付款区间迄
        /// </summary>
        public string PaymentEnd { get; set; }

        /// <summary>
        /// 付款费率
        /// </summary>
        public string PayFeeRatio { get; set; }

        /// <summary>
        /// 跨行转账
        /// </summary>
        public sbyte? CrossBankPay { get; set; }

        /// <summary>
        /// 证件号码
        /// </summary>
        public string DocumentNumber { get; set; }

        /// <summary>
        /// 收款费率
        /// </summary>
        public string DepositFeeRatio { get; set; }

        /// <summary>
        /// 存款等级
        /// </summary>
        public string DepositType { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 用户编号
        /// </summary>
        public int UserId { get; set; }

        #region 额外限制
        /// <summary>
        /// 关闭时间
        /// </summary>
        public DateTime? LimitCloseDate { get; set; }

        /// <summary>
        /// 开启时间
        /// </summary>
        public DateTime? LimitOpenDate { get; set; }

        /// <summary>
        /// 每天执行
        /// </summary>
        public sbyte? LimitRepeat { get; set; }

        /// <summary>
        /// 限制收款金额
        /// </summary>
        public string LimitDepositAmount { get; set; }

        /// <summary>
        /// 转付款
        /// </summary>
        public sbyte? LimitChangetoPay { get; set; }

        /// <summary>
        /// 限制付款金额
        /// </summary>
        public string LimitPayAmount { get; set; }

        /// <summary>
        /// 转收款
        /// </summary>
        public sbyte? LimitChangetoDeposit { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public sbyte? LimitStatus { get; set; }
        #endregion

        #region 中转卡
        /// <summary>
        /// 中转费率
        /// </summary>
        public string TransportRate { get; set; }
        ///// <summary>
        ///// 使用接口生成中转订单
        ///// </summary>
        //public sbyte ApiTransport { get; set; }
        ///// <summary>
        ///// 触发中转金额
        ///// </summary>
        //public string LimitAmount { get; set; }
        ///// <summary>
        ///// 每次中转金额
        ///// </summary>
        //public string LimitTransFerAmount { get; set; }
        ///// <summary>
        ///// 转入卡类别
        ///// </summary>
        //public sbyte LimitCardType { get; set; }
        ///// <summary>
        ///// 预留账户金额
        ///// </summary>
        //public string LimitBalance { get; set; }
        ///// <summary>
        ///// 转账最大额度
        ///// </summary>
        //public string LimitMaxAmount { get; set; }
        ///// <summary>
        ///// 转入卡余额
        ///// </summary>
        //public string LimitOrderSideBalance { get; set; }
        ///// <summary>
        ///// 转入卡银行
        ///// </summary>
        //public string LimitBankCode { get; set; }
        #endregion
    }
}
