﻿using System;

namespace FlashPay.Entity.Request.ExtApi
{
    /// <summary>
    /// 推送地址
    /// </summary>
    public class ExtApiPushUrlAddOrEditRequest
    {
        /// <summary>
        /// 系统编号
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 公司编号
        /// </summary>
        public int? CompanyId { get; set; }
        /// <summary>
        /// 类型
        /// </summary>
        public sbyte Type { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public sbyte SortNo { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public sbyte Status { get; set; }
        /// <summary>
        /// Url
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// 描述
        /// </summary>
        public string Description { get; set; }
    }
}
