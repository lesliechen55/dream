﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.ExtApi
{
    /// <summary>
    /// 授权
    /// </summary>
    public class ExtApiCompatEditRequest
    {
        /// <summary>
        /// 存款编号
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 存款类型
        /// </summary>
        public sbyte Type { get; set; }
        /// <summary>
        /// 存款公司
        /// </summary>
        public int CompanyId { get; set; }
        /// <summary>
        /// 存款ApiKey
        /// </summary>
        public string ApiKey { get; set; }
        /// <summary>
        /// 存款SecretKey
        /// </summary>
        public string SecretKey { get; set; }
        /// <summary>
        /// 存款状态
        /// </summary>
        public sbyte Status { get; set; }
    }
}
