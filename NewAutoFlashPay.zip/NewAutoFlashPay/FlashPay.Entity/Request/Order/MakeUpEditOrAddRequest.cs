﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace FlashPay.Entity.Request.Order
{
    public class MakeUpEditOrAddRequest
    {
        /// <summary>
        /// 系统编号
        /// </summary>
        public int DetailId { get; set; }
        /// <summary>
        /// 订单编号
        /// </summary>
        [DisplayName("订单编号")]
        [Required(ErrorMessage = "订单编号不能为空")]
        public long OrderNo { get; set; }

        /// <summary>
        /// 银行编码
        /// </summary>
        [DisplayName("银行编码")]
        [Required(ErrorMessage = "银行编码不能为空")]
        [RegularExpression(@"^[A-Za-z]+$", ErrorMessage = "银行编码只能包含英文")]
        public string BankCode { get; set; }

        /// <summary>
        /// 下单数量
        /// </summary>
        public int OrderQuantity { get; set; }

        /// <summary>
        /// 单价
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// 实际数量
        /// </summary>
        [DisplayName("实际数量")]
        [Required(ErrorMessage = "实际数量不能为空")]
        [RegularExpression(@"^[0-9]*$", ErrorMessage = "实际数量格式错误")]
        public int ActualQuantity { get; set; }

        /// <summary>
        /// 实际单价
        /// </summary>
        [DisplayName("实际单价")]
        [Required(ErrorMessage = "实际单价不能为空")]
        [RegularExpression(@"^\d{1,4}(?:\.\d{1,2})?$", ErrorMessage = "实际单价必须为金额，最多保留2位小数")]
        public decimal ActualUnitPrice { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }

        /// <summary>
        /// 用户权限
        /// </summary>
        public List<String> userPermission { get; set; }
    }
}
