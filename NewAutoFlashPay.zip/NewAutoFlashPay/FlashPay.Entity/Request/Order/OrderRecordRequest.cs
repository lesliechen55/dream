﻿using System;
using System.Collections.Generic;
using FlashPay.Util;

namespace FlashPay.Entity.Request.Order
{
    public class OrderRecordRequest<T> : BaseModel<T>
    {
        public Int64? OrderNo { set; get; }
        public DateTime? OrderDate { set; get; }
        public DateTime? EndOrderDate { set; get; }

        public String DeliveryNo { set; get; }

        public Int32? DepositUID { set; get; }
        public DateTime? DepositDate { set; get; }
        public Decimal? DepositAmount { set; get; }
        public String DepositCardNumber { set; get; }

        public Int32? ReceiptUID { set; get; }
        public DateTime? ReceiptDate { set; get; }

        public Int32? PayUID { set; get; }
        public DateTime? PayDate { set; get; }
        public DateTime? EndPayDate { set; get; }
        public Decimal? PayAmount { set; get; }
        public String PayCardNumber { set; get; }

        public String PayUserName { set; get; }

        public Int32? CreateUID { set; get; }
        public DateTime? CreateDate { set; get; }

        public Int32 Status { set; get; }

        public Int32 CMID { set; get; }
        public String CMName { get; set; }             //卡商名称

        /* 為限制獲取訂單時條件 */
        public Int32 CompanyID { set; get; }

        public List<OrderRecordDetailRequest<String>> OrderRecordDetails { set; get; }
    }
}