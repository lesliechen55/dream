﻿using System;
using FlashPay.Util;

namespace FlashPay.Entity.Request.Order
{
    public class OrderRecordDetailRequest<T> : BaseModel<T>
    {
        public Int32 DetailID { set; get; }

        public Int64 OrderNo { set; get; }

        public Int32 CMID { set; get; }
        
        public String BankCode { set; get; }
        
        public Int32 OrderQuantity { set; get; }
        
        public Decimal UnitPrice { set; get; }
        
        public Int32 ActualQuantity { set; get; }
        
        public Decimal ActualUnitPrice { set; get; }
        
        public String Remark { set; get; }

        public Int32 CreateUID { set; get; }

        public DateTime CreateDate { set; get; }

        /* 為檢查與主訂單關聯性 */
        public Int32 CompanyID { set; get; }
    }
}