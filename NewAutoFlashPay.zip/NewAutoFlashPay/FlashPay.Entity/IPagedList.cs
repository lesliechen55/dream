﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity
{
    /// <summary>
    /// 
    /// </summary>
    public interface IPagedList
    {
        int CurrentPageIndex { get; set; }
        int PageSize { get; set; }
        int TotalCount { get; set; }
    }
}
