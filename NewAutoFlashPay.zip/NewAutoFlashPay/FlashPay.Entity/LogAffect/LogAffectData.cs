﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.LogAffect
{
    public class LogAffectData
    {
        public LogAffectData()
        {
            BeforeData = new Dictionary<String, Object>();
            AfterData = new Dictionary<String, Object>();
        }

        public Dictionary<String, Object> BeforeData { set; get; }
        public Dictionary<String, Object> AfterData { set; get; }
    }
}
