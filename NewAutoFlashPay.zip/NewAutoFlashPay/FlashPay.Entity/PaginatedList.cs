﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class PagedList<T> : PagedList
    {
        /// <summary>
        /// 当前页数据
        /// </summary>
        public IList<T> TData { get; set; }
    }

    /// <summary>
    /// 分页模型
    /// </summary>>
    public class PagedList : IPagedList
    {
        /// <summary>
        /// 状态
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// 状态代码
        /// </summary>
        public string StatusCode { get; set; }

        /// <summary>
        /// 错误编码
        /// </summary>
        public string ErrorCode { get; set; }

        /// <summary>
        /// 错误消息
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// 当前页码
        /// </summary>
        private int pageSize = 10;

        /// <summary>
        /// 当前索引
        /// </summary>
        public int CurrentPageIndex { get; set; }

        /// <summary>
        /// 每页显示数
        /// </summary>
        public int PageSize
        {
            get { return pageSize; }
            set { pageSize = value; }
        }

        /// <summary>
        /// 数据总数
        /// </summary>
        public int TotalCount { get; set; }
        /// <summary>
        /// 分页数
        /// </summary>
        public int TotalPageCount { get { return (int)Math.Ceiling(TotalCount / (double)PageSize); } }

    }

    public class DataGrid<T>
    {
        /// <summary>
        /// 状态
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// 状态代码
        /// </summary>
        public string StatusCode { get; set; }

        /// <summary>
        /// 错误编码
        /// </summary>
        public string ErrorCode { get; set; }

        /// <summary>
        /// 错误消息
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// 总记录数
        /// </summary>
        public int Total { get; set; }

        /// <summary>
        /// 当前页数据
        /// </summary>
        public IList<T> Rows { get; set; }
    }
}
