﻿using System;

namespace FlashPay.Entity.Response.Company
{
    public class CompanyResponse
    {
        public int CompanyID { set; get; }
        public int CompanyPID { set; get; }
        public String CompanyName { set; get; }
        public SByte CompanyStatus { set; get; }
        public String CompanyBossName { set; get; }
        public String CompanyTel { set; get; }
        public String CompanyAddress { set; get; }
        public String CompanyNameEN { set; get; }
        public int CreateUID { set; get; }
        public DateTime CreateDate { set; get; }
        public int? UpdateUID { set; get; }
        public DateTime? UpdateDate { set; get; }
        public Decimal? DepositRate { set; get; }
        public Decimal? PayRate { set; get; }
        public Decimal? TransportRate { set; get; }
        public Int32 MenuType { set; get; }
    }
}