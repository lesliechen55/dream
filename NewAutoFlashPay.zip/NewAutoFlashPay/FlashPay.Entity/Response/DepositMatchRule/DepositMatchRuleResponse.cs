﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.Response.DepositMatchRule
{
    using FlashPay.Entity.Response.Bank;
    using FlashPay.Entity.Response.Company;

    /// <summary>
    ///  收款匹配规则
    /// </summary>
    public class DepositMatchRuleResponse
    {
        /// <summary>
        /// 编号
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// 公司
        /// </summary>
        public int CompanyId { get; set; }

        /// <summary>
        /// 公司名称
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// 公司英文名称
        /// </summary>
        public string CompanyNameEn { get; set; }

        /// <summary>
        /// 匹配时间
        /// </summary>
        public int MatchMinute { get; set; }

        /// <summary>
        /// 匹配银行
        /// </summary>
        public string MatchBankCode { get; set; }

        /// <summary>
        /// 匹配规则
        /// </summary>
        public string MatchRule { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string MatchRemark { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int CreateId { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateDate { get; set; }

        /// <summary>
        /// 银行列表
        /// </summary>
        public List<BankInfoResponse> BankInfoResponse { get; set; }

        /// <summary>
        /// 公司列表
        /// </summary>
        public List<CompanyResponse> CompanyResponse { get; set; }
    }
}
