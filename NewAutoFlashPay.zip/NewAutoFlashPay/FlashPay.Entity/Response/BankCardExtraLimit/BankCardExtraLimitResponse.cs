﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Response.BankCardExtraLimit
{
    public class BankCardExtraLimitResponse
    {
        public string CardNumber { get; set; }
        public DateTime? LimitCloseDate { get; set; }
        public DateTime? LimitOpenDate { get; set; }
        public sbyte? LimitRepeat { get; set; }
        public decimal? LimitDepositAmount { get; set; }
        public sbyte? LimitChangetoPay { get; set; }
        public decimal? LimitPayAmount { get; set; }
        public sbyte? LimitChangetoDeposit { get; set; }
        public sbyte LimitStatus { get; set; }
    }
}
