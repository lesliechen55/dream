﻿using FlashPay.Entity.Response.Company;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Request.DepositMatchRecord
{
    public class DepositMatchRecordResponse
    {
        public string Id { get; set; }
        public int CompanyId { get; set; }
        public string BankCode { get; set; }
        public string MatchOrderNo { get; set; }
        public string ClientOrderNo { get; set; }
        public string DepositRemark { get; set; }
        public DateTime CreateDbdate { get; set; }
        public DateTime DepositDate { get; set; }
        public decimal DepositAmount { get; set; }
        public string ClientBankName { get; set; }
        public string ClientAccountName { get; set; }
        public string ClientCardNumber { get; set; }
        public string PostScript { get; set; }
        public int? UpdateId { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string CompanyName { get; set; }
        public bool IsShowSearch { get; set; }//是否显示查询按钮
        public bool IsShowAddPush { get; set; }//是否显示补推送按钮
        public string StatusCode { get; set; }
        public string ErrorCode { get; set; }
    }
}
