﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Response.Bank
{
    /// <summary>
    /// 银行卡输出
    /// </summary>
    public class BankPagerResponse
    {
        /// <summary>
        /// 系统编号
        /// </summary>
        public int BcId { get; set; }
        /// <summary>
        /// 公司名称
        /// </summary>
        public long OrderNo { get; set; }
        /// <summary>
        /// 公司名称
        /// </summary>
        public string DisplayOrderNo { get; set; }
        /// <summary>
        /// 公司编号
        /// </summary>
        public int CompanyId { get; set; }
        /// <summary>
        /// 银行卡公司编号
        /// </summary>
        public int BankCardCompanyId { get; set; }
        /// <summary>
        /// 公司名称
        /// </summary>
        public string CompanyName { get; set; }
        /// <summary>
        /// 	公司英文名称
        /// </summary>
        public string CompanyNameEN { get; set; }
        /// <summary>
        /// 银行名称
        /// </summary>
        public string BankName { get; set; }
        /// <summary>
        /// 银行卡用户名
        /// </summary>
        public string CardName { get; set; }
        /// <summary>
        /// 银行卡号
        /// </summary>
        public string CardNumber { get; set; }
        /// <summary>
        /// 银行卡副卡号
        /// </summary>
        public string SecCardNumber { get; set; }
        /// <summary>
        /// 银行卡类型
        /// </summary>
        public sbyte CardType { get; set; }
        /// <summary>
        /// 银行卡使用状态
        /// </summary>
        public sbyte UsingStatus { get; set; }
        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        public sbyte EnableStatus { get; set; }
        /// <summary>
        /// 网盾类型
        /// </summary>
        public sbyte UsbType { get; set; }
        /// <summary>
        /// 付款区间
        /// </summary>
        public string PaymentInterval { get; set; }
        /// <summary>
        /// 付款费率
        /// </summary>
        public string PayFeeRatio { get; set; }
        /// <summary>
        /// 收款费率
        /// </summary>
        public string DepositFeeRatio { get; set; }
        /// <summary>
        /// 跨行转账
        /// </summary>
        public int CrossBankPay { get; set; }
        /// <summary>
        /// 存款等级
        /// </summary>
        public string DepositType { get; set; }
        /// <summary>
        /// 创建人名称
        /// </summary>
        public string CreateName { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public string CreateDate { get; set; }
    }
}
