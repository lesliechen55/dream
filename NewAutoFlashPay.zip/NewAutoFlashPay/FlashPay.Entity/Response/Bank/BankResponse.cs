﻿using System;
using System.Collections.Generic;

namespace FlashPay.Entity.Response.Bank
{
    using FlashPay.Entity.Response.BankCard;
    using FlashPay.Entity.Response.Company;
    using FlashPay.Entity.Response.Order;

    /// <summary>
    /// 银行卡输出
    /// </summary>
    public class BankResponse
    {
        public int Bcid { get; set; }
        public string OrderNo { get; set; }
        public string BankCode { get; set; }
        public string BankName { get; set; }
        public string CardNumber { get; set; }
        public string SecCardNumber { get; set; }
        public string CardName { get; set; }
        public sbyte CardType { get; set; }
        public sbyte UsingStatus { get; set; }
        public sbyte EnableStatus { get; set; }
        public string LoginName { get; set; }
        public string PasswordLogin { get; set; }
        public string PasswordQuery { get; set; }
        public string PasswordPay { get; set; }
        public string PasswordShield { get; set; }
        public sbyte UsbType { get; set; }
        public string UsbSerialNumber { get; set; }
        public string OriginalPassword { get; set; }
        public string AccountBank { get; set; }
        public string DocumentNumber { get; set; }
        public string PhoneNumber { get; set; }
        public decimal PaymentStart { get; set; }
        public decimal PaymentEnd { get; set; }
        /// <summary>
        /// 付款费率
        /// </summary>
        public decimal PayFeeRatio { get; set; }

        /// <summary>
        /// 收款费率
        /// </summary>
        public decimal DepositFeeRatio { get; set; }
        public sbyte CrossBankPay { get; set; }
        public string DepositType { get; set; }
        public string BankPhoto { get; set; }
        public int CompanyId { get; set; }
        public string Remark { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }
        public string IpAddress { get; set; }

        /// <summary>
        /// 中转费率
        /// </summary>
        public decimal TransportRate { get; set; }

        public TransportCardResponse TransportCardResponse { get; set; }

        #region 订单信息
        /// <summary>
        /// 押金审核人
        /// </summary>
        public int DepositUID { get; set; }
        /// <summary>
        /// 发货审核人
        /// </summary>
        public int ReceiptUID { get; set; }
        /// <summary>
        /// 付款审核人
        /// </summary>
        public int PayUID { get; set; }
        #endregion

        #region 图片上传设置
        /// <summary>
        /// 上传最大数量
        /// </summary>
        public int Maximum { get; set; }
        /// <summary>
        /// 上传最大数量
        /// </summary>
        public string Domain { get; set; }
        #endregion

        /// <summary>
        /// 额外限制
        /// </summary>
        public BankCardExtraLimitResponse BankCardExtraLimitResponse { get; set; }

        /// <summary>
        /// 公司列表
        /// </summary>
        public List<CompanyResponse> CompanyResponse { get; set; }
        /// <summary>
        /// 银行列表
        /// </summary>
        public List<BankInfoResponse> BankInfoResponse { get; set; }
        /// <summary>
        /// 证件列表
        /// </summary>
        public List<DocumentResponse> DocumentResponse { get; set; }
        /// <summary>
        /// 订单列表
        /// </summary>
        public List<OrderRecordResponse> OrderRecordResponse { get; set; }

    }
}
