﻿using System;

namespace FlashPay.Entity.Response.Bank
{
    public class BankInfoResponse
    {
        public String BankCode { set; get; }
        public String BankName { set; get; }
        public String BankFullName { set; get; }
        public String BankEnglishName { set; get; }
        public String BankUrl { set; get; }
        public String BankRemark { set; get; }
        public String BankTel { set; get; }
        public String BankAddress { set; get; }
    }
}
