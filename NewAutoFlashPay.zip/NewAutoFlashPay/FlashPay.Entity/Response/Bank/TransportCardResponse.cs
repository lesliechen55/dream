﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Response.Bank
{
    /// <summary>
    /// 中转卡
    /// </summary>
    public class TransportCardResponse
    {
        /// <summary>
        /// 中转费率
        /// </summary>
        public decimal TransportRate { get; set; }
        /// <summary>
        /// 使用接口生成中转订单
        /// </summary>
        public sbyte ApiTransport { get; set; }
        /// <summary>
        /// 触发中转金额
        /// </summary>
        public decimal LimitAmount { get; set; }
        /// <summary>
        /// 每次中转金额
        /// </summary>
        public decimal LimitTransFerAmount { get; set; }
        /// <summary>
        /// 转入卡类别
        /// </summary>
        public string LimitCardType { get; set; }
        /// <summary>
        /// 预留账户金额
        /// </summary>
        public decimal LimitBalance { get; set; }
        /// <summary>
        /// 转账最大额度
        /// </summary>
        public decimal LimitMaxAmount { get; set; }
        /// <summary>
        /// 转入卡余额
        /// </summary>
        public decimal LimitOrderSideBalance { get; set; }
        /// <summary>
        /// 转入卡银行
        /// </summary>
        public string LimitBankCode { get; set; }
    }
}
