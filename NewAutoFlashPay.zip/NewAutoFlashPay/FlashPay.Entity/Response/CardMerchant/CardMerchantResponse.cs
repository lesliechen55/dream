﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Response.CardMerchant
{
    public class CardMerchantResponse
    {
        public int Cmid { get; set; }
        public string Cmname { get; set; }
        public string Cmcode { get; set; }
        public string Cmcredit { get; set; }
        public sbyte DelayRate { get; set; }
        public string Remark { get; set; }
        public int CardCommissionerUid { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }
        public string ULoginName { get; set; }
        public int CompanyID { set; get; }
    }
}
