﻿using System;

namespace FlashPay.Entity.Response.BankCard
{
    /// <summary>
    /// 额外限制
    /// </summary>
    /// <remarks>immi 2018-09-15 创建</remarks>
    public class BankCardExtraLimitResponse
    {
        /// <summary>
        /// 关闭时间
        /// </summary>
        public DateTime? LimitCloseDate { get; set; }

        /// <summary>
        /// 开启时间
        /// </summary>
        public DateTime? LimitOpenDate { get; set; }

        /// <summary>
        /// 每天执行
        /// </summary>
        public sbyte? LimitRepeat { get; set; }

        /// <summary>
        /// 限制收款金额
        /// </summary>
        public decimal? LimitDepositAmount { get; set; }

        /// <summary>
        /// 转付款
        /// </summary>
        public sbyte? LimitChangetoPay { get; set; }

        /// <summary>
        /// 限制付款金额
        /// </summary>
        public decimal? LimitPayAmount { get; set; }

        /// <summary>
        /// 转收款
        /// </summary>
        public sbyte? LimitChangetoDeposit { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public sbyte? LimitStatus { get; set; }
    }
}
