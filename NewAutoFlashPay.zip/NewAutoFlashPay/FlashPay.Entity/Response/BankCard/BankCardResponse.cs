﻿using FlashPay.Entity.Response.Bank;
using FlashPay.Entity.Response.BankCardExtraLimit;
using FlashPay.Entity.Response.Company;
using FlashPay.Entity.Response.Order;
using FlashPay.Entity.Response.User;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Response.BankCard
{
    public class BankCardResponse
    {
        public int Bcid { get; set; }
        public string OrderNo { get; set; }
        public string BankCode { get; set; }
        public string BankName { get; set; }
        public string CardNumber { get; set; }
        public string SecCardNumber { get; set; }
        public string CardName { get; set; }
        public sbyte CardType { get; set; }
        public sbyte UsingStatus { get; set; }
        public sbyte EnableStatus { get; set; }
        public string LoginName { get; set; }
        public string PasswordLogin { get; set; }
        public string PasswordQuery { get; set; }
        public string PasswordPay { get; set; }
        public string PasswordShield { get; set; }
        public sbyte UsbType { get; set; }
        /// <summary>
        /// 网盾序号
        /// </summary>
        public string UsbSerialNumber { get; set; }
        public string OriginalPassword { get; set; }
        public string AccountBank { get; set; }
        public string DocumentNumber { get; set; }
        public string PhoneNumber { get; set; }
        public decimal PaymentStart { get; set; }
        public decimal PaymentEnd { get; set; }
        public decimal PayFeeRatio { get; set; }
        public decimal DepositFeeRatio { get; set; }
        public sbyte CrossBankPay { get; set; }
        public string DepositType { get; set; }
        public int CompanyId { get; set; }
        public int CompanyNameId { get; set; }
        public string Remark { get; set; }
        public int CreateUid { get; set; }
        public string CreateDate { get; set; }


        public int DepositUID { get; set; }
        public int ReceiptUID { get; set; }

        public List<DocumentResponse> DocumentResponse { get; set; }

        public CompanyResponse CompanyResponse { get; set; }

        public UserInfoResponse UserInfoResponse { get; set; }

        public List<CompanyResponse> CompanyResponseList { get; set; }
        public List<BankInfoResponse> BankInfoResponseList { get; set; }
        public List<AuditingOrderRecordResponse> AuditingOrderRecordResponseList { get; set; }
        public List<BankCardExtraLimitResponse> BankCardExtraLimitList { get; set; }
    }
}
