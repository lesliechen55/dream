﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Response.Bank
{
    /// <summary>
    /// 银行卡
    /// </summary>
    public class BankCardAddOrEditResponse
    {
        /// <summary>
        /// 编号
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 订单
        /// </summary>
        public long OrderNo { get; set; }
        /// <summary>
        /// 银行编号
        /// </summary>
        public string BankInfoId { get; set; }
        /// <summary>
        /// 银行代码
        /// </summary>
        public string BankCode { get; set; }
        /// <summary>
        /// 银行名称
        /// </summary>
        public string BankName { get; set; }
        /// <summary>
        /// 银行卡类型
        /// </summary>
        public sbyte CardType { get; set; }
        /// <summary>
        /// 银行卡号
        /// </summary>
        public string CardNumber { get; set; }
        /// <summary>
        /// 银行副卡号
        /// </summary>
        public string SecCardNumber { get; set; }
        /// <summary>
        /// 登陆名称
        /// </summary>
        public string LoginName { get; set; }
        /// <summary>
        /// 银行卡使用状态
        /// </summary>
        public sbyte UsingStatus { get; set; }
        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        public sbyte EnableStatus { get; set; }
        /// <summary>
        /// 登陆密码
        /// </summary>
        public string PasswordLogin { get; set; }
        /// <summary>
        /// 查询密码
        /// </summary>
        public string PasswordQuery { get; set; }
        /// <summary>
        /// 支付密码
        /// </summary>
        public string PasswordPay { get; set; }
        /// <summary>
        /// 网盾密码
        /// </summary>
        public string PasswordShield { get; set; }
        /// <summary>
        /// 网盾类型
        /// </summary>
        public sbyte UsbType { get; set; }
        /// <summary>
        /// 原始密码
        /// </summary>
        public string OriginalPassword { get; set; }
        /// <summary>
        /// 开户地
        /// </summary>
        public string AccountBank { get; set; }
        /// <summary>
        /// 证件号码
        /// </summary>
        public string DocumentNumber { get; set; }
        /// <summary>
        /// 手机号码
        /// </summary>
        public string PhoneNumber { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}
