﻿
namespace FlashPay.Entity.Response.BankCard
{
    /// <summary>
    /// 
    /// </summary>
    public class DocumentResponse
    {
        /// <summary>
        /// 域名
        /// </summary>
        public string Domain { get; set; }

        /// <summary>
        /// 图片地址
        /// </summary>
        public string URL { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public string Sort { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        public string Description { get; set; }
    }
}
