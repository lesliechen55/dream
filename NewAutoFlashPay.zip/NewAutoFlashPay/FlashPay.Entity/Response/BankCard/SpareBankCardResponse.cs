﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Response.BankCard
{
    /// <summary>
    /// 
    /// </summary>
    public class SpareBankCardResponse
    {
        public int CompanyId { get; set; }

        public int Bcid { get; set; }

        public string OrderNo { get; set; }
        public string BankName { get; set; }
        public string CardNumber { get; set; }
        public string SecCardNumber { get; set; }
        public string CardName { get; set; }
        public sbyte CardType { get; set; }
        public sbyte UsingStatus { get; set; }
        public sbyte EnableStatus { get; set; }
        public string LoginName { get; set; }
        public string PasswordLogin { get; set; }
        public string PasswordQuery { get; set; }
        public string PasswordPay { get; set; }
        public string PasswordShield { get; set; }
        public sbyte UsbType { get; set; }
        public string OriginalPassword { get; set; }
        public string AccountBank { get; set; }
        public string DocumentNumber { get; set; }
        public string PhoneNumber { get; set; }
        public decimal PaymentStart { get; set; }
        public decimal PaymentEnd { get; set; }
        public string PayFeeRatio { get; set; }
        public string DepositFeeRatio { get; set; }
        public sbyte CrossBankPay { get; set; }
        public string DepositType { get; set; }
        
        public string Remark { get; set; }
        public int CreateUid { get; set; }
        public string CreateName { get; set; }
        public string CreateDate { get; set; }

        /// <summary>
        /// 作废时间
        /// </summary>
        public DateTime? UpdateDate { get; set; }
        /// <summary>
        /// 收货审核人
        /// </summary>
        public int ReceiptUID { get; set; }

        /// <summary>
        /// 付款审核人
        /// </summary>
        public int PayUID { get; set; }

        ///变化后类型
        public sbyte AfterCardType { get; set; }
    }
}
