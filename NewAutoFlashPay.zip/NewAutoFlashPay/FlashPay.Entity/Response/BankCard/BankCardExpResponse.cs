﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.Entity.Response.BankCard
{
    /// <summary>
    /// 银行卡
    /// </summary>
    public class BankCardExpResponse
    {
        /// <summary>
        /// 订单号
        /// </summary>
        public string 订单号 { get; set; }

        /// <summary>
        /// 银行名称
        /// </summary>
        public string 银行名称 { get; set; }

        /// <summary>
        /// 银行卡用户名
        /// </summary>
        public string 银行卡用户名 { get; set; }

        /// <summary>
        /// 银行卡号
        /// </summary>
        public string 银行卡号 { get; set; }

        /// <summary>
        /// 银行副卡号
        /// </summary>
        public string 银行副卡号 { get; set; }

        /// <summary>
        /// 银行卡类型
        /// </summary>
        public string 银行卡类型
        {
            get;
            set;
            
            //set
            //{
            //    switch (银行卡类型)
            //    {
            //        case "1":
            //            银行卡类型 = "收款卡";
            //            break;
            //        case "2":
            //            银行卡类型 = "中转卡";
            //            break;
            //        case "3":
            //            银行卡类型 = "付款卡";
            //            break;
            //        case "4":
            //            银行卡类型 = "备用卡";
            //            break;
            //        default:
            //            银行卡类型 = "银行卡";
            //            break;
            //    }
            //    //银行卡类型 = value;
            //}
        }

        /// <summary>
        /// 银行卡使用状态
        /// </summary>
        public sbyte 银行卡使用状态 { get; set; }

        /// <summary>
        /// 银行卡启用状态
        /// </summary>
        public sbyte 银行卡启用状态 { get; set; }

        /// <summary>
        /// 建立人员
        /// </summary>
        public string 建立人员 { get; set; }

        /// <summary>
        /// 建立时间
        /// </summary>
        public string 建立时间 { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string 备注 { get; set; }

        public int CompanyId { get; set; }

    }
}
