﻿using FlashPay.CardManagement.ViewModels.Shared;
using System;
using System.ComponentModel.DataAnnotations;

namespace FlashPay.CardManagement.ViewModels.Order
{
    public class OrderRecordDetailViewModel<T> : BaseViewModel<T>
    {
        public Int32 DetailID { set; get; }

        [Required]
        public Int64 OrderNo{ set; get; }

        //[Required]
        //public Int32 CMID { set; get; }

        [Required]
        public String BankCode { set; get; }

        //[Required]
        //[Range(1, Int32.MaxValue)]
        public Int32 OrderQuantity { set; get; }

        //[Required]
        //[DataType(DataType.Currency)]
        public Decimal UnitPrice { set; get; }

        [Required]
        //[Range(1, Int32.MaxValue)]
        public Int32 ActualQuantity { set; get; }

        [Required]
        [DataType(DataType.Currency)]
        public Decimal ActualUnitPrice { set; get; }

        public String Remark { set; get; }

        public Int32 CreateUID { set; get; }

        public DateTime CreateDate { set; get; }
    }
}
