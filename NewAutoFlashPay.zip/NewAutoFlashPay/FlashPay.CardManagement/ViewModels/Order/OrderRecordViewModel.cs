﻿using FlashPay.CardManagement.ViewModels.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;

namespace FlashPay.CardManagement.ViewModels.Order
{
    public class OrderRecordViewModel<T> : BaseViewModel<T>
    {
        public Int64? OrderNo { set; get; }
        
        [Required]
        [DataType(DataType.Date)]
        public DateTime? OrderDate { set; get; }
        public DateTime? EndOrderDate { set; get; }

        public Int32 DepositUID { set; get; }

        //[Required]
        [DataType(DataType.Date)]
        public DateTime? DepositDate { set; get; }

        [Required]
        [DataType(DataType.Currency)]
        public Decimal DepositAmount { set; get; }

        //[Required]
        [DataType(DataType.Date)]
        public DateTime? ReceiptDate { set; get; }

        public Int32 PayUID { set; get; }

        //[Required]
        [DataType(DataType.Date)]
        public DateTime? PayDate { set; get; }
        public DateTime? EndPayDate { set; get; }

        [DataType(DataType.Currency)]
        public Decimal PayAmount { set; get; }

        public String PayUserName { set; get; }

        public Int32 CreateUID { set; get; }

        public DateTime? CreateDate { set; get; }

        public Int32? ReceiptUID { set; get; }         //收款审核人
        public Int32 CMID { set; get; }                //卡商ID
        public String CMName { get; set; }             //卡商名称
        public Int32 Status { set; get; }              //订单状态
        public String DeliveryNo { set; get; }        //快递单号
        public String PayCardNumber { set; get; }    //尾款收款卡号
        public String DepositCardNumber { set; get; }//押金收款卡号
    }
}
