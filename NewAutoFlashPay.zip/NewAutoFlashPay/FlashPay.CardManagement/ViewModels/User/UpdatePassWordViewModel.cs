﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace FlashPay.CardManagement.ViewModels.User
{
    /// <summary>
    /// 修改密码
    /// </summary>
    public class UpdatePassWordViewModel
    {
        /// <summary>
        /// 旧密码
        /// </summary>
        [Description("旧密码")]
        [StringLength(50, MinimumLength = 6, ErrorMessage = "旧密码名称长度必须介于 {2} 和 {1} 之间")]
        public string OldPassword { get; set; }
        /// <summary>
        /// 新密码
        /// </summary>
        [Description("新密码")]
        [StringLength(50, MinimumLength = 6, ErrorMessage = "新密码长度必须介于 {2} 和 {1} 之间")]
        public string NewPassword { get; set; }
        /// <summary>
        /// 确认新密码
        /// </summary>
        [Description("确认新密码")]
        [StringLength(50, MinimumLength = 6, ErrorMessage = "确认密码长度必须介于 {2} 和 {1} 之间")]
        public string ConfirmNewPassword { get; set; }
    }

    /// <summary>
    /// 重设密码
    /// </summary>
    public class ResetPassWordViewModel
    {
        public int UID { get; set; }
        /// <summary>
        /// 新密码
        /// </summary>
        [Description("新密码")]
        [StringLength(50, MinimumLength = 6, ErrorMessage = "新密码长度必须介于 {2} 和 {1} 之间")]
        public string NewPassword { get; set; }
        /// <summary>
        /// 确认新密码
        /// </summary>
        [Description("确认新密码")]
        [StringLength(50, MinimumLength = 6, ErrorMessage = "确认密码长度必须介于 {2} 和 {1} 之间")]
        public string ConfirmNewPassword { get; set; }
    }
}
