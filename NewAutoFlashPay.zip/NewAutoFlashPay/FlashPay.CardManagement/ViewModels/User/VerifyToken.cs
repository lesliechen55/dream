﻿using System;
using System.ComponentModel;

namespace FlashPay.CardManagement.ViewModels.User
{
    public class VerifyToken
    {
        /// <summary>
        /// Token
        /// </summary>
        [Description("Token")]
        public string Token { get; set; }
    }
}
