﻿using System;
using System.Collections.Generic;

namespace FlashPay.CardManagement.ViewModels.User
{
    public class UserDataKeepViewModel
    {
        public Int32 UserID { set; get; }
        public Int32 CompanyID { set; get; }
        /// <summary>
        /// 菜单类型
        /// </summary>
        public Int32 MType { set; get; }
        public String UserName { set; get; }
        public String CompanyName { get; set; }
        public String Host { set; get; }
        /// <summary>
        /// 平台类型
        /// </summary>
        public int PlatformType { set; get; }
        /// <summary>
        /// 权限
        /// </summary>
        public List<String> UserPermission { set; get; }
    }
}
