﻿using FlashPay.CardManagement.ViewModels.Shared;
using FlashPay.Entity.Response.User;
using System.ComponentModel;

namespace FlashPay.CardManagement.ViewModels.User
{
    /// <summary>
    /// 登录
    /// </summary>
    public class AuthorizeViewModel
    {
        /// <summary>
        /// 帐号名称
        /// </summary>
        [Description("帐号名称")]
        public string Account { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        [Description("密码")]
        public string Password { get; set; }

        /// <summary>
        /// 验证码
        /// </summary>
        [Description("验证码")]
        public string VerifyCode { get; set; }
    }
}
