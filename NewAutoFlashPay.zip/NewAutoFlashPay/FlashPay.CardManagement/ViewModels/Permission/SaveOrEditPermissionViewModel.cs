﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlashPay.CardManagement.ViewModels.Permission
{
    public class SaveOrEditPermissionViewModel
    {
        public int Pid { get; set; }
        public int? PParent { get; set; }

        [DisplayName("权限名称")]
        [StringLength(40, MinimumLength = 3,ErrorMessage = "权限名称长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "权限名称由中文、英文、数字包括下划线")]
        public string PName { get; set; }

        [DisplayName("权限代码")]
        [StringLength(40, MinimumLength = 3, ErrorMessage = "权限代码长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "权限代码由中文、英文、数字包括下划线")]
        public string PCode { get; set; }

        public int NodeType { get; set; }
        public int SortNo { get; set; }
        public sbyte Hide { get; set; }
    }
}
