﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlashPay.CardManagement.ViewModels.Permission
{
    public class PermissionViewModel
    {
        public PermissionViewModel()
        {
            CanYajinCardNo = false;
            CanWeiKuanCardNo = false;
            CanDepositAmount = false;
            CanPayAmount = false;
            CanViewAmount = false;
            CanReceipt = false;
            CanCompletedOrder = false;
            CanUndoneOrder = false;
        }
        public Boolean CanYajinCardNo { set; get; }    //是否可以查看押金收款卡号
        public Boolean CanWeiKuanCardNo { set; get; }  //是否可以查看尾款收款卡号
        public Boolean CanDepositAmount { set; get; }  //是否可以查看押金金额(押金审核)
        public Boolean CanPayAmount { set; get; }      //是否可以查看付款金额(付款审核)
        public Boolean CanReceipt { set; get; }        //是否可以确认收货
        public Boolean CanCompletedOrder { set; get; } //是否可以查看已完成订单信息
        public Boolean CanUndoneOrder { set; get; }    //是否可以查看未完成订单信息
        public Boolean CanViewAmount { get; set; }     //是否可以查看所有订单相关金额
    }

    public class PermissionCompanyViewModel
    {

        public PermissionCompanyViewModel()
        {
            CanDepositView = false;
            CanPaymentView = false;
            CanTransferView = false;
        }

        /// <summary>
        /// 公司推送接口列表查看(存款)
        /// </summary>
        public Boolean CanDepositView { set; get; }

        /// <summary>
        /// 公司推送接口列表查看(付款)
        /// </summary>
        public Boolean CanPaymentView { set; get; }

        /// <summary>
        /// 公司推送接口列表查看(中转)
        /// </summary>
        public Boolean CanTransferView { set; get; }
    }
}
