﻿using FlashPay.CardManagement.ViewModels.Permission;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlashPay.CardManagement.ViewModels.Shared
{
    public class BaseViewModel<T>
    {
        public BaseViewModel()
        {
            PageIndex = 1;
            CurrentPageIndex = 1;
            PageSize = 50;
            Success = false;
        }

        public Int32 TotalCount { get; set; }
        public Int32 PageIndex { get; set; }
        public Int32 CurrentPageIndex { get; set; }
        public Int32 PageSize { get; set; }

        public String Code { get; set; }
        public String Message { get; set; }

        public String SuccessMessage { get; set; }
        public String ErrorMessage { get; set; }

        public Boolean Success { get; set; }

        public T Result { get; set; }

        public PermissionViewModel Permisss { get; set; }
        public PermissionCompanyViewModel Permission { get; set; }

        public Int32 LoginUserID { get; set; }           //当前登陆用户ID
    }
}
