﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlashPay.CardManagement.ViewModels.Role
{
    public class AuthorizeViewModel
    {
        public int AuthRid { get; set; }
        public int AuthPid { get; set; }
        public sbyte AuthType { get; set; }
    }
}
