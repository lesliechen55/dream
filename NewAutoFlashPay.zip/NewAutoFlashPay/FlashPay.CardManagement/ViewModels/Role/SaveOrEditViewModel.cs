﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlashPay.CardManagement.ViewModels.Role
{
    /// <summary>
    /// 角色
    /// </summary>
    public class SaveOrEditViewModel
    {
        public int RId { get; set; }

        public int RCompanyId { get; set; }

        [DisplayName("角色名称")]
        [StringLength(40, MinimumLength = 3, ErrorMessage = "角色名称长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "角色名称由中文、英文、数字包括下划线")]
        public string RName { get; set; }

        public DateTime CreateDate { get; set; }
        public sbyte RStatus { get; set; }
    }
}
