﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlashPay.CardManagement.ViewModels.BankCard
{
    public class BankCardViewModel
    {
        public int Bcid { get; set; }

        public long OrderNo { get; set; }

        public string BankCode { get; set; }

        public string BankName { get; set; }
        /// <summary>
        /// 银行卡号
        /// </summary>
        [DisplayName("银行卡号")]
        [StringLength(90, MinimumLength = 6, ErrorMessage = "银行卡号长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[0-9]*$", ErrorMessage = "请输入正确的银行卡号")]
        public string CardNumber { get; set; }

        public string SecCardNumber { get; set; }

        /// <summary>
        /// 银行卡用户名
        /// </summary>
        [DisplayName("银行卡用户名")]
        [StringLength(40, MinimumLength = 1, ErrorMessage = "银行卡用户名长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "银行卡用户名由中文、英文、数字包括下划线")]
        public string CardName { get; set; }

        public sbyte CardType { get; set; }

        public sbyte UsingStatus { get; set; }

        public sbyte EnableStatus { get; set; }

        /// <summary>
        /// 登录名称
        /// </summary>
        [DisplayName("登录名称")]
        [StringLength(118, MinimumLength = 3, ErrorMessage = "登录名称长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "登录名称由中文、英文、数字包括下划线")]
        public string LoginName { get; set; }

        /// <summary>
        /// 登录密码
        /// </summary>
        public string PasswordLogin { get; set; }

        /// <summary>
        /// 查询密码
        /// </summary>
        public string PasswordQuery { get; set; }

        /// <summary>
        /// 支款密码
        /// </summary>
        public string PasswordPay { get; set; }

        /// <summary>
        /// 网盾密码
        /// </summary>
        public string PasswordShield { get; set; }

        /// <summary>
        /// 网盾类型
        /// </summary>
        public sbyte UsbType { get; set; }

        /// <summary>
        /// 网盾序号
        /// </summary>
        public string UsbSerialNumber { get; set; }

        /// <summary>
        /// 原始密码
        /// </summary>
        public string OriginalPassword { get; set; }

        /// <summary>
        /// 开户地
        /// </summary>
        public string AccountBank { get; set; }

        /// <summary>
        /// 证件号码
        /// </summary>
        public string DocumentNumber { get; set; }

        /// <summary>
        /// 手机号码
        /// </summary>
        [DisplayName("手机号码")]
        [StringLength(11, MinimumLength = 0, ErrorMessage = "手机号码长度必须介于 {2} 和 {1}")]
        [RegularExpression(@"^1\d{10}$", ErrorMessage = "请输入正确的手机号码")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// 付款区间起
        /// </summary>
        [DisplayName("付款区间起")]
        //[StringLength(16, MinimumLength = 1, ErrorMessage = "付款区间起长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^\d{1,12}(?:\.\d{1,4})?$", ErrorMessage = "付款区间起必须为金额，最多保留4位小数")]
        public decimal PaymentStart { get; set; }

        /// <summary>
        /// 付款区间迄
        /// </summary>
        [DisplayName("付款区间迄")]
        //[StringLength(16, MinimumLength = 1, ErrorMessage = "付款区间起长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^\d{1,12}(?:\.\d{1,4})?$", ErrorMessage = "付款区间起必须为金额，最多保留4位小数")]
        public decimal PaymentEnd { get; set; }

        /// <summary>
        /// 付款费率
        /// </summary>
        [DisplayName("付款费率")]
        //[StringLength(12, MinimumLength = 1, ErrorMessage = "收款费率长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^\d{1,4}(?:\.\d{1,8})?$", ErrorMessage = "收款费率必须为金额，最多保留8位小数")]
        public decimal PayFeeRatio { get; set; }

        /// <summary>
        /// 收款费率 
        /// </summary>
        [DisplayName("收款费率")]
        //[StringLength(12, MinimumLength = 1, ErrorMessage = "收款费率长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^\d{1,4}(?:\.\d{1,8})?$", ErrorMessage = "收款费率必须为金额，最多保留8位小数")]
        public decimal DepositFeeRatio { get; set; }

        /// <summary>
        /// 跨行转账
        /// </summary>
        public sbyte CrossBankPay { get; set; }

        /// <summary>
        /// 存款等级
        /// </summary>
        public string DepositType { get; set; }

        /// <summary>
        /// 公司ID
        /// </summary>
        public int CompanyId { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        public int CreateUid { get; set; }

        public DateTime CreateDate { get; set; }
    }
}
