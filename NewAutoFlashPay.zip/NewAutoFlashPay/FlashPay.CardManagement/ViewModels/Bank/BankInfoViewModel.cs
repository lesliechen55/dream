﻿using FlashPay.CardManagement.ViewModels.Shared;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace FlashPay.CardManagement.ViewModels.Bank
{
    public class BankInfoViewModel<T> : BaseViewModel<T>
    {
        /// <summary>
        /// 银行代码
        /// </summary>
        [DisplayName("银行代码")]
        [StringLength(40, MinimumLength = 1, ErrorMessage = "银行代码长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "银行代码由中文、英文、数字包括下划线")]
        public String BankCode { set; get; }

        /// <summary>
        /// 银行名称
        /// </summary>
        [DisplayName("银行名称")]
        [StringLength(40, MinimumLength = 1, ErrorMessage = "银行名称长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "银行名称由中文、英文、数字包括下划线")]
        public String BankName { set; get; }

        /// <summary>
        /// 银行全部名称
        /// </summary>
        [DisplayName("银行全部名称")]
        [StringLength(40, MinimumLength = 1, ErrorMessage = "银行全部名称长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "银行全部名称由中文、英文、数字包括下划线")]
        public String BankFullName { set; get; }

        [Required]
        public String BankEnglishName { set; get; }

        [Required]
        public Int32 SortNo { set; get; }

        [Required]
        public String BankUrl { set; get; }

        [Required]
        public String BankRemark { set; get; }

        [Required]
        public String BankTel { set; get; }

        [Required]
        public String BankAddress { set; get; }
    }
}
