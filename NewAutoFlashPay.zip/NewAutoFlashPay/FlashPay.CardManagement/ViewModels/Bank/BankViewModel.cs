﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlashPay.CardManagement.ViewModels.Bank
{
    public class BankViewModel
    {
        /// <summary>
        /// 银行代码
        /// </summary>
        [DisplayName("银行代码")]
        [StringLength(40, MinimumLength = 1, ErrorMessage = "银行代码长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "银行代码由中文、英文、数字包括下划线")]
        public string BankCode { set; get; }

        /// <summary>
        /// 银行名称
        /// </summary>
        [DisplayName("银行名称")]
        [StringLength(40, MinimumLength = 1, ErrorMessage = "银行名称长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "银行名称由中文、英文、数字包括下划线")]
        public string BankName { set; get; }

        /// <summary>
        /// 银行全部名称
        /// </summary>
        [DisplayName("银行全部名称")]
        [StringLength(40, MinimumLength = 1, ErrorMessage = "银行全部名称长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "银行全部名称由中文、英文、数字包括下划线")]
        public string BankFullName { set; get; }

        public string BankEnglishName { set; get; }

        /// <summary>
        /// 排序
        /// </summary>
        [DisplayName("排序")]
        //[StringLength(40, MinimumLength = 1, ErrorMessage = "手机号码长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[0-9]*$", ErrorMessage = "请输入正确的排序号码")]
        public int SortNo { set; get; }

        public string BankUrl { set; get; }

        public string BankRemark { set; get; }

        public string BankTel { set; get; }

        public string BankAddress { set; get; }
    }
}
