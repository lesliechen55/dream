﻿using FlashPay.CardManagement.ViewModels.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FlashPay.CardManagement.ViewModels.Report
{
    public class ReportStatisticsViewModel<T> : BaseViewModel<T>
    {
        public List<Int32> CompanyID { set; get; }
        public List<Int32> BankCardID { set; get; }

        public SByte ReportType { set; get; }

        [DataType(DataType.Date)]
        public DateTime? ReportDate { set; get; }

        [DataType(DataType.Date)]
        public DateTime? EndReportDate { set; get; }
    }
}
