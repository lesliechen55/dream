﻿using FlashPay.CardManagement.ViewModels.Shared;
using System;
using System.ComponentModel.DataAnnotations;

namespace FlashPay.CardManagement.ViewModels.Company
{
    public class CompanyViewModel<T> : BaseViewModel<T>
    {
        public Int32 CompanyID{ set; get; }
        public Int32 CompanyPID{ set; get; }
        [Required]
        public String CompanyName{ set; get; }
        public SByte CompanyStatus { set; get; }
        public SByte NotCompanyStatus { set; get; }
        public String CompanyBossName{ set; get; }
        public String CompanyTel { set; get; }
        public String CompanyAddress { set; get; }
        public String CompanyNameEN { set; get; }
        public Int32 CreateUID { set; get; }
        public DateTime CreateDate{ set; get; }
        public Int32? UpdateUID { set; get; }
        public DateTime? UpdateDate { set; get; }
        public Decimal? DepositRate{ set; get; }

        public Decimal? PayRate { set; get; }
        public Decimal? TransportRate { set; get; }
        public Int32 Level { set; get; }
    }
}
