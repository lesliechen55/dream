﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlashPay.CardManagement.ViewModels.Menu
{
    /// <summary>
    /// 菜单保存参数
    /// </summary>
    public class SaveMenuRequestViewModel
    {
        /// <summary>
        /// 编号
        /// </summary>
        public int? Mid { get; set; }

        /// <summary>
        /// 父ID
        /// </summary>
        public int? MParent { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        [DisplayName("菜单名称")]
        [StringLength(40, MinimumLength = 3, ErrorMessage = "菜单名称长度必须介于 {2} 和 {1} 之间")]
        [RegularExpression(@"^[\u4E00-\u9FA5A-Za-z0-9_]+$", ErrorMessage = "菜单名称由中文、英文、数字包括下划线")]
        public string MName { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        [Description("地址")]
        [StringLength(120, MinimumLength = 0, ErrorMessage = "菜单地址长度必须介于 {2} 和 {1} 之间")]
        public string MUrl { get; set; }

        /// <summary>
        /// 节点类型
        /// </summary>
        public int? NodeType { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        [Description("排序")]
        [RegularExpression(@"[0-9]{1,4}", ErrorMessage = "只能为正整数")]
        public int SortNo { get; set; }

        /// <summary>
        /// 功能分类
        /// </summary>
        public int MType { get; set; }

        /// <summary>
        /// 隐藏
        /// </summary>
        public sbyte Hide { get; set; }
    }
}
