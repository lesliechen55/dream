﻿using System;
using System.Collections.Generic;

namespace FlashPay.CardManagement.ViewModels.Menu
{
    /// <summary>
    /// 菜单
    /// </summary>
    public class MenuViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }

        public List<ChildMenu> ChildMenus;
    }

    public class ChildMenu
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
    }
}
