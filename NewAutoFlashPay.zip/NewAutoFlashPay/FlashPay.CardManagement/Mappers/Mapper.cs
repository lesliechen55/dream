﻿using FlashPay.CardManagement.ViewModels.Bank;
using FlashPay.CardManagement.ViewModels.Company;
using FlashPay.CardManagement.ViewModels.Order;
using FlashPay.CardManagement.ViewModels.Report;
using FlashPay.CardManagement.ViewModels.Shared;
using FlashPay.CardManagement.ViewModels.User;
using FlashPay.Entity.Request.Bank;
using FlashPay.Entity.Request.Company;
using FlashPay.Entity.Request.Order;
using FlashPay.Entity.Request.Report;
using FlashPay.Entity.Response.User;
using System;

namespace FlashPay.CardManagement.Mappers
{
    public static class Mapper
    {
        public static BaseViewModel<T> MapperResponse<T>(OrderRecordViewModel<T> model)
        {
            BaseViewModel<T> _model = model;
            return MapperResponse(_model);
        }

        public static BaseViewModel<T> MapperResponse<T>(OrderRecordDetailViewModel<T> model)
        {
            BaseViewModel<T> _model = model;
            return MapperResponse(_model);
        }

        public static BaseViewModel<T> MapperResponse<T>(CompanyViewModel<T> model)
        {
            BaseViewModel<T> _model = model;
            return MapperResponse(_model);
        }

        public static BaseViewModel<T> MapperResponse<T>(BankInfoViewModel<T> model)
        {
            BaseViewModel<T> _model = model;
            return MapperResponse(_model);
        }

        public static BaseViewModel<TokenResponse> MapperResponse<T>(AuthorizeViewModel model)
        {
            return MapperResponse<TokenResponse>(model);
        }

        public static BaseViewModel<T> MapperResponse<T>(BaseViewModel<T> model)
        {
            BaseViewModel<T> respoonse = new BaseViewModel<T>();
            respoonse.TotalCount = model.TotalCount;
            respoonse.PageIndex = model.PageIndex;
            respoonse.PageSize = model.PageSize;
            if (model.Success)
            {
                respoonse.SuccessMessage = "操作成功";
            }
            else
            {
                respoonse.ErrorMessage = model.Message == null ? "操作失败" : model.Message;
            }
            //respoonse.Message = model.Message;
            respoonse.Success = model.Success;
            respoonse.Result = model.Result;
            respoonse.Code = model.Code;
            respoonse.LoginUserID = model.LoginUserID;//当前登陆用户ID
            //权限
            respoonse.Permisss = model.Permisss;
            respoonse.Permission = model.Permission;
            return respoonse;
        }

        public static OrderRecordRequest<T2> MapperRequest<T, T2>(OrderRecordViewModel<T> model)
        {
            OrderRecordRequest<T2> request = new OrderRecordRequest<T2>();
            request.OrderNo = model.OrderNo;
            request.OrderDate = model.OrderDate;
            request.EndOrderDate = model.EndOrderDate;
            request.DepositUID = model.DepositUID;
            request.DepositDate = model.DepositDate;
            request.DepositAmount = model.DepositAmount;
            request.ReceiptDate = model.ReceiptDate;
            request.PayUID = model.PayUID;
            request.PayDate = model.PayDate;
            request.EndPayDate = model.EndPayDate;
            request.PayUserName = model.PayUserName;
            request.CreateUID = model.CreateUID;
            request.CreateDate = model.CreateDate;
            //新加的字段
            request.CMName = model.CMName;
            request.CMID = model.CMID;
            request.Status = model.Status;
            request.PayCardNumber = model.PayCardNumber;
            request.DeliveryNo = model.DeliveryNo;
            request.DepositCardNumber = model.DepositCardNumber;
            request.ReceiptUID = model.ReceiptUID;
            //新加的字段end 
            request.PageIndex = model.PageIndex;
            request.PageSize = model.PageSize;
            return request;
        }

        public static OrderRecordDetailRequest<T2> MapperRequest<T, T2>(OrderRecordDetailViewModel<T> model)
        {
            OrderRecordDetailRequest<T2> request = new OrderRecordDetailRequest<T2>();
            request.DetailID = model.DetailID;
            request.OrderNo = model.OrderNo;
            request.BankCode = model.BankCode;
            request.OrderQuantity = model.OrderQuantity;
            request.UnitPrice = model.UnitPrice;
            request.ActualQuantity = model.ActualQuantity;
            request.ActualUnitPrice = model.ActualUnitPrice;
            request.Remark = model.Remark;
            request.CreateUID = model.CreateUID;
            request.CreateDate = model.CreateDate;
            request.TotalCount = model.TotalCount;
            request.PageIndex = model.PageIndex;
            request.PageSize = model.PageSize;

            return request;
        }

        public static CompanyRequest<T2> MapperRequest<T, T2>(CompanyViewModel<T> model)
        {
            CompanyRequest<T2> request = new CompanyRequest<T2>();
            request.CompanyID = model.CompanyID;
            request.CompanyPID = model.CompanyPID;
            request.CompanyName = model.CompanyName;
            request.CompanyStatus = model.CompanyStatus;
            request.NotCompanyStatus = model.NotCompanyStatus;
            request.CompanyBossName = model.CompanyBossName;
            request.CompanyTel = model.CompanyTel;
            request.CompanyAddress = model.CompanyAddress;
            request.CompanyNameEN = model.CompanyNameEN;
            request.CreateUID = model.CreateUID;
            request.CreateDate = model.CreateDate;
            request.UpdateUID = model.UpdateUID;
            request.UpdateDate = model.UpdateDate;
            request.DepositRate = model.DepositRate;
            request.TransportRate = model.TransportRate;
            request.PayRate = model.PayRate;
            request.PageIndex = model.PageIndex;
            request.PageSize = model.PageSize;
            request.Level = model.Level;

            return request;
        }

        public static BankInfoRequest<T2> MapperRequest<T, T2>(BankInfoViewModel<T> model)
        {
            BankInfoRequest<T2> request = new BankInfoRequest<T2>();
            request.BankCode = model.BankCode;
            request.BankName = model.BankName;
            request.BankFullName = model.BankFullName;
            request.BankEnglishName = model.BankEnglishName;
            request.SortNo = model.SortNo;
            request.BankUrl = model.BankUrl;
            request.BankRemark = model.BankRemark;
            request.BankTel = model.BankTel;
            request.BankAddress = model.BankAddress;

            return request;
        }

        //public static ReportStatisticsRequest<T2> MapperRequest<T, T2>(ReportStatisticsViewModel<T> model)
        //{
        //    ReportStatisticsRequest<T2> request = new ReportStatisticsRequest<T2>();
        //    request.CompanyID = model.CompanyID;
        //    request.BankCardID = model.BankCardID;
        //    request.ReportType = model.ReportType;
        //    request.ReportDate = model.ReportDate;
        //    request.EndReportDate = model.EndReportDate;

        //    return request;
        //}
    }
}
