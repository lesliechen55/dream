﻿function getParams() {
    var params = {};

    var companyName = $("input[name='companyName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(companyName)) {
        params.companyName = companyName;
    }

    var orderNo = $("input[name='orderNo']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(orderNo)) {
        params.orderNo = orderNo;
    }

    params.startTime = $("input[name='startTime']").val();
    params.endTime = $("input[name='endTime']").val();

    var clientBankName = $("input[name='clientBankName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(clientBankName)) {
        params.clientBankName = clientBankName;
    }

    var clientAccountName = $("input[name='clientAccountName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(clientAccountName)) {
        params.clientAccountName = clientAccountName;
    }
    return params;
}

function doSearch() {

    FlashPay.UI.DataGrid({
        ctrId: 'easyui-treegrid',
        url: '/Payment/recordreal',
        queryParams: getParams(),
        pagination: true,
        rownumbers: true,
        singleSelect: true,
        pageSize: 50,
        pageList: [50, 200, 500, 1000],
        height: $(window).height() - 70,
        idField: 'orderNo',
        frozenColumns: [[
            { field: 'orderNo', title: '订单号', width: 150, align: 'left' },
            { field: 'clientOrderNo', title: '实际订单号', width: 200, align: 'left' },
            { field: 'companyName', title: '公司名称', width: 100, align: 'left' },
            { field: 'bankName', title: '银行名称', width: 100, align: 'left' },
            { field: 'cardName', title: '付款卡用户名', width: 100, align: 'left' }
        ]],
        columns: [[
            {
                field: 'cardNumber', title: '银行卡号', width: 125,align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.SubCardNumber(val);
                }
            },
            {
                field: 'afterBalance', title: '余额', width: 75, align: 'right',
                formatter: function (val, row) {
                    return '<span class="bold">{0}</span>'.format(val)
                }
            },
            {
                field: 'amount', title: '付款金额', width: 75, align: 'right',
                formatter: function (val, row) {
                    return '<span class="bold">{0}</span>'.format(val)
                }
            },
            {
                field: 'operatingDate', title: '付款时间', width: 130, align: 'left',
                formatter: function (val, row) {
                    var result = "";
                    if (!FlashPay.Util.isNullOrEmptySpance(val)) {
                        result = val.replace("T", " ");
                    }
                    return result;
                }
            },
            { field: 'clientBankName', title: '客户银行', width: 200, align: 'left' },
            { field: 'clientAccountName', title: '客户姓名', width: 100, align: 'left' },
            {
                field: 'clientCardNumber', title: '客户卡号', width: 125, align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.SubCardNumber(val);
                }
            },
            {
                field: 'matchOrderNo',
                title: '已匹配单号',
                width: 150,
                align: 'left',
                formatter: function (val, row) {
                    var result = "未匹配";
                    if (!FlashPay.Util.isNullOrEmptySpance(val)) {
                        result = val;
                    }
                    return result;
                }
            },
            { field: 'remark', title: '备注', width: 200, align: 'left' },
            { field: 'vmClientID', title: '机器ID', width: 250, align: 'left' }
        ]]
    })
}