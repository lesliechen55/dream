﻿function getParams() {
    var params = {};

    var companyName = $("input[name='companyName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(companyName)) {
        params.companyName = companyName;
    }

    var orderNo = $("input[name='orderNo']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(orderNo)) {
        params.orderNo = orderNo;
    }

    params.startTime = $("input[name='startTime']").val();
    params.endTime = $("input[name='endTime']").val();

    return params;
}

function doSearch() {

    emptyCompanyId();

    FlashPay.UI.DataGrid({
        ctrId: 'easyui-treegrid',
        url: '/Transfer/TransferCardRecord',
        queryParams: getParams(),
        pagination: true,
        rownumbers: true,
        singleSelect: true,
        pageSize: 50,
        pageList: [50, 200, 500, 1000],
        height: $(window).height() - 70,
        idField: 'orderNo',
        frozenColumns: [[
            { field: 'orderNo', title: '订单号', width: 175, align: 'left' },
            { field: 'companyName', title: '公司名称', width: 100, align: 'left' },
            { field: 'withdrawalOrderNo', title: '中转单号', width: 200, align: 'left' },
            { field: 'bankName', title: '中转银行', width: 100, align: 'left' },
            { field: 'cardName', title: '中转名称', width: 100, align: 'left' },
            { field: 'cardNumber', title: '中转卡号', width: 150, align: 'left' },
        ]],
        columns: [[
            {
                field: 'withdrawalAmount',
                title: '中转金额',
                width: 75,
                align: 'right',
                formatter: function (val, row) {
                    return '<span class="bold">{0}</span>'.format(val)
                }
            },
            {
                field: 'transportDate',
                title: '中转时间',
                width: 150,
                align: 'left',
                formatter: function (val, item) {
                    if (item.paymentStatus == 3 || item.paymentStatus == 4) {
                        return FlashPay.Util.FormatDate(item.readDate);
                    } else {
                        return FlashPay.Util.FormatDate(val);
                    }
                }
            },
            {
                field: 'transportStatus',
                title: '中转结果',
                width: 200,
                align: 'left',
                formatter: function (val, item) {
                    var result = '';
                    if (val == 1) {
                        result = '<span class="bold">未付款</span>';
                    } else if (val == 2) {
                        result = '<span class="green bold">付款成功</span>';
                    } else if (val == 3) {
                        result = '<span class="red bold">付款失败</span>';
                    } else if (val == 4) {
                        result = '<span class="bold">付款中</span><a class="btn btn-primary btn-sm" data-confirm="{0}<br> 确定要 <span class=red> 重置</span > 该记录？" data-href="/Transfer/TransferCardRecordReset?orderNo={0}">重置</a>'.format(item.orderNo);
                    } else if (val == 5)  {
                        result = '<span class="bold">异常</span>';
                    }
                    return result;
                }
            },
            {
                field: 'noticeStatus',
                title: '通知状态',
                width: 125,
                align: 'left',
                formatter: function (val, item) {
                    var result = "";
                    if (val == 1) {
                        result = '<span class="bold">未通知</span>';
                    } else if (val == 2) {
                        result = '<span class="green bold">通知成功</span>';
                    } else if (val == 3) {
                        result = '<span class="red bold">通知失败</span>';
                    } else {
                        result = '<span class="bold">通知中</span>';
                    }
                    return result;
                }
            },
            {
                field: 'noticeLastDate',
                title: '通知时间',
                width: 150,
                align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.FormatDate(val)
                }
            },
            { field: 'withdrawalAccountName', title: '客户姓名', width: 150, align: 'left' },
            { field: 'withdrawalBankName', title: '客户银行', width: 150, align: 'left' },
            { field: 'withdrawalCardNumber', title: '客户卡号', width: 200, align: 'left' },
            {
                field: 'createDbdate',
                title: '创建时间',
                width: 150,
                align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.FormatDate(val)
                }
            },
        ]]
    })
}