﻿function getParams() {
    var params = {};

    var companyName = $("input[name='companyName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(companyName)) {
        params.companyName = companyName;
    }

    var cardName = $("input[name='cardName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(cardName)) {
        params.cardName = cardName;
    }

    var startAmount = $("input[name='startAmount']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(startAmount)) {
        params.startAmount = startAmount;
    }

    var endAmount = $("input[name='endAmount']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(endAmount)) {
        params.endAmount = endAmount;
    }

    var clientAccountName = $("input[name='clientAccountName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(clientAccountName)) {
        params.clientAccountName = clientAccountName;
    }

    params.startTime = $("input[name='startTime']").val();
    params.endTime = $("input[name='endTime']").val();
    return params;
}

function doSearch() {

    FlashPay.UI.DataGrid({
        ctrId: 'easyui-treegrid',
        url: '/Payment/ReceiptList',
        queryParams: getParams(),
        pagination: true,
        rownumbers: true,
        singleSelect: true,
        pageSize: 50,
        pageList: [50, 200, 500, 1000],
        height: $(window).height() - 70,
        idField: 'orderNo',
        frozenColumns: [[
            { field: 'orderNo', title: '订单号', width: 150, align: 'left' },
            { field: 'clientOrderNo', title: '实际订单号', width: 200, align: 'left' },
            { field: 'companyName', title: '公司名称', width: 100, align: 'left' },
            { field: 'bankName', title: '银行名称', width: 100, align: 'left' },
            { field: 'cardName', title: '收款卡用户名', width: 100, align: 'left' }
        ]],
        columns: [[
            {
                field: 'cardNumber', title: '银行卡号', width: 125, align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.SubCardNumber(val);
                }
            },
            {
                field: 'afterBalance', title: '余额', width: 75, align: 'right',
                formatter: function (val, row) {
                    return '<span class="bold">{0}</span>'.format(val)
                }
            },
            {
                field: 'amount', title: '收款金额', width: 75, align: 'right',
                formatter: function (val, row) {
                    return '<span class="bold">{0}</span>'.format(val)
                }
            },
            {
                field: 'operatingDate', title: '付款时间', width: 130, align: 'left',
                formatter: function (val, row) {
                    var result = "";
                    if (!FlashPay.Util.isNullOrEmptySpance(val)) {
                        result = val.replace("T", " ");
                    }
                    return result;
                }
            },
            { field: 'clientBankName', title: '客户银行', width: 200, align: 'left' },
            { field: 'clientAccountName', title: '客户姓名', width: 100, align: 'left' },
            {
                field: 'clientCardNumber', title: '客户卡号', width: 125, align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.SubCardNumber(val);
                }
            },
            {
                field: 'matchOrderNo',
                title: '匹配单号',
                width: 150,
                align: 'left',
                formatter: function (val, item) {
                    var result = val;

                    if (FlashPay.Util.isNullOrEmptySpance(val)) {
                        result = '<a class="btn btn-default btn-xs btn-danger " data-title="{0}-补单" data-modal="/view/receipt/receiptmakeup.html?orderNo={0}" data-width="500" data-height="700">补单</a>'.format(item.orderNo);
                    }

                    return result;
                }
            },
            { field: 'remark', title: '备注', width: 200, align: 'left' },
            { field: 'vmClientID', title: '机器ID', width: 250, align: 'left' }
        ]]
    })
}