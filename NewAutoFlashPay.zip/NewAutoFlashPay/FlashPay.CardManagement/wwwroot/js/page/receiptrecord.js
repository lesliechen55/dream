﻿function getParams() {
    var params = {};

    var orderNo = $("input[name='orderNo']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(orderNo)) {
        params.orderNo = orderNo;
    }

    var cardName = $("input[name='cardName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(cardName)) {
        params.cardName = cardName;
    }

    var withdrawalAccountName = $("input[name='withdrawalAccountName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(withdrawalAccountName)) {
        params.withdrawalAccountName = withdrawalAccountName;
    }

    var noticeStatus = $("select[name='noticeStatus']").find("option:selected").val();
    if (!FlashPay.Util.isNullOrEmptySpance(noticeStatus)) {
        params.noticeStatus = noticeStatus;
    }

    params.startTime = $("input[name='startTime']").val();
    params.endTime = $("input[name='endTime']").val();

    return params;
}

function doSearch() {

    FlashPay.UI.DataGrid({
        ctrId: 'easyui-treegrid',
        url: '/Receipt/GetReceiptRecords',
        queryParams: getParams(),
        pagination: true,
        rownumbers: true,
        singleSelect: true,
        pageSize: 50,
        pageList: [50, 200, 500, 1000],
        height: $(window).height() - 70,
        idField: 'orderNo',
        frozenColumns: [[
            { field: 'orderNo', title: '订单号', width: 175, align: 'left' },
            { field: 'companyName', title: '公司名称', width: 100, align: 'left' },
            { field: 'withdrawalOrderNo', title: '收款单号', width: 200, align: 'left' },
            { field: 'bankName', title: '收款银行', width: 100, align: 'left' },
            { field: 'cardName', title: '收款姓名', width: 100, align: 'left' },
            { field: 'cardNumber', title: '收款卡号', width: 150, align: 'left' },
        ]],
        columns: [[
            {
                field: 'withdrawalAmount',
                title: '收款金额',
                width: 75,
                align: 'right',
                formatter: function (val, row) {
                    return '<span class="bold">{0}</span>'.format(val)
                }
            },
            {
                field: 'paymentDate',
                title: '收款时间',
                width: 150,
                align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.FormatDate(val)
                }
            },
            {
                field: 'depositType',
                title: '交易类型',
                width: 100,
                align: 'left',
                formatter: function (val, row) {
                    return val;
                }
            },
            {
                field: 'noticeStatus',
                title: '通知状态',
                width: 125,
                align: 'left',
                formatter: function (val, row) {
                    var returnStr = "";
                    if (val == 1) {
                        returnStr = "<span class='bold'>未通知</span>";
                    } else if (val == 2) {
                        returnStr = '<span class="green bold">通知成功</span>';
                    } else if (val == 3) {
                        returnStr = '<span class="red bold">通知失败</span>';
                        if (row.timeDifference > 6 && row.noticeTimes == 5) {
                            returnStr += ' <a class="btn btn-warning btn-xs" data-confirm="{0}<br>确定要<span class=orange>重置</span>吗？" data-href="/Receipt/ResetNoticeStatus?orderNo={0}">重置</a>'.format(row.orderNo);
                        }
                    } else if (val == 4) {
                        returnStr = "<span class='orange bold'>通知中</span>";
                    }
                    return returnStr;
                }
            },
            {
                field: 'noticeLastDate',
                title: '通知时间',
                width: 150,
                align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.FormatDate(val)
                }
            },
            { field: 'noticeTimes', title: '通知次数', width: 75, align: 'left' },
            { field: 'withdrawalAccountName', title: '客户姓名', width: 75, align: 'left' },
            { field: 'withdrawalBankName', title: '客户银行', width: 150, align: 'left' },
            { field: 'withdrawalCardNumber', title: '客户卡号', width: 200, align: 'left' },
            { field: 'postScript', title: '客户附言', width: 200, align: 'left' },
            {
                field: 'createDbdate',
                title: '创建时间',
                width: 150,
                align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.FormatDate(val)
                }
            },
        ]]
    })
}