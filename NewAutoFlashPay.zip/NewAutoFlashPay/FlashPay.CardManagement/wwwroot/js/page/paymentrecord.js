﻿function getParams() {
    var params = {};

    var companyName = $("input[name='companyName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(companyName)) {
        params.companyName = companyName;
    }

    var orderNo = $("input[name='orderNo']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(orderNo)) {
        params.orderNo = orderNo;
    }

    params.startTime = $("input[name='startTime']").val();
    params.endTime = $("input[name='endTime']").val();

    var paymentStatus = $("select[name='paymentStatus']").find("option:selected").val();
    if (!FlashPay.Util.isNullOrEmptySpance(paymentStatus)) {
        params.paymentStatus = paymentStatus;
    }

    var noticeStatus = $("select[name='noticeStatus']").find("option:selected").val();
    if (!FlashPay.Util.isNullOrEmptySpance(noticeStatus)) {
        params.noticeStatus = noticeStatus;
    }

    var withdrawalAccountName = $("input[name='withdrawalAccountName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(withdrawalAccountName)) {
        params.withdrawalAccountName = withdrawalAccountName;
    }

    var withdrawalCardNumber = $("input[name='withdrawalCardNumber']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(withdrawalCardNumber)) {
        params.withdrawalCardNumber = withdrawalCardNumber;
    }

    var cardName = $("input[name='cardName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(cardName)) {
        params.cardName = cardName;
    }

    return params;
}

function doSearch() {

    FlashPay.UI.DataGrid({
        ctrId: 'easyui-treegrid',
        url: '/Payment/GetPaymentRecords',
        queryParams: getParams(),
        pagination: true,
        rownumbers: true,
        singleSelect: true,
        pageSize: 50,
        pageList: [50, 200, 500, 1000],
        height: $(window).height() - 70,
        idField: 'orderNo',
        frozenColumns: [[
            { field: 'orderNo', title: '订单号', width: 175, align: 'left' },
            { field: 'companyName', title: '公司名称', width: 100, align: 'left' },
            { field: 'withdrawalOrderNo', title: '客户单号', width: 200, align: 'left' },
            { field: 'bankName', title: '付款银行', width: 100, align: 'left' },
            { field: 'cardName', title: '付款姓名', width: 100, align: 'left' },
            { field: 'cardNumber', title: '收款卡号', width: 150, align: 'left' },
        ]],
        columns: [[
            {
                field: 'withdrawalAmount',
                title: '付款金额',
                width: 75,
                align: 'right',
                formatter: function (val, row) {
                    return '<span class="bold">{0}</span>'.format(val)
                }
            },
            {
                field: 'paymentDate',
                title: '付款时间',
                width: 150,
                align: 'left',
                formatter: function (val, item) {
                    if (item.paymentStatus == 3 || item.paymentStatus == 4) {
                        return FlashPay.Util.FormatDate(item.readDate);
                    } else {
                        return FlashPay.Util.FormatDate(val);
                    }
                }
            },
            {
                field: 'paymentStatus',
                title: '付款结果',
                width: 200,
                align: 'left',
                formatter: function (val, item) {
                    var result = '';
                    if (val == 1) {
                        result = '<span class="bold">未付款</span> <a class="btn btn-danger btn-xs" data-confirm="{0}<br>确定要<span class=red>取消</span>该付款单？" data-href="/Payment/PaymentRecordCancel?orderNo={0}">取消</a>'.format(item.orderNo);
                        if (item.confirmStatus == 1) {
                            result += ' <a class="btn btn-primary btn-xs" data-modal="/view/payment/paymentconfirm.html?orderNo={0}" data-title="确认付款" data-confirmname="确认付款" data-width="400" data-height="175"> 付款审核</a>'.format(item.orderNo);
                        }
                    } else if (val == 2) {
                        result = '<span class="green bold">付款成功</span>';
                    } else if (val == 3) {
                        result = '<span class="red bold">付款失败</span>';
                    } else if (val == 4) {
                        result = '<span class="bold">付款中</span>';
                        if (item.timeDifference > 20) {
                            result += ' <a class="btn btn-default btn-xs" onclick="return view(this)" data-href="/view/payment/paymentrecordreals.html?orderNo={0}" data-title="{0}-查询" data-width="900" data-height="300">查询</a>'.format(item.orderNo);
                        }
                    } else{
                        result = '<span class="bold">取消付款</span>';
                    }
                    return result;
                }
            },
            {
                field: 'noticeStatus',
                title: '通知状态',
                width: 125,
                align: 'left',
                formatter: function (val, item) {
                    var result = "";
                    if (val == 1) {
                        result = '<span class="bold">未通知</span>';
                    } else if (val == 2) {
                        result = '<span class="green bold">通知成功</span>';
                    } else if (val == 3) {
                        result = '<span class="red bold">通知失败</span>';
                        if (item.noticeTimes == 5) {
                            result += ' <a class="btn btn-default btn-primary btn-xs" data-confirm="{0} <br>确定要<span class="red">重置</span>该付款单？" data-href="/Payment/PaymentRecordReset?orderNo={0}">重置</a>'.format(item.orderNo);
                        }
                    } else {
                        result = '<span class="bold">通知中</span>';
                    }
                    return result;
                }
            },
            {
                field: 'noticeLastDate',
                title: '通知时间',
                width: 150,
                align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.FormatDate(val)
                }
            },
            { field: 'noticeTimes', title: '通知次数', width: 75, align: 'left' },
            { field: 'withdrawalAccountName', title: '客户姓名', width: 150, align: 'left' },
            { field: 'withdrawalBankName', title: '客户银行', width: 150, align: 'left' },
            { field: 'withdrawalCardNumber', title: '客户卡号', width: 200, align: 'left' },
            {
                field: 'createDbdate',
                title: '创建时间',
                width: 150,
                align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.FormatDate(val)
                }
            },
        ]]
    })
}