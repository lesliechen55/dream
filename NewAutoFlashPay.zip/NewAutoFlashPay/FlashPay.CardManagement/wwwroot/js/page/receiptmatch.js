﻿function getParams() {
    var params = {};

    var companyName = $("input[name='companyName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(companyName)) {
        params.companyName = companyName;
    }

    var orderNo = $("input[name='orderNo']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(orderNo)) {
        params.orderNo = orderNo;
    }

    params.startTime = $("input[name='startTime']").val();
    params.endTime = $("input[name='endTime']").val();

    var clientBankName = $("input[name='clientBankName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(clientBankName)) {
        params.clientBankName = clientBankName;
    }

    var clientAccountName = $("input[name='clientAccountName']").val()
    if (!FlashPay.Util.isNullOrEmptySpance(clientAccountName)) {
        params.clientAccountName = clientAccountName;
    }
    return params;
}

function doSearch() {

    FlashPay.UI.DataGrid({
        ctrId: 'easyui-treegrid',
        url: '/DepositMatchRecord/GetDepositMatchRecord',
        queryParams: getParams(),
        pagination: true,
        rownumbers: true,
        singleSelect: true,
        pageSize: 50,
        pageList: [50, 200, 500, 1000],
        height: $(window).height() - 70,
        idField: 'orderNo',
        frozenColumns: [[]],
        columns: [[
            {
                field: 'companyName', title: '公司名称', width: 100, align: 'left'
            },
            {
                
                field: 'matchOrderNo',
                title: '订单号',
                width: 200,
                align: 'left',
                formatter: function (val, item) {

                    var result = "";

                    if (FlashPay.Util.isNullOrEmptySpance(val) && item.isShowSearch && item.statusCode == "100") {
                        result = '<a class="btn btn-default btn-xs" onclick="return view(this)" data-href="/view/receipt/matchsearch.html?ID={0}" data-title="{1}-查询" data-width="900" data-height="300">查询</a>'.format(item.id, item.clientOrderNo);
                    } else {
                        result = item.matchOrderNo;
                    }

                    if (!FlashPay.Util.isNullOrEmptySpance(item.matchOrderNo) && item.isShowAddPush && item.errorCode == "100") {
                        result += '<a class="btn btn-primary btn-xs m10_l" data-confirm="{0} <br>确定要<span class="red">补推送</span>吗？" data-href="/Receipt/AddPush?orderNo={0}">补推送</a>'.format(item.matchOrderNo);;
                    }
                    return result;
                }
            },
            { field: 'clientOrderNo', title: '商户单号', width: 200, align: 'left' },
            {
                field: 'depositDate',
                title: '订单时间',
                width: 150,
                align: 'left',
                formatter: function (val, row) {
                    return val.replace("T", " ");
                }
            },
            {
                field: 'depositAmount',
                title: '订单金额',
                width: 200,
                align: 'right',
                formatter: function (val, row) {
                    return '<span class="bold">{0}</span>'.format(val)
                }
            },
            { field: 'withdrawalAccountName', title: '银行名称', width: 150, align: 'left' },
            { field: 'clientAccountName', title: '用户名', width: 200, align: 'left' },
            {
                field: 'clientCardNumber',
                title: '银行卡号',
                width: 150,
                align: 'left',
                formatter: function (val, row) {
                    return FlashPay.Util.SubCardNumber(val)
                }
            },
            { field: 'postScript', title: '客户附言', width: 150, align: 'left' },
            { field: 'depositRemark', title: '备注', width: 150, align: 'left' },
        ]]
    })
}