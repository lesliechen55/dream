﻿(function ($, window, undefined) {

    //全局命名空间
    var FlashPay = window.FlashPay || {};

    //设定基本框架
    FlashPay = {
        Base: {}, //基础层,所有的基础函数库,如数据验证、转换等
        DAO: {},  //数据访问层,取数据,一般为Ajax的套接口
        Util: {}, //前端工具层
        UI: {},   //前端工具层

    };
    //数据访问
    FlashPay.DAO = {};
    //工具
    FlashPay.Util = {};
    //前端展示函数库
    FlashPay.UI = {};

    //将EC导入到全局对象  
    window.FlashPay = FlashPay;

}($, window));