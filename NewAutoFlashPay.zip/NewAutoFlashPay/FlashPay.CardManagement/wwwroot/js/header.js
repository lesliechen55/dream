﻿/**
 * 引用JS和CSS头文件
 */
var rootPath = getRootPath(); //项目路径

/**
 * 动态加载CSS和JS文件
 */
var dynamicLoading = {
    meta: function () {
        document.write('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
        document.write('<meta name="viewport" content="width=device-width" />');
    },
    css: function (path) {
        if (!path || path.length === 0) {
            throw new Error('argument "path" is required!');
        }
        document.write('<link rel="stylesheet" type="text/css" href="' + path + '">');
    },
    js: function (path, charset) {
        if (!path || path.length === 0) {
            throw new Error('argument "path" is required!');
        }
        document.write('<script charset="' + (charset ? charset : "utf-8") + '" src="' + path + '"></script>');
    }
};

/**
 * 取得项目路径
 */
function getRootPath() {
    /*取得当前URL*/
    var path = window.document.location.href;

    /*取得主机地址后的目录*/
    var pathName = window.document.location.pathname;

    var post = path.indexOf(pathName);

    /*取得主机地址*/
    var hostPath = path.substring(0, post);
    return hostPath;
}

/*
 获取时间戳,清缓存用
 */
var timestamp = Date.parse(new Date());
var v = "20181010";
var min = ".min";

/*动态生成meta*/
dynamicLoading.meta();

/*动态加载项目 CSS文件*/
dynamicLoading.css(rootPath + "/fonts/iconfont" + min + ".css?f=" + v);
dynamicLoading.css(rootPath + "/css/bootstrap" + min + ".css?f=" + v);
dynamicLoading.css(rootPath + "/css/framebox" + min + ".css?f=" + v);
dynamicLoading.css(rootPath + "/css/common" + min + ".css?f=" + v);
dynamicLoading.css(rootPath + "/lib/jquery/jquery-ui" + min + ".css?f=" + v);
//dynamicLoading.css(rootPath + "/lib/easyui/material-teal/easyui.css?f=" + v);

/*动态加载项目 JS文件*/
dynamicLoading.js(rootPath + "/lib/jquery/jquery.1.10.2" + min + ".js?f=" + v, "utf-8");
dynamicLoading.js(rootPath + "/lib/jquery/jquery.cookie" + min + ".js?f=" + v, "utf-8");
dynamicLoading.js(rootPath + "/lib/bootstrap/bootstrap" + min + ".js?f=" + v, "utf-8");
dynamicLoading.js(rootPath + "/js/sellerscroll" + min + ".js?f=" + v, "utf-8");

dynamicLoading.js(rootPath + "/js/base" + min + ".js?f=" + v, "utf-8");

dynamicLoading.js(rootPath + "/lib/dialog/dialog.yui" + min + ".js?f=" + v, "utf-8");
dynamicLoading.js(rootPath + "/js/ui" + min + ".js?f=" + v, "utf-8");
dynamicLoading.js(rootPath + "/js/util" + min + ".js?f=" + v, "utf-8");

dynamicLoading.js(rootPath + "/lib/dot/dot" + min + ".js?f=" + v, "utf-8");
dynamicLoading.js(rootPath + "/lib/validate/jquery.validate" + min + ".js?f=" + v, "utf-8");

dynamicLoading.js(rootPath + "/lib/jquery/jquery-ui" + min + ".js?f=" + v, "utf-8");

//dynamicLoading.js(rootPath + "/lib/easyui/jquery.easyui" + min + ".js?f=" + v, "utf-8");

dynamicLoading.js(rootPath + "/js/framebox" + min + ".js?f=" + v, "utf-8");