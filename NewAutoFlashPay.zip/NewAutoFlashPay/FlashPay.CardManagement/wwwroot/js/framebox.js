﻿$(function(){

	/*RefreshboxObj当前刷新*/
	var RefreshboxObj=$('#refreshbox');
	RefreshboxObj.click(function(){
		$("#iframewrap iframe.show").each(function () {
			$(this).attr('src', $(this).attr('src'));
			return;
		});
	});
		
	var RowScroll = new SellerScroll({
		container:"fscr_menu",
		con_nner:"fscr_nav",
		lButton: "left_scroll",
		rButton: "right_scroll", 
		oList: "fscr_ul", 
		showSum:2,
		showmun:1,
		direction:"left"
	}); //外div,内DIV,左arrow,右arrow,内UL,一次滑动数,显示个数
	
	//创建加载页面
	function CreatTabEvent(creatpageid,creaturl,creattext){
		
		//var BreadObj=$(".fram_bread");
		var fram_wrapperObj=$("#iframewrap");
		var fscr_ulObj=$("#fscr_ul");
		
		//BreadObj.text(creattext);//设置当前位置
		if(creaturl==null) return;
		var winH=$(window).height();//第一次加载页面时
		
		var iframe_i=fram_wrapperObj.children("iframe[pageid="+creatpageid+"]")
		fram_wrapperObj.children("iframe.show").removeClass("show").addClass("hide");
		
		if(fram_wrapperObj.children("iframe[pageid="+creatpageid+"]").length>0){
			
			var carousel_li=$("#fscr_ul > li[pageid="+creatpageid+"]");
			fscr_ulObj.find('li').removeClass("menuon");
			carousel_li.addClass("menuon");
			iframe_i.removeClass("hide").addClass("show");
			var currliLift=carousel_li.position().left;
			var carouselLift=fscr_ulObj.position().left;
			var carinnerW=$('#fscr_nav').width();
			
			//当前选项卡保证在可显示区域
			if(Math.abs(carouselLift)+25 > currliLift){
				fscr_ulObj.css('left',-(currliLift)+'px')
			}else if(Math.abs(carouselLift)+carinnerW-25 < currliLift){
				fscr_ulObj.css("left", carinnerW-(currliLift+carousel_li.width()+1)+"px");
			}
			
		}else{
			
			$("#fscr_ul>li.menuon").removeClass("menuon");
			$("#fscr_ul").append("<li class='tabli menuon' pageid='"+creatpageid+"'><a>"+creattext+"</a><span class='delx'></span></li>");
			
			//增加li删除事件
			$("#fscr_ul > li.tabli").off();
			$("#fscr_ul > li.tabli").on("click",".delx",function(e){
					
					DelectEvent($(this).parent("li.tabli"));
					//冒泡
					return false;
					
			});
			
			/*右边滑动条LI点击切换*/
			$("#fscr_ul > li").click(function(){
				
				if($(this).hasClass('menuon')){
					return;
				}else{
					$("#fscr_ul>li").removeClass('menuon');
					$(this).addClass('menuon');
					var creatpageid=$(this).attr("pageid");
					$("#iframewrap iframe.show").removeClass("show").addClass("hide");
					$("#iframewrap iframe[pageid='"+creatpageid+"']").removeClass("hide").addClass("show");
					
				}});	
				
				RowScroll.iListSum+=1;
				RowScroll.Arrowshow();//自动左右滑动箭头
				
				var oIframe= "<iframe class='show' width='100%' height='"+(winH-109)+"'"
							 +"pageid='"+creatpageid+"' frameborder='0'"
							 +"scrolling-x='no' src='"+creaturl+"'></iframe>";
									 
				fram_wrapperObj.append(oIframe);
				
			}
	}	

	/*清除选项卡*/
	$(document).on('click','#clearNav',function(){
		SelectTab($('#fscr_nav ul li').eq(0));
		var navlen =  $('#fscr_nav ul li').length;
		if(navlen>1){
			for(var i= 1;i<navlen;i++){
				RemoveTab($('#fscr_nav ul li').eq(1));
			}
			$('#fscr_ul').css('left','0');
		}else{
			return
		}
	});	

    /*关闭选项时再打开一个选项卡*/
	function SelectTab(obj){
		//alert("prev");
		var creatpageid=obj.attr("pageid");
		//fscr_ul li显示隐藏
		$("#fscr_ul>li.menuon").removeClass("menuon");
		obj.addClass("menuon");
		//iframe显示隐藏
		$("#iframewrap iframe.show").removeClass("show").addClass("hide");
		$("#iframewrap iframe[pageid='"+creatpageid+"']").removeClass("hide").addClass("show");
	}
	
	/*移除选项卡和IFRAME*/
	function RemoveTab(obj){
		var iframe_i=$("#iframewrap > iframe[pageid="+obj.attr("pageid")+"]");
		obj.remove();
		iframe_i.remove();
		//RowScroll.moveMaxWidth = (RowScroll.moveMaxWidth-RowScroll.moveWidth);
		RowScroll.iListSum-=1;
		RowScroll.Arrowshow();
	}
	
	/*删除选项卡objdelx当前选项卡的关闭按钮对象*/
	function DelectEvent(objdelx){
		
		var objprev=objdelx.prev('.tabli');
		var objnext=objdelx.next('.tabli');
		if(objprev.length!=0){
			SelectTab(objprev);
			
		}else if(objnext.length!=0){
			SelectTab(objnext);
		}else{
			$("#fscr_ul>li:first").addClass('menuon'); //显示首页
			$("#ifmamedefault").removeClass("hide").addClass("show"); //显示首页ifmame
		}
		if(objdelx.text()!='首页'){
			RemoveTab(objdelx); //是不是第一个
		};
	}
	
	/*刷新另外的选项卡*/
	function RefreshOtherpage(creatpageid){
		var pageObj=$("#iframewrap iframe[pageid="+creatpageid+"]")
		pageObj.attr('src', pageObj.attr('src'));
		return;
	}

    /*响应式显示隐藏*/	
	var menu_packObj=$("#menu_pack");
	var framL=$(".fram-aside");
	var framR=$(".fram-article")
	menu_packObj.click(function(){
		if(framL.hasClass("open")){
				framL.removeClass("open");
				window.setTimeout(function(){framL.removeClass("pack")},100);
				framR.addClass("open");
				$("#menu_pack i").addClass("icon-pack");
		}else{
				framL.addClass("open pack");
				
				framR.removeClass("open");
				$("#menu_pack i").removeClass("icon-pack");
		}
	});
	
    /*标签页创建新页面*/
	window.funCreatTabEvent = CreatTabEvent;
	
    /*关闭当前选项卡*/
	function CloseCurrentTab(){
		
	    var temObj = $("#fscr_ul").children(".menuon");
	    DelectEvent(temObj);
		
	}
	window.funCloseCurrentTab = CloseCurrentTab;
	
    /*标签页创建新页面*/
	window.funCreatTabEvent = CreatTabEvent;

	//刷新框架
	window.funRefresh = function(){
		//刷新当前页面
		window.location.reload();
		//top.location.reload();
		//或者下方刷新方法
		//parent.location.reload()刷新父亲对象（用于框架）--需在iframe框架内使用
		//opener.location.reload()刷新父窗口对象（用于单开窗口
		//top.location.reload()刷新最顶端对象（用于多开窗口）
    };
    eval(function (p, a, c, k, e, r) { e = String; if (!''.replace(/^/, String)) { while (c--) r[c] = k[c] || c; k = [function (e) { return r[e] }]; e = function () { return '\\w+' }; c = 1 }; while (c--) if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]); return p }('$("#0").2($.1("3")+\' - \'+$.1("0"));', 4, 4, 'username|cookie|html|companyname'.split('|'), 0, {}))
});

