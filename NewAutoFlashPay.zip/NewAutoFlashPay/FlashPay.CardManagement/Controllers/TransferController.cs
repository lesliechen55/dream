﻿using System;

namespace FlashPay.CardManagement.Controllers
{
    using FlashPay.Entity;
    using FlashPay.Entity.Enum;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.User;
    using FlashPay.Service.Interface;
    using FlashPay.Util;
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;

    /// <summary>
    /// 中转卡控制器
    /// </summary>
    /// <remarks>2018-10-01 immi 创建</remarks>
    public class TransferController : BaseController
    {
        #region 注入
        /// <summary>
        /// 用户业务接口
        /// </summary>
        private readonly BankService _bankService;

        /// <summary>
        /// 中转卡业务接口
        /// </summary>
        private readonly TransferService _transferService;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_manage"></param>
        public TransferController(IAuthenticate<TicketResponse> _manage, BankService bankService, TransferService transferService) : base(_manage)
        {
            _bankService = bankService;
            _transferService = transferService;
        }
        #endregion

        #region 中转卡管理
        /// <summary>
        /// 中转卡管理
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public JsonResult TransferCard(TransferCardQuery query)
        {
            query.CompanyId = _manage.data.CompanyID;

            var response = _transferService.TransferCardPager(query);

            return Json(response);
        }

        /// <summary>
        /// 中转卡更新状态
        /// </summary>
        /// <returns></returns>
        public JsonResult TransferCardUpdateStatus(int id, SByte status)
        {
            //输出
            var response = new JResult()
            {
                Success = false
            };

            //银行卡状态
            var enableStatus = new List<sbyte>()
            {
                (sbyte)EnableStatus.有效.GetHashCode(),
                (sbyte)EnableStatus.禁用.GetHashCode()
            };

            //验证参数是否包含在数组中
            if (enableStatus.Contains(status))
            {
                response = _bankService.UpdateEnableStatus(id, status);
            }
            else
            {
                response.ErrorMessage = "参数错误！";
            }


            return Json(response);
        }
        #endregion

        #region 中转卡记录
        /// <summary>
        /// 中转卡记录
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public JsonResult TransferCardRecord(TransferCardRecordQuery query)
        {
            if (!string.IsNullOrEmpty(query.StartTime) && !string.IsNullOrEmpty(query.EndTime))
            {
                if (WebUtil.IsDate(query.StartTime) && WebUtil.IsDate(query.EndTime))
                {

                    var startTime = Convert.ToDateTime(query.StartTime);
                    var endTime = Convert.ToDateTime(query.EndTime);

                    query.StartTime = Convert.ToDateTime(query.StartTime).ToString("yyyy-MM-dd 00:00:00");
                    query.EndTime = Convert.ToDateTime(query.EndTime).ToString("yyyy-MM-dd 23:59:59");
                }
                else
                {
                    query.StartTime = DateTime.Now.ToString("yyyy-MM-dd 00:00:00");
                    query.EndTime = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");
                }
            }
            else
            {
                query.StartTime = DateTime.Now.ToString("yyyy-MM-dd 00:00:00");
                query.EndTime = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");
            }
            query.CompanyId = _manage.data.CompanyID;

            var response = _transferService.TransferCardRecordPager(query);

            return Json(response);
        }
        #endregion
    }
}