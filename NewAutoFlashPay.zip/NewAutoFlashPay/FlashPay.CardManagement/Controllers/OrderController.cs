﻿using System;
using System.Collections.Generic;
using FlashPay.Service.Order;
using FlashPay.CardManagement.ViewModels.Order;
using Microsoft.AspNetCore.Mvc;
using FlashPay.Entity.Request.Order;
using FlashPay.Entity.Response.Order;
using FlashPay.CardManagement.Mappers;
using FlashPay.Entity;
using FlashPay.Service.Interface;
using System.Linq;
using FlashPay.CardManagement.ViewModels.Permission;
using FlashPay.Entity.Response.User;

namespace FlashPay.CardManagement.Controllers
{
    /// <summary>
    /// 訂單管理
    /// </summary>
    public class OrderController : BaseController
    {
        private readonly OrderService orderService;
        private readonly UserInfoService userService;
        public OrderController(IAuthenticate<TicketResponse> _manage, OrderService orderService, UserInfoService userService) : base(_manage)
        {
            this.orderService = orderService;
            this.userService = userService;
        }

        /// <summary>
        /// 訂單新增
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0002)]
        public JsonResult Add([FromBody] OrderRecordViewModel<String> model)
        {
            /* 資料驗證 */
            /* 因目前沒有錯誤碼及錯誤提示，所以這兩個欄位先不填 */
            if (!this.TryValidateModel(model))
            {
                return Json(Mapper.MapperResponse(model));
            }

            /* 轉換Model */
            OrderRecordRequest<String> request = Mapper.MapperRequest<String, String>(model);

            /* 補上必要資料 */
            request.CreateUID = _manage.data.UserID;

            /* 呼叫Service層 */
            this.orderService.AddOrderRecord(request);

            /* 結果複製 */
            model.Code = request.Code;
            model.Result = request.Result;
            model.Message = request.Message;
            model.Success = request.Success;

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 訂單修改
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0003)]
        public JsonResult Edit([FromBody] OrderRecordViewModel<String> model)
        {
            if (model.OrderNo != null && model.OrderNo > 0)
            {
                /* 轉換Model */
                OrderRecordRequest<String> request = Mapper.MapperRequest<String, String>(model);

                /* 補上必要資料 */
                request.CreateUID = _manage.data.UserID;
                request.CompanyID = _manage.data.CompanyID;

                #region 判断是否有查看所有订单相关金额权限
                if (!CheckPermission())
                {
                    request.Code = AuthCode.Order0017.ToString();
                }
                #endregion
                request.LoginUserID = _manage.data.UserID;
                /* 呼叫Service層 */
                this.orderService.EditOrderRecord(request);

                /* 結果複製 */
                model.Code = request.Code;
                model.Result = request.Result;
                model.Message = request.Message;
                model.Success = request.Success;
            }

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 訂單修改(快递单号)
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0003)]
        public JsonResult EditDeliveryNo([FromBody] OrderRecordViewModel<String> model)
        {
            if (model.OrderNo != null && model.OrderNo > 0)
            {
                /* 轉換Model */
                OrderRecordRequest<String> request = Mapper.MapperRequest<String, String>(model);

                /* 補上必要資料 */
                request.CreateUID = _manage.data.UserID;
                request.CompanyID = _manage.data.CompanyID;

                /* 呼叫Service層 */
                this.orderService.EditOrderRecordDeliveryNo(request);

                /* 結果複製 */
                model.Code = request.Code;
                model.Result = request.Result;
                model.Message = request.Message;
                model.Success = request.Success;
            }

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 訂單收貨時間修改
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0004)]
        public JsonResult EditReceiptDate([FromBody] OrderRecordViewModel<String> model)
        {
            if (model.OrderNo != null && model.OrderNo > 0 && model.ReceiptDate != null)
            {
                /* 轉換Model */
                OrderRecordRequest<String> request = Mapper.MapperRequest<String, String>(model);

                /* 補上必要資料 */
                request.CreateUID = _manage.data.UserID;
                request.CompanyID = _manage.data.CompanyID;

                /* 呼叫Service層 */
                this.orderService.EditOrderRecordReceiptDate(request);

                /* 結果複製 */
                model.Code = request.Code;
                model.Result = request.Result;
                model.Message = request.Message;
                model.Success = request.Success;
            }

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 訂單付款時間修改
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0005)]
        public JsonResult EditPayDate([FromBody] OrderRecordViewModel<String> model)
        {
            if (model.OrderNo != null && model.OrderNo > 0 && model.PayDate != null)
            {
                /* 轉換Model */
                OrderRecordRequest<String> request = Mapper.MapperRequest<String, String>(model);

                /* 補上必要資料 */
                request.CreateUID = _manage.data.UserID;
                request.CompanyID = _manage.data.CompanyID;

                /* 呼叫Service層 */
                this.orderService.EditOrderRecordPayDate(request);

                /* 結果複製 */
                model.Code = request.Code;
                model.Result = request.Result;
                model.Message = request.Message;
                model.Success = request.Success;
            }

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 訂單刪除
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0009)]
        public JsonResult Delete(OrderRecordViewModel<String> model)
        {
            if (model.OrderNo != null && model.OrderNo > 0)
            {
                /* 轉換Model */
                OrderRecordRequest<String> request = Mapper.MapperRequest<String, String>(model);

                /* 補上必要資料 */
                request.CreateUID = _manage.data.UserID;
                request.CompanyID = _manage.data.CompanyID;

                /* 呼叫Service層 */
                this.orderService.DeleteOrderRecord(request);

                /* 結果複製 */
                model.Code = request.Code;
                model.Result = request.Result;
                model.Message = request.Message;
                model.Success = request.Success;
            }

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 訂單列表
        /// </summary>
        //[AuthorizeFilter(AuthCode.Order0001)]
        [AuthorizeFilter(AuthCode.Order0015, AuthCode.Order0016)]
        public JsonResult Get([FromBody] OrderRecordViewModel<List<Object>> model)
        {
            if (model != null)
            {
                model.PageIndex = model.CurrentPageIndex;
                return GetCommon(model);
            }
            else
            {
                return Json(new JResult { Success =false,ErrorMessage="未获取到数据"});
            }
        }

        /// <summary>
        /// 查看详情
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0003, AuthCode.AllowEdit)]
        public JsonResult GetDetail([FromBody] OrderRecordViewModel<List<Object>> model)
        {
            if (model != null)
            {
                return GetCommon(model);
            }
            else
            {
                return Json(new JResult { Success = false, ErrorMessage = "未获取到数据" });
            }
        }

        /// <summary>
        /// 是否有查看(编辑)收货日期的权限
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0004,AuthCode.AllowEdit)]
        public JsonResult GetReceiptDatePermission([FromBody] OrderRecordViewModel<List<Object>> model)
        {
            if (model != null)
            {
                return GetCommon(model);
            }
            else
            {
                return Json(new JResult { Success = false, ErrorMessage = "未获取到数据" });
            }
        }

        /// <summary>
        /// 是否有查看(编辑)付款日期的权限
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0005,AuthCode.AllowEdit)]
        public JsonResult GetPayDatePermission([FromBody] OrderRecordViewModel<List<Object>> model)
        {
            if (model != null)
            {
                return GetCommon(model);
            }
            else
            {
                return Json(new JResult { Success = false, ErrorMessage = "未获取到数据" });
            }
        }

        //公共Get方法
        public JsonResult GetCommon([FromBody] OrderRecordViewModel<List<Object>> model)
        {
            if (model.EndOrderDate != null)
            {
                model.EndOrderDate = Convert.ToDateTime(model.EndOrderDate).AddDays(1).AddSeconds(-1);
            }
            if (model.EndPayDate != null)
            {
                model.EndPayDate = Convert.ToDateTime(model.EndPayDate).AddDays(1).AddSeconds(-1);
            }

            #region 权限判断
            List<string> userPermission = _manage.data.UserPermission;
            if (userPermission != null && userPermission.Count > 0)
            {
                userPermission = userPermission.Where(e => e.Contains("Order00")).ToList();
            }
            PermissionViewModel permissionModel = new PermissionViewModel();
            for (int i = 0; userPermission != null && i < userPermission.Count; i++)
            {
                if (userPermission[i].Equals(AuthCode.Order0011.ToString()))
                {
                    permissionModel.CanYajinCardNo = true;
                }
                if (userPermission[i].Equals(AuthCode.Order0012.ToString()))
                {
                    permissionModel.CanWeiKuanCardNo = true;
                }
                if (userPermission[i].Equals(AuthCode.Order0007.ToString()))
                {
                    permissionModel.CanDepositAmount = true;
                }
                if (userPermission[i].Equals(AuthCode.Order0008.ToString()))
                {
                    permissionModel.CanPayAmount = true;
                }
                //是否可以确认收货
                if (userPermission[i].Equals(AuthCode.Order0010.ToString()))
                {
                    permissionModel.CanReceipt = true;
                }
                //是否可以查看已完成订单
                if (userPermission[i].Equals(AuthCode.Order0015.ToString()))
                {
                    permissionModel.CanCompletedOrder = true;
                }
                //是否可以查看未完成订单
                if (userPermission[i].Equals(AuthCode.Order0016.ToString()))
                {
                    permissionModel.CanUndoneOrder = true;
                }
                //是否可以查看所有订单相关金额
                if (userPermission[i].Equals(AuthCode.Order0017.ToString()))
                {
                    permissionModel.CanViewAmount = true;
                }
            }

            if (!permissionModel.CanCompletedOrder && permissionModel.CanUndoneOrder)  //只能看未完成的订单
            {
                if (model.Status == 4)
                {
                    return Json(new JResult { Success = false, ErrorCode = "11000", ErrorMessage = "筛选无效,您只有查看未完成订单的权限" });
                }
                if (model.Status == 0)
                {
                    model.Status = 5;
                }
            }
            else if (permissionModel.CanCompletedOrder && !permissionModel.CanUndoneOrder)  //只能看已完成的订单
            {
                if (model.Status > 0 && model.Status < 4)
                {
                    return Json(new JResult { Success = false, ErrorCode = "11000", ErrorMessage = "筛选无效,您只有查看已完成订单的权限" });
                }
                if (model.Status == 0)
                {
                    model.Status = 4;
                }
            }
            #endregion

            /* 轉換Model */
            OrderRecordRequest<List<OrderRecordResponse>> request = Mapper.MapperRequest<List<Object>, List<OrderRecordResponse>>(model);

            /* 補上必要資料 */
            request.CompanyID = _manage.data.CompanyID;

            /* 呼叫Service層 */
            this.orderService.GetOrderRecord(request);

            /* 結果複製 */
            model.Code = request.Code;
            model.Result = new List<Object>(request.Result);

            //权限信息
            model.Permisss = permissionModel;

            model.Message = request.Message;
            model.Success = request.Success;
            model.TotalCount = request.TotalCount;
            model.LoginUserID = _manage.data.UserID;
            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 訂單押金審核
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0007)]
        public JsonResult PassDeposit(OrderRecordViewModel<String> model)
        {
            if (model.OrderNo != null && model.OrderNo > 0)
            {
                /* 轉換Model */
                OrderRecordRequest<String> request = Mapper.MapperRequest<String, String>(model);

                /* 補上必要資料 */
                request.DepositUID = _manage.data.UserID;
                request.CompanyID = _manage.data.CompanyID;
                //request.PayCardNumber = model.PayCardNumber;//尾款收款卡号

                /* 呼叫Service層 */
                this.orderService.PassOrderRecordDeposit(request);

                /* 結果複製 */
                model.Code = request.Code;
                model.Result = request.Result;
                model.Message = request.Message;
                model.Success = request.Success;
            }

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 訂單付款審核
        /// </summary>
        [AuthorizeFilter(AuthCode.Order0008)]
        public JsonResult PassPay(OrderRecordViewModel<String> model)
        {
            if (model.OrderNo != null && model.OrderNo > 0)
            {
                /* 轉換Model */
                OrderRecordRequest<String> request = Mapper.MapperRequest<String, String>(model);

                /* 補上必要資料 */
                request.PayUID = _manage.data.UserID;
                request.CompanyID = _manage.data.CompanyID;
                //request.DepositCardNumber = model.DepositCardNumber;//押金收款卡号

                /* 呼叫Service層 */
                this.orderService.PassOrderRecordPay(request);

                /* 結果複製 */
                model.Code = request.Code;
                model.Result = request.Result;
                model.Message = request.Message;
                model.Success = request.Success;
            }

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        //根据押金、付款人名称，获取不重复信息
        public JsonResult GetUserName([FromBody] OrderRecordViewModel<List<int>> model)
        {
            OrderRecordRequest<List<int>> request = Mapper.MapperRequest<List<int>, List<int>>(model);
            request.CompanyID = _manage.data.CompanyID;
            this.orderService.GetAllOrderRecordUserId(request);

            //model.Code = request.Code;
            model.Success = request.Success;
            model.Result = new List<int>(request.Result);
            //model.Message = request.Message;
            //model.TotalCount = request.Result.Count;

            if (model.Success)
            {
                var pager=this.userService.GetUserInfoByIds(model.Result, model.PageIndex, model.PageSize);
                return Json(pager);
            }

            return Json(new { Success =false});
        }

        //确认收货
        [AuthorizeFilter(AuthCode.Order0010)]
        public JsonResult Receipt(OrderRecordViewModel<String> model)
        {
            if (model.OrderNo != null && model.OrderNo > 0)
            {
                /* 轉換Model */
                OrderRecordRequest<String> request = Mapper.MapperRequest<String, String>(model);

                /* 補上必要資料 */
                request.ReceiptUID = _manage.data.UserID;
                request.CompanyID = _manage.data.CompanyID;

                /* 呼叫Service層 */
                this.orderService.PassOrderRecordReceipt(request);

                /* 結果複製 */
                model.Code = request.Code;
                model.Result = request.Result;
                model.Message = request.Message;
                model.Success = request.Success;
            }
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 驗證模型
        /// </summary>
        protected virtual Boolean TryValidateModel(Object model)
        {
            return base.TryValidateModel(model);
        }

        //判断是否有查看押金金额(修改)的权限
        public bool CheckPermission()
        {
            bool isCan = false;
            List<string> userPermission = _manage.data.UserPermission;
            if (userPermission != null && userPermission.Count > 0)
            {
                var checkPermission = userPermission.Where(e => e.Contains(AuthCode.Order0017.ToString())).FirstOrDefault();
                if (checkPermission != null)
                {
                    isCan = true;
                }
            }
            return isCan;
        }
    }
}