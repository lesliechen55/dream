﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.Report;
    using FlashPay.Entity.Response.Company;
    using FlashPay.Entity.Response.User;
    using FlashPay.Service.Interface;
    using FlashPay.Service.Report;
    using FlashPay.Util;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// 报表控制器
    /// </summary>
    public class ReportController : BaseController
    {
        #region 注入
        /// <summary>
        /// 报表业务接口
        /// </summary>
        private readonly ReportService _reportService;

        /// <summary>
        /// 用户业务接口
        /// </summary>
        private readonly SysRoleService _sysRoleService;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="reportService">报表业务接口</param>
        /// <param name="manage"></param>
        public ReportController(IAuthenticate<TicketResponse> _manage,ReportService reportService, SysRoleService sysRoleService) : base(_manage)
        {
            this._reportService = reportService;
            this._sysRoleService = sysRoleService;
        }
        #endregion

        #region 获取公司月份报表
        /// <summary>
        /// 获取公司月份报表
        /// </summary>
        /// <param name="request">参数</param>
        [AuthorizeFilter(AuthCode.CompanyMonth0001)]
        public JsonResult GetCompanyMonthsReport(CompanyMonthsReportRequest request)
        {
            //获取月天数
            int day = DateTime.DaysInMonth(request.ReportDate.Year, request.ReportDate.Month);
            request.StartTime = request.ReportDate.ToString("yyyy-MM-01 00:00:00");
            request.EndTime = request.ReportDate.ToString($"yyyy-MM-{day.ToString("00")} 23:59:59");
            request.CompanyId = _manage.data.CompanyID;
            var response = _reportService.GetCompanyMonthsReport(request);
            return Json(response);
        }

        /// <summary>
        /// 获取银行月份报表
        /// </summary>
        /// <param name="request">参数</param>
        public JsonResult GetBankCardMonthsReport(BankCardMonthsReportReqeust request)
        {
            //获取月天数
            int day = DateTime.DaysInMonth(request.ReportDate.Year, request.ReportDate.Month);
            request.StartTime = request.ReportDate.ToString("yyyy-MM-01 00:00:00");
            request.EndTime = request.ReportDate.ToString($"yyyy-MM-{day.ToString("00")} 23:59:59");
            request.CompanyId = _manage.data.CompanyID;
            var response = _reportService.GetBankCardMonthsReport(request);
            return Json(response);
        }
        #endregion

        /// <summary>
        /// 获取公司年报表
        /// </summary>
        [AuthorizeFilter(AuthCode.CompanyYear0001)]
        public JsonResult GetReportByYear(ReportStatisticsQuery query)
        {
            if (query.StartTime == null)
            {
                query.StartTime = DateTime.Now.ToString("yyyy");
            }
            if (query.CompanyIds == null || query.CompanyIds.Count <= 0)
            {
                query.CompanyId = _manage.data.CompanyID;
            }
            var pager = _reportService.GetReportByYear(query);
            return Json(pager);
        }

        #region 获取公司银行卡报表
        /// <summary>
        /// 获取公司银行卡报表
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.CompanyBankCard0001)]
        public JsonResult GetBankCardDetail(BankCardDetailQuery query)
        {
            query.CompanyId = _manage.data.CompanyID;
            if (query.CompanyIds == null)
            {
                var companys = _sysRoleService.GetCompany(this._manage.data.CompanyID, 2);
                if (companys != null) {
                    query.CompanyIds = companys.Select(p => p.CompanyID).ToList();
                }
            }
            else {
                query.CompanyIds.Add(_manage.data.CompanyID);
            }
            if (!string.IsNullOrEmpty(query.StartTime) && !string.IsNullOrEmpty(query.EndTime))
            {
                if (WebUtil.IsDate(query.StartTime) && WebUtil.IsDate(query.EndTime))
                {
                    var startTime = Convert.ToDateTime(query.StartTime);
                    var endTime = Convert.ToDateTime(query.EndTime);

                    query.StartTime = Convert.ToDateTime(query.StartTime).ToString("yyyy-MM-dd 00:00:00");
                    query.EndTime = Convert.ToDateTime(query.EndTime).ToString("yyyy-MM-dd 23:59:59");
                }
                else
                {
                    query.StartTime = DateTime.Now.ToString("yyyy-MM-dd 00:00:00");
                    query.EndTime = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");
                }
            }
            else
            {
                query.StartTime = DateTime.Now.ToString("yyyy-MM-dd 00:00:00");
                query.EndTime = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");
            }
            var response = _reportService.GetBankCardDetail(query);

            return Json(response);
        }

        /// <summary>
        /// 根据编号获取公司
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>Company</returns>
        [AuthorizeFilter(AuthCode.CompanyBankCard0001)]
        public JsonResult GetCompany()
        {
            var response = new JResult<List<CompanyResponse>>()
            {
                Success = false
            };
            try
            {
                //所属公司
                if (_manage.data.CompanyID <= 0)
                {
                    throw new Exception("所属公司不存在!");
                }

                var companys = _sysRoleService.GetCompany(this._manage.data.CompanyID, 2);
                if (companys != null) {
                    companys.RemoveAll(p => p.CompanyID == _manage.data.CompanyID);
                }
                response.Data = companys;
                response.Success = true;
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
            }

            return Json(response);
        }
        #endregion
    }
}