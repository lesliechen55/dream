﻿using System;
using System.Linq;
using FlashPay.Entity;
using FlashPay.Entity.Enum;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Response.User;
using FlashPay.Service.Interface.Receipt;
using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    public class ReceiptController : BaseController
    {
        private readonly ReceiptService receiptService;

        public ReceiptController(IAuthenticate<TicketResponse> _manage, ReceiptService receiptService) : base(_manage)
        {
            this.receiptService = receiptService;
        }

        public IActionResult Index()
        {
            return View();
        }

        //获取收款卡管理列表
        [AuthorizeFilter(AuthCode.ReceiptCard0001)]
        public JsonResult GetReceiptCardList(PaymentCardQuery query)
        {
            sbyte type = (int)AdjustStatus.收款;
            query.AdjustStatus = type;
            query.CardType = type;
            query.CompanyId = _manage.data.CompanyID;
            var pager = this.receiptService.GetList(query);
            if (pager.Success)
            {
                var userPermission = _manage.data.UserPermission.Where(e => e.Contains("ReceiptCard0002")).FirstOrDefault();
                if (userPermission != null)
                {
                    pager.StatusCode = "100";
                }
            }
            return Json(pager);
        }

        //获取收款记录列表
        [AuthorizeFilter(AuthCode.ReceiptRecord0001)]
        public JsonResult GetReceiptRecord(PaymentRecordQuery query)
        {
            if (query.StartTime == null)
            {
                query.StartTime = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 00:00:00");
            }
            else
            {
                query.StartTime = Convert.ToDateTime(query.StartTime).ToString("yyyy-MM-dd 00:00:00");
            }
            if (query.EndTime == null)
            {
                query.EndTime = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");
            }
            else
            {
                query.EndTime = Convert.ToDateTime(query.EndTime).ToString("yyyy-MM-dd 23:59:59");
            }
            query.CompanyId = _manage.data.CompanyID;
            var pager = this.receiptService.GetReceiptRecordList(query);
            return Json(pager);
        }

        /// <summary>
        /// 获取收款记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.ReceiptRecord0001)]
        public JsonResult GetReceiptRecords(DepositRecordQuery query)
        {
            if (query.StartTime == null)
            {
                query.StartTime = DateTime.Now.AddDays(-1).ToString("yyyy-MM-02 00:00:00");
            }
            else
            {
                query.StartTime = Convert.ToDateTime(query.StartTime).ToString("yyyy-MM-dd 00:00:00");
            }
            if (query.EndTime == null)
            {
                query.EndTime = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");
            }
            else
            {
                query.EndTime = Convert.ToDateTime(query.EndTime).ToString("yyyy-MM-dd 23:59:59");
            }
            query.CompanyId = _manage.data.CompanyID;
            var pager = receiptService.GetReceiptRecord(query);
            return Json(pager);
        }

        //获取收款记录列表
        public JsonResult GetReceiptRecordByTime(string time, int minutes)
        {
            var response = new JResult()
            {
                Success = false
            };
            if (string.IsNullOrEmpty(time))
            {
                response.ErrorMessage = "时间获取出错";
                return Json(response);
            }
            PaymentRecordQuery q = new PaymentRecordQuery();
            q.StartTime = time;
            q.EndTime = Convert.ToDateTime(time).AddMinutes(minutes).ToString("yyyy-MM-dd HH:mm:ss");
            q.CompanyId = _manage.data.CompanyID;
            q.Type=1;
            var pager = this.receiptService.GetReceiptRecordList(q);
            return Json(pager);
        }

        /// <summary>
        /// 重置
        /// </summary>
        /// <param name="orderNo">订单编号</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.ReceiptRecord0002)]
        public JsonResult ResetNoticeStatus(Int64 orderNo)
        {
            var response = this.receiptService.ResetNoticeStatus(orderNo);

            return Json(response);
        }

        /// <summary>
        /// 补推送
        /// </summary>
        /// <param name="orderNo">订单编号</param>
        /// <returns></returns>
        //[AuthorizeFilter(AuthCode.ReceiptRecord0002)]
        public JsonResult AddPush(Int64 orderNo)
        {
            var response = this.receiptService.AddPush(orderNo);

            return Json(response);
        }

    }
}