﻿using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    using FlashPay.Entity;
    using FlashPay.EF.Models;
    using FlashPay.Service.Interface;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.User;

    /// <summary>
    /// 卡商管理
    /// </summary>
    public class CardMerchantController : BaseController
    {
        /// <summary>
        /// 卡商业务接口
        /// </summary>
        private readonly CardMerchantService _cardMerchantService;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cardMerchantService">卡商业务接口</param>
        /// <param name="_manage"></param>
        public CardMerchantController(IAuthenticate<TicketResponse> _manage,CardMerchantService cardMerchantService) : base(_manage)
        {
            _cardMerchantService = cardMerchantService;
        }

        /// <summary>
        /// 获取卡商
        /// </summary>
        [AuthorizeFilter(AuthCode.CardMerchant0001)]
        public JsonResult Get(int Cmid)
        {
            var result = _cardMerchantService.GetCardMerchant(Cmid);
            return Json(result);

        }

        #region #region 新增、编辑
        /// <summary>
        /// 根据编号获取
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AuthorizeFilter(AuthCode.CardMerchant0002, AuthCode.CardMerchant0003, AuthCode.AllowEdit)]
        public JsonResult GetAddOrEdit(int cmid)
        {
            var result = _cardMerchantService.GetCardMerchant(cmid);
            return Json(result);
        }

        /// <summary>
        /// 添加卡商
        /// </summary>
        [AuthorizeFilter(AuthCode.CardMerchant0002)]
        public JsonResult Insert([FromBody] CardMerchant model)
        {
            model.CreateUid = _manage.data.UserID;
            model.CardCommissionerUid = _manage.data.UserID;
            var result = _cardMerchantService.AddCardMerchant(model);
            return Json(result);
        }

        /// <summary>
        /// 卡商修改
        /// </summary>
        [AuthorizeFilter(AuthCode.CardMerchant0003, AuthCode.AllowEdit)]
        public JsonResult Edit([FromBody] CardMerchant model)
        {
            JResult result = new JResult();
            if (model.Cmid > 0)
            {
                model.CardCommissionerUid = _manage.data.UserID;
                result = _cardMerchantService.UpdateCardMerchant(model);
            }
            return Json(result);
        }
        #endregion

        /// <summary>
        /// 删除卡商
        /// </summary>
        [AuthorizeFilter(AuthCode.CardMerchant0005)]
        public JsonResult Delete(int Cmid)
        {
            JResult result = new JResult();
            if (Cmid > 0)
            {
                result = _cardMerchantService.DeleteCardMerchant(Cmid);
            }
            return Json(result);
        }

        /// <summary>
        /// 卡商分页列表
        /// </summary>
        [AuthorizeFilter(AuthCode.CardMerchant0001)]
        public JsonResult GetPage([FromBody] CardMerchantQuery model)
        {
            model.CompanyId = _manage.data.CompanyID;

            var result = _cardMerchantService.CardMerchantPage(model);
            return Json(result);
        }

        // 卡商下拉列表(不需要权限)
        public JsonResult GetPage2([FromBody] CardMerchantQuery model)
        {
            model.CompanyId = _manage.data.CompanyID;
            model.CreateUid = _manage.data.UserID;//只能看到自己创建的卡商
            var result = _cardMerchantService.CardMerchantPage(model);
            return Json(result);
        }

        /// <summary>
        /// 卡商列表
        /// </summary>
        public JsonResult GetList([FromBody] CardMerchantQuery model)
        {
            var result = _cardMerchantService.CardMerchantList(model);
            return Json(result);
        }

        /// <summary>
        /// 通过条件获取卡商信息
        /// </summary>
        public JsonResult SearchCardMerchant(CardMerchantQuery query)
        {
            query.CompanyId = _manage.data.CompanyID;

            var result = _cardMerchantService.SearchCardMerchant(query);
            return Json(result);
        }



    }
}
