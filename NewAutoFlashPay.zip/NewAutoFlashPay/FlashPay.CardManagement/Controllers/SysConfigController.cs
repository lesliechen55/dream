﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    using FlashPay.Entity;
    using FlashPay.Service.Sys;
    using FlashPay.Entity.Response.Sys;
    using System;
    using FlashPay.Entity.Request.Sys;
    using FlashPay.Entity.Parameter;
    using System.Linq;
    using FlashPay.Util;
    using FlashPay.Entity.Response.User;
    using FlashPay.Service.Company;
    using FlashPay.Service.Bank;
    using FlashPay.Service.Interface;

    /// <summary>
    /// 参数管理
    /// </summary>
    public class SysConfigController : BaseController
    {
        #region 注入
        /// <summary>
        /// 系统参数配置业务接口
        /// </summary>
        private readonly SysConfigService _sysService;

        public SysConfigController(IAuthenticate<TicketResponse> _manage,SysConfigService sysService) : base(_manage)
        {
            _sysService = sysService;
        }
        #endregion

        #region 获取系统配置
        /// <summary>
        /// 编辑时获取
        /// </summary>
        [AuthorizeFilter(AuthCode.SysConfig0003)]
        public JsonResult GetEdit(int configId)
        {
            //输出
            var response = new JResult<SysConfigResponse>()
            {
                Success = false
            };

            try
            {
                response.Success = true;
                response.Data = _sysService.Get(configId, _manage.data.CompanyID);
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
            }

            return Json(response);

        }

        /// <summary>
        /// 新增时获取
        /// </summary>
        [AuthorizeFilter(AuthCode.SysConfig0002)]
        public JsonResult GetAdd(int configId)
        {
            //输出
            var response = new JResult<SysConfigResponse>()
            {
                Success = false
            };

            try
            {
                response.Success = true;
                response.Data = _sysService.Get(configId, _manage.data.CompanyID);
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
            }

            return Json(response);
        }
        #endregion

        /// <summary>
        /// 系统配置新增或编辑
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.SysConfig0002, AuthCode.SysConfig0003)]
        public JsonResult SysConfigAddOrEdit(SysConfigAddOrEditRequest request)
        {
            var response = _sysService.AddOrEdit(request);
            return Json(response);
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.SysConfig0004)]
        public JsonResult SysConfigDelete(int configId)
        {
            var response = _sysService.Delete(configId);
            return Json(response);
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<PermissionResponse></returns>
        [AuthorizeFilter(AuthCode.SysConfig0001)]
        public JsonResult GetPager(SysConfigQuery query)
        {
            query.CompanyId = _manage.data.CompanyID;

            var pager = _sysService.GetPager(query);
            return Json(pager);
        }

        #region 第三方接口信息
        /// <summary>
        /// 获取第三方接口列表
        /// </summary>
        [AuthorizeFilter(AuthCode.PaymentInterface0001)] 
        public JsonResult GetPayMentInterfaceList([FromBody]PaymentInterfaceQuery query)
        {
            query.CompanyId = _manage.data.CompanyID;
            var response = _sysService.GetPayMentInterfaceList(query);
            return Json(response);
        }

        /// <summary>
        /// 获取某第三方接口详细信息
        /// </summary>
        public JsonResult GetDetail(PaymentInterfaceQuery query)
        {
            int companyID = query.CompanyId.Value;
            var data = _sysService.GetDetail(companyID);
            return Json(data);
        }

        /// <summary>
        /// 获取某第三方接口多重信息
        /// </summary>
        public JsonResult GetManyInfo(PaymentInterfaceQuery query)
        {
            int companyID = 0;
            if (query.CompanyId == null)
            {
                companyID = _manage.data.CompanyID;
            }
            else
            {
                companyID = query.CompanyId.Value;
            }
            var data = _sysService.GetManyInfo(companyID);
            return Json(data);
        }

        //添加或修改
        [AuthorizeFilter(AuthCode.PaymentInterface0002)]
        public JsonResult AddOrEditInterface(PaymentInterfaceQuery query)
        {
            if (!ModelState.IsValid)
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).FirstOrDefault();
                return Json(new JResult()
                {
                    Success = false,
                    ErrorMessage = message
                });
            }
            
            if (query.LimitCloseDate!=null)
            {
                query.LimitCloseDate = DateTime.Now.ToString("yyyy-MM-dd ")+ query.LimitCloseDate+":00:00";
            }
            if (query.LimitOpenDate!=null)
            {
                query.LimitOpenDate = DateTime.Now.ToString("yyyy-MM-dd ") + query.LimitOpenDate + ":00:00";
            }
            var data = _sysService.AddOrEditInterface(query);
            return Json(data);
        }

        //修改状态
        [AuthorizeFilter(AuthCode.PaymentInterface0004)]
        public JsonResult UpdateStatus(PaymentInterfaceQuery query)
        {
            var data = _sysService.UpdateStatus(query);
            return Json(data);
        }

        //删除
        [AuthorizeFilter(AuthCode.PaymentInterface0003)]
        public JsonResult DeleteInterface(PaymentInterfaceQuery query)
        {
            var data = _sysService.DeleteInterface(query.CompanyId.Value);
            return Json(data);
        }

        // 获取交易类型列表
        public JsonResult GetTypeList(SysConfigAddOrEditRequest sysRequest)
        {
            sysRequest.ConfigCode = "PaymentInterface";
            //sysRequest.CompanyId = _manage.data.CompanyID;
            var response = _sysService.GetTransTypeList(sysRequest);
            return Json(response);
        }
        #endregion

        /// <summary>
        /// 获取推送地址列表
        /// </summary>
        //[AuthorizeFilter(AuthCode.PushAddressList0001)]
        //public JsonResult GetPushAddressList([FromBody]PushAddressQuery query)
        //{
        //    query.CompanyId = _manage.data.CompanyID;
        //    var response = _sysService.GetPushAddressList(query);
        //    return Json(response);
        //}

        public JsonResult CommonGetKey()
        {
            var response = new JResult()
            {
                Success = false
            };

            try
            {
                string data = EncryptHelper.enSHA256(Guid.NewGuid().ToString("N"));
                string appkey = data.Substring(0, 32);
                string secret = string.Empty;
                string secretKey = string.Empty;

                if (string.IsNullOrEmpty(appkey))
                {
                    response.ErrorMessage = "获取appkey出错";
                    return Json(response);
                }
                else
                {
                    System.Threading.Thread.Sleep(1000);
                    secret = EncryptHelper.enSHA256(Guid.NewGuid().ToString("N"));
                    secretKey = secret.Substring(0, 64);
                }
                if (string.IsNullOrEmpty(secretKey))
                {
                    response.ErrorMessage = "获取secretKey出错";
                    return Json(response);
                }

                response.StatusCode = appkey;
                response.SuccessMessage = secretKey;
            }
            catch (Exception)
            {
                response.ErrorMessage = "服务器异常";
                return Json(response);
            }
            response.Success = true;
            return Json(response);
        }

        //生成存款key和SecretKey
        [AuthorizeFilter(AuthCode.GetExtApi003)] 
        public JsonResult GetNewKeyByDeposit()
        {
            return CommonGetKey();
        }

        //生成付款key和SecretKey
        [AuthorizeFilter(AuthCode.GetExtApi004)]
        public JsonResult GetNewKeyByPayment()
        {
            return CommonGetKey();
        }

        //生成中转key和SecretKey
        [AuthorizeFilter(AuthCode.GetExtApi006)]
        public JsonResult GetNewKeyByTransfer()
        {
            return CommonGetKey();
        }

    }
}