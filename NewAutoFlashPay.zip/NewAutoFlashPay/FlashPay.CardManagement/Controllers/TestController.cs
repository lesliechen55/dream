﻿
using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using OfficeOpenXml;
    using System;
    using System.IO;
    using System.Net.Http.Headers;
    using System.Text;

    public class TestController : Controller
    {

        private IHostingEnvironment _hostingEnv;

        public TestController(IHostingEnvironment env)
        {
            this._hostingEnv = env;
        }

        /// <summary>
        /// 公用路径
        /// </summary>
        /// <returns></returns>
        private Tuple<string, string> GetTuple()
        {
            string rootFolder = _hostingEnv.WebRootPath;
            string fileName = $"{Guid.NewGuid()}.xlsx";
            return Tuple.Create(rootFolder, fileName);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult PaymentCardImport()
        {

            var file = Request.Form.Files[0];

            var filename = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');

            var severPath = _hostingEnv.WebRootPath;

            var savePath = Path.Combine(severPath, filename);

            try
            {
                using (FileStream fs = System.IO.File.Create(savePath))
                {
                    file.CopyTo(fs);
                    fs.Flush();
                }
            }
            catch (Exception ex) {
            }

            //// 原文件名（包括路径）
            //var filename = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName;
            //// 新文件名
            //string newfilename = $"{Guid.NewGuid()}" + filename.Substring(filename.LastIndexOf('.')).Replace("\"", "");
            ////服务器路径
            //string sWebRootFolder = _hostingEnvironment.WebRootPath;

            //FileInfo fileInfo = new FileInfo(Path.Combine(sWebRootFolder, newfilename));

            //try
            //{
            //    using (FileStream fs = System.IO.File.Create(Path.Combine(sWebRootFolder, newfilename)))
            //    {
            //        // 复制文件
            //        file.CopyTo(fs);
            //        // 清空缓冲区数据
            //        fs.Flush();
            //    }

            //    using (ExcelPackage package = new ExcelPackage(fileInfo))
            //    {
            //        StringBuilder sb = new StringBuilder();
            //        ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
            //        int rowCount = worksheet.Dimension.Rows;
            //        int ColCount = worksheet.Dimension.Columns;
            //        //bool bHeaderRow = true;

            //        //for (int row = 3; row <= rowCount; row++)
            //        //{
            //        //    for (int col = 1; col <= ColCount; col++)
            //        //    {
            //        //        if (bHeaderRow)
            //        //        {
            //        //            sb.Append(worksheet.Cells[row, col].Value.ToString() + "\t");
            //        //        }
            //        //        else
            //        //        {
            //        //            sb.Append(worksheet.Cells[row, col].Value.ToString() + "\t");
            //        //        }
            //        //    }
            //        //    sb.Append(Environment.NewLine);
            //        //}
            //        //var xx = sb.ToString();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    //return "Some error occured while importing." + ex.Message;
            //}
            return Content("");
    }

        /// <summary>
        /// Excel导入
        /// </summary>
        /// <param name="excelFile">Excel文件</param>
        /// <param name="sWebRootFolder">文件存储路径</param>
        ///  <param name="content">显示内容</param>
        /// <param name="isShow">是否显示内容</param>
        public static void Import(IFormFile excelFile)
        {
            //if (string.IsNullOrWhiteSpace(sWebRootFolder))
            //    content = string.Empty;

            //FileInfo file = new FileInfo(Path.Combine(sWebRootFolder, sFileName));

            //using (FileStream fs = new FileStream(file.ToString(), FileMode.Create))
            //{
            //    excelFile.CopyToAsync(fs);
            //    fs.Flush();
            //}

            ////导出单个工作表sheet
            //using (ExcelPackage package = new ExcelPackage(file))
            //{
            //    StringBuilder sb = new StringBuilder();
            //    ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
            //    int rowCount = worksheet.Dimension.Rows;
            //    int colCount = worksheet.Dimension.Columns;
            //    bool bHeaderRow = true;
            //    for (int row = 1; row <= rowCount; row++)
            //    {
            //        for (int col = 1; col <= colCount; col++)
            //        {
            //            if (bHeaderRow)
            //                sb.Append(worksheet.Cells[row, col].Value.ToString() + "\t");
            //            else
            //                sb.Append(worksheet.Cells[row, col].Value.ToString() + "\t");
            //        }
            //        sb.Append(Environment.NewLine);
            //    }
            //    content = sb.ToString();
            //}
        }

    }
}