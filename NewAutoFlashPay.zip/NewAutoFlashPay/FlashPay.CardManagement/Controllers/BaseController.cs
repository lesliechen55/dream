﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace FlashPay.CardManagement.Controllers
{
    using FlashPay.EF.Models;
    //自定义命名空间
    using FlashPay.Entity;
    using FlashPay.Entity.Enum;
    using FlashPay.Entity.Request.Log;
    using FlashPay.Entity.Response.User;
    using FlashPay.Service.Interface;
    using FlashPay.Util;

    #region 基础控制
    /// <summary>
    /// 基础控制
    /// </summary>
    public class BaseController : Controller
    {
        /// <summary>
        /// 票据
        /// </summary>
        public readonly IAuthenticate<TicketResponse> _manage;

        /// <summary>
        /// 注入
        /// </summary>
        public BaseController(IAuthenticate<TicketResponse> manage)
        {
            _manage = manage;
        }

        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            var token = string.IsNullOrEmpty(filterContext.HttpContext.Request.Query["token"])? filterContext.HttpContext.Request.Headers["token"]:filterContext.HttpContext.Request.Query["token"];

            _manage.GetTicket(token);

            if (_manage.data!=null)
            {
                if (_manage.data.UserID <= 0 || _manage.data.CompanyID <= 0 || _manage.data.MType <= 0)
                {
                    filterContext.Result = new JsonResult(new
                    {
                        Success = false,
                        ErrorMessage = "授权失败！",
                        ErrorCode = "200",
                        Callback = @"FlashPay.UI.LoginBox()"
                    });
                }
            }
            else {
                filterContext.Result = new JsonResult(new
                {
                    Success = false,
                    ErrorMessage = "授权失败！请联系管理员！",
                    ErrorCode = "200",
                    Callback = @"FlashPay.UI.LoginBox()"
                });
            }
        }
    }
    #endregion

    #region 自定义方法拦截器
    /// <summary>
    /// 自定义方法拦截器
    /// </summary>
    /// <remarks>2018-06-01 创建</remarks>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
    public class AuthorizeFilter : ActionFilterAttribute
    {
        /// <summary>
        /// 授权码列表
        /// </summary>
        public AuthCode[] Code { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="code">权限码</param>
        public AuthorizeFilter(params AuthCode[] code)
        {
            this.Code = code;
        }

        /// <summary>
        /// 拦截未登录的用户
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var IsAjaxRequest = false;

            var headers = context.HttpContext.Request.Headers.ContainsKey("x-requested-with");
            if (headers)
            {
                IsAjaxRequest = context.HttpContext.Request.Headers["x-requested-with"] == "XMLHttpRequest";
            }

            //String token = context.HttpContext.Request.Headers["token"];
            var token = string.IsNullOrEmpty(context.HttpContext.Request.Query["token"]) ? context.HttpContext.Request.Headers["token"] : context.HttpContext.Request.Query["token"];

            if (string.IsNullOrEmpty(token))
            {
                context.Result = new JsonResult(new
                {
                    Success = false,
                    ErrorCode = "200！",
                    ErrorMessage = "登录失败,token验证失败！",
                    Callback = @"FlashPay.UI.LoginBox()",
                });
            }
            else
            {
                try
                {

                    var userDataKeepViewModel = new MemoryCacheUtil().Get<TicketResponse>(EncryptHelper.deCryptDES(token));
                    if (userDataKeepViewModel == null)
                    {
                        context.Result = new JsonResult(new
                        {
                            Success = false,
                            ErrorCode = "200",
                            ErrorMessage = "登录失败，未找到Token对象！",
                            Callback = @"FlashPay.UI.LoginBox()"
                        });
                    }
                    else
                    {
                        var isAuthority = Code.Any(item => userDataKeepViewModel.UserPermission.Contains(item.ToString()));
                        if (!isAuthority)
                        {
                            int isEdit = 0;
                            if (Code.Contains(AuthCode.AllowEdit)){
                                isEdit = 1;
                            }

                            var result = new JsonResult(new
                            {
                                Success = false,
                                ErrorCode = "100",
                                Callback = string.Format("FlashPay.UI.NoPrivilege({0})", isEdit)
                            });
                            context.Result = result;
                        }
                    }
                }
                catch(Exception ex)
                {
                    context.Result = new JsonResult(new
                    {
                        Success = false,
                        ErrorCode = "200",
                        ErrorMessage = ex.Message,
                        Callback = @"FlashPay.UI.LoginBox()",
                    });
                }
            }
        }
    }
    #endregion

    #region 自定义全局异常过滤器
    // <summary>
    /// 自定义全局异常过滤器
    /// </summary>
    public class HttpGlobalExceptionFilter : ExceptionFilterAttribute
    {
        private readonly LogService _logService;

        /// <summary>
        /// 日志模型
        /// </summary>
        private readonly LogRecord _logRecord;

        /// <summary>
        /// 注入
        /// </summary>
        public HttpGlobalExceptionFilter(LogService logService,LogRecord logRecord)
        {
            this._logService = logService;
            this._logRecord = logRecord;
        }

        public override void OnException(ExceptionContext context)
        {
            var response = new JResult()
            {
                Success = false
            };

            //执行过程出现未处理异常
            Exception ex = context.Exception;

            response.ErrorCode = "500";
            response.ErrorMessage = ex.Message;

            context.Result = new JsonResult(response);
            context.HttpContext.Response.StatusCode = 200;
            context.ExceptionHandled = true;

            try
            {
                var log = new LogRecordRequest() {
                    Ip = _logRecord.Ip,
                    LogType = LogRecordLogType.Log_Add,
                    CreateName = _logRecord.CreateName,
                    CreateUid = _logRecord.CreateUid,
                    LogRemark = "系统全局日志："+ex.Message,
                    CompanyId = _logRecord.CompanyId,
                    RequestUrl = _logRecord.RequestUrl,
                    RequestData = ex.StackTrace
                };
                _logService.AddLog(log);
            }
            catch {

            }

            base.OnException(context);
        }
    }
    #endregion
    
}

namespace FlashPay.CardManagement
{
    using FlashPay.Entity;
    //自定义命名空间
    using FlashPay.Util;

    /// <summary>
    /// 认证接口
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IAuthenticate<T>
    {
        T data { set; get; }

        /// <summary>
        /// 获取票据
        /// </summary>
        /// <param name="token"></param>
        void GetTicket(string token);

        /// <summary>
        /// 设置票据
        /// </summary>
        /// <param name="token"></param>
        JResult<string> SetTicket();
    }

    public class AuthenticateImpl<T> : IAuthenticate<T>
    {

        #region 注入
        /// <summary>
        /// 缓存
        /// </summary>
        private MemoryCacheUtil _cache;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cache">缓存</param>
        public AuthenticateImpl(MemoryCacheUtil cache)
        {
            this._cache = cache;
        }
        #endregion

        public T data { set; get; }

        /// <summary>
        /// 获取票据
        /// </summary>
        /// <param name="token"></param>
        public void GetTicket(string token)
        {
            this.data = _cache.Get<T>(EncryptHelper.deCryptDES(token));
        }

        /// <summary>
        /// 设置票据
        /// </summary>
        /// <param name="token"></param>
        public JResult<string> SetTicket()
        {
            var response = new JResult<string>()
            {
                Success = false
            };

            try
            {
                //生成Token
                var token = Guid.NewGuid().ToString("N");
                //设置缓存
                var status = _cache.Set(token, data, 120);
                if (status)
                {
                    //验证是否存在
                    var existsStatus = _cache.Exists(token);
                    if (existsStatus)
                    {
                        response.Success = true;
                        response.Data = EncryptHelper.enCryptDES(token);
                    }
                }

            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
            }

            return response;
        }
    }
}