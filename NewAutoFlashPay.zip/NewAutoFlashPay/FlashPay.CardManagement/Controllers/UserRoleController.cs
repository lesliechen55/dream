﻿using FlashPay.Entity.Response.User;
using FlashPay.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    public class UserRoleController : BaseController
    {
        private readonly UserRoleService _userRoleService;
        public UserRoleController(IAuthenticate<TicketResponse> _manage, UserRoleService userRoleService) : base(_manage)
        {
            _userRoleService = userRoleService;
        }

        //根据用户ID获取角色信息
        public JsonResult GetRoleByUID(int uID)
        {
            var list = _userRoleService.GetRoleByUID(uID);
            return Json(list);
        }
    }
}