﻿using System;
using System.Linq;
using AutoMapper;
using FlashPay.Entity;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Request.Order;
using FlashPay.Entity.Response.User;
using FlashPay.Service.Interface;
using FlashPay.Service.Order;
using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    /// <summary>
    /// 訂單詳情管理
    /// </summary>
    public class OrderDetailController : BaseController
    {
        /// <summary>
        /// 订单业务
        /// </summary>
        private readonly OrderService _orderService;

        /// <summary>
        /// 订单明细业务
        /// </summary>
        private readonly OrderRecordDetailService _orderRecordDetailService;

        /// <summary>
        /// 卡商业务
        /// </summary>
        private readonly CardMerchantService _cardMerchantService;

        /// <summary>
        /// mapper
        /// </summary>
        private readonly IMapper _mapper;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="orderService">订单业务</param>
        /// <param name="orderRecordDetailService">订单明细业务</param>
        /// <param name="_manage"></param>
        public OrderDetailController(IAuthenticate<TicketResponse> _manage,OrderService orderService, OrderRecordDetailService orderRecordDetailService, CardMerchantService cardMerchantService, IMapper mapper) : base(_manage)
        {
            _orderService = orderService;
            _orderRecordDetailService = orderRecordDetailService;
            _cardMerchantService = cardMerchantService;
            _mapper = mapper;
        }

        #region 初始化
        /// <summary>
        /// 获取订单详情
        /// </summary>
        /// <param name="orderNo">订单编号</param>
        /// <param name="detailId">订单明细编号</param>
        [AuthorizeFilter(AuthCode.OrderDetail0001)]
        public JsonResult GetOrderdetail(long orderNo,int detailId) {

            var orderdetail = _orderRecordDetailService.Get(orderNo, detailId);

            orderdetail.IsAuth = false;


            if (_manage.data.UserPermission.Contains("OrderDetail0005") || _manage.data.UserPermission.Contains("Order0017"))
            {
                if (!_manage.data.UserPermission.Contains("Order0017"))
                {
                    if (_manage.data.UserID == orderdetail.OrderCreateUID)
                    {
                        orderdetail.IsAuth = true;
                    }else{
                        orderdetail.UnitPrice = "**.**";
                        orderdetail.ActualUnitPrice = "**.**";
                    }
                }else{
                    orderdetail.IsAuth = true;
                }
            }
            else
            {
                if (_manage.data.UserID == orderdetail.OrderCreateUID)
                {
                    orderdetail.IsAuth = true;
                }else{
                    orderdetail.UnitPrice = "**.**";
                    orderdetail.ActualUnitPrice = "**.**";
                }
            }

            orderdetail.IsCurrentUser = _manage.data.UserID == orderdetail.OrderCreateUID;
            return Json(orderdetail);
        }

        /// <summary>
        /// 获取订单详情
        /// </summary>
        [AuthorizeFilter(AuthCode.OrderDetail0001)]
        public JsonResult GetOrder(long orderNo)
        {
            var para = new OrderRecordDetailQuery() {
                OrderNo = orderNo,
                UserId = _manage.data.UserID,
                userPermission = _manage.data.UserPermission
            };
            var orderdetail = _orderRecordDetailService.GetOrderRecord(para);

            return Json(orderdetail);
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        [AuthorizeFilter(AuthCode.OrderDetail0001)]
        public JsonResult GetPager(OrderRecordDetailQuery query)
        {
            query.CompanyId = _manage.data.CompanyID;
            query.UserId = _manage.data.UserID;
            query.userPermission = _manage.data.UserPermission;
            //获取分页列表
            var pager = _orderRecordDetailService.GetPager(query);

            return Json(pager);
        }
        #endregion

        #region 刪除
        /// <summary>
        /// 刪除
        /// </summary>
        [AuthorizeFilter(AuthCode.OrderDetail0004)]
        public JsonResult Delete(int detailId)
        {
            var response = _orderRecordDetailService.DeleteByDetailId(_manage.data.UserPermission,_manage.data.UserID,detailId);

            return Json(response);
        }
        #endregion

        #region 新增、编辑
        /// <summary>
        /// 新增、编辑
        /// </summary>
        [AuthorizeFilter(AuthCode.OrderDetail0002, AuthCode.OrderDetail0003)]
        public JsonResult EditOrAdd(OrderRecordDetailEditOrAddRequest request)
        {
            //输出
            var response = new JResult()
            {
                Success = false
            };

            try
            {
                request.CreateUid = _manage.data.UserID;
                request.userPermission = _manage.data.UserPermission;
                request.Type = 1;
                response = _orderRecordDetailService.EditOrAdd(request);
            }
            catch (Exception ex) {
                response.ErrorMessage = ex.Message;
            }
            return Json(response);
        }

        /// <summary>
        /// 新增、编辑
        /// </summary>
        [AuthorizeFilter(AuthCode.OrderDetail0002, AuthCode.OrderDetail0003)]
        public JsonResult MakeUpEditOrAdd(OrderRecordDetailEditOrAddRequest request)
        {
            //输出
            var response = new JResult()
            {
                Success = false
            };

            try
            {
                request.CreateUid = _manage.data.UserID;
                request.userPermission = _manage.data.UserPermission;
                request.Type = 2;
                response = _orderRecordDetailService.EditOrAdd(request);
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
            }
            return Json(response);
        }
        #endregion
    }
}