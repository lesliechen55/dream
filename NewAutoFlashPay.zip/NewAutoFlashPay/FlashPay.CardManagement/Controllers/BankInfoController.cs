﻿using System;
using System.Collections.Generic;
using System.Linq;
using FlashPay.CardManagement.Mappers;
using FlashPay.CardManagement.ViewModels.Bank;
using FlashPay.EF.Models;
using FlashPay.Entity;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Request;
using FlashPay.Entity.Request.Bank;
using FlashPay.Entity.Response.Bank;
using FlashPay.Entity.Response.User;
using FlashPay.Service.Bank;
using FlashPay.Util;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace FlashPay.CardManagement.Controllers
{
    public class BankInfoController : BaseController
    {
        private readonly BankInfoService bankInfoService;
        
        public BankInfoController(IAuthenticate<TicketResponse> _manage, BankInfoService bankInfoService) : base(_manage)
        {
            this.bankInfoService = bankInfoService;
        }

        /// <summary>
        /// 銀行新增
        /// </summary>
        public JsonResult Add([FromBody] BankInfoViewModel<String> model)
        {
            /* 資料驗證 */
            /* 因目前沒有錯誤碼及錯誤提示，所以這兩個欄位先不填 */
            if (!this.TryValidateModel(model))
            {
                return Json(Mapper.MapperResponse(model));
            }

            /* 轉換Model */
            BankInfoRequest<String> request = Mapper.MapperRequest<String, String>(model);

            /* 呼叫Service層 */
            this.bankInfoService.AddBank(request);

            /* 結果複製 */
            model.Code = request.Code;
            model.Result = request.Result;
            model.Message = request.Message;
            model.Success = request.Success;

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 銀行修改
        /// </summary>
        public JsonResult Edit([FromBody] BankInfoViewModel<String> model)
        {
            /* 資料驗證 */
            /* 因目前沒有錯誤碼及錯誤提示，所以這兩個欄位先不填 */
            if (!this.TryValidateModel(model))
            {
                return Json(Mapper.MapperResponse(model));
            }

            /* 轉換Model */
            BankInfoRequest<String> request = Mapper.MapperRequest<String, String>(model);

            /* 呼叫Service層 */
            this.bankInfoService.EditBank(request);

            /* 結果複製 */
            model.Code = request.Code;
            model.Result = request.Result;
            model.Message = request.Message;
            model.Success = request.Success;

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 銀行列表
        /// </summary>
        public JsonResult Get([FromBody] BankInfoViewModel<List<Object>> model)
        {
            /* 轉換Model */
            BankInfoRequest<List<BankInfoResponse>> request = Mapper.MapperRequest<List<Object>, List<BankInfoResponse>>(model);
            
            /* 呼叫Service層 */
            this.bankInfoService.GetBank(request);

            /* 結果複製 */
            model.Code = request.Code;
            model.Result = new List<Object>(request.Result);
            model.Message = request.Message;
            model.Success = request.Success;
            model.TotalCount = request.TotalCount;

            /* 資料轉換並回傳JSON */
            return Json(Mapper.MapperResponse(model));
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList</returns>
        [AuthorizeFilter(AuthCode.Bank0001)]
        public JsonResult GetList([FromBody] BankInfoQuery query)
        {
            query.CompanyId = this._manage.data.CompanyID;

            //获取分页列表
            var pager = bankInfoService.GetList(query);
            return Json(pager);
        }

        /// <summary>
        /// 获取所有銀行信息
        /// </summary>
        /// <returns>List</returns>
        public JsonResult GetBankInfoList()
        {
            var CList = bankInfoService.GetBankInfoList();
            return Json(CList);
        }
        /// <summary>
        /// 根据编号获取银行信息
        /// </summary>
        /// <param name="SortNo">银行编号</param>
        /// <returns>BankInfo</returns>
        public JsonResult GetBankInfoByBankCode(string BankCode)
        {
            var result = bankInfoService.GetBankInfoByBankCode(BankCode);
            return Json(result);
        }
        /// <summary>
        /// 新增银行信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.Bank0002)]
        public JsonResult AddBankInfo(BankViewModel model)
        {
            if (!ModelState.IsValid)
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).FirstOrDefault();

                return Json(new JResult()
                {
                    Success = false,
                    ErrorMessage = message
                });
            }
            var Rxmodel = new BankInfo()
            {
                SortNo = model.SortNo,
                BankAddress = model.BankAddress,
                BankCode = model.BankCode,
                BankName = model.BankName,
                BankFullName = model.BankFullName,
                BankEnglishName = model.BankEnglishName,
                BankRemark = model.BankRemark,
                BankTel = model.BankTel,
                BankUrl = model.BankUrl
            };
            //日志
            var request = new Request();
            request.Ip = HttpContext.GetUserIp();
            request.CreateId = _manage.data.UserID;
            request.CreateName = _manage.data.UserName;
            request.CompanyId = _manage.data.CompanyID;
            request.RequestUrl = HttpContext.Request.Host.ToString();
            request.RequestData = JsonConvert.SerializeObject(model);

            var result = bankInfoService.AddBankInfo(Rxmodel, request);
            return Json(result);
        }
        /// <summary>
        /// 修改銀行信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.Bank0003)]
        public JsonResult UpdateBankInfo(BankInfo model)
        {
            if (!ModelState.IsValid)
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).FirstOrDefault();

                return Json(new JResult()
                {
                    Success = false,
                    ErrorMessage = message
                });
            }
            var Rxmodel = new BankInfo()
            {
                SortNo = model.SortNo,
                BankAddress = model.BankAddress,
                BankCode = model.BankCode,
                BankName = model.BankName,
                BankFullName = model.BankFullName,
                BankEnglishName = model.BankEnglishName,
                BankRemark = model.BankRemark,
                BankTel = model.BankTel,
                BankUrl = model.BankUrl
            };
            //日志
            var request = new Request();
            request.Ip = HttpContext.GetUserIp();
            request.CreateId = _manage.data.UserID;
            request.CreateName = _manage.data.UserName;
            request.CompanyId = _manage.data.CompanyID;
            request.RequestUrl = HttpContext.Request.Host.ToString();
            request.RequestData = JsonConvert.SerializeObject(model);

            var result = bankInfoService.UpdateBankInfo(Rxmodel, request);
            return Json(result);
        }

        /// <summary>
        /// 驗證模型
        /// </summary>
        protected virtual Boolean TryValidateModel(Object model)
        {
            return base.TryValidateModel(model);
        }

        /// <summary>
        /// 删除银行
        /// </summary>
        [AuthorizeFilter(AuthCode.Bank0004)]
        public JsonResult Delete(string bankCode)
        {
            JResult result = new JResult();
            if (!string.IsNullOrEmpty(bankCode))
            {
                result = bankInfoService.DeleteBankInfo(bankCode);
            }
            return Json(result);
        }
    }
}