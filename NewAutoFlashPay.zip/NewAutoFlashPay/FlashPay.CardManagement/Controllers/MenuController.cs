﻿using System;
using System.Collections.Generic;

namespace FlashPay.CardManagement.Controllers
{
    using FlashPay.CardManagement.ViewModels.Menu;
    using FlashPay.Entity;
    using FlashPay.Entity.Enum;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.Menu;
    using FlashPay.Entity.Response.User;
    using FlashPay.Service.Interface;
    using FlashPay.Util;
    using Microsoft.AspNetCore.Mvc;
    using Newtonsoft.Json;
    using System.Linq;

    /// <summary>
    /// 菜单控制器
    /// </summary>
    public class MenuController : BaseController
    {
        #region 注入
        /// <summary>
        /// 菜单业务接口
        /// </summary>
        private readonly MenuService _menuService;

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="sysRoleService"></param>
        public MenuController(IAuthenticate<TicketResponse> _manage, MenuService menuService) : base(_manage)
        {
            _menuService = menuService;
        }
        #endregion

        /// <summary>
        /// 获取节点
        /// </summary>
        /// <param name="id">菜单编号</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.Menu0001,AuthCode.AllowEdit)]
        public JsonResult GetMenuNode(int id)
        {
            var response = _menuService.GetMenuNode(id);

            return Json(response);
        }

        /// <summary>
        /// 获取节点列表
        /// </summary>
        /// <param name="id">菜单编号</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.Menu0001)]
        public JsonResult GetZtreeNodes(int? id)
        {
            var response = _menuService.GetZtreeNodes(this._manage.data.MType, id);

            return Json(response);
        }

        #region 获取子节点
        /// <summary>
        /// 获取卡管子节点
        /// </summary>
        /// <returns>JsonResult</returns>
        [AuthorizeFilter(AuthCode.Menu0001)]
        public JsonResult GetZtreeChildNodes(int? id)
        {
            var response = _menuService.GetZtreeChildNodes(_manage.data.MType, id);

            return Json(response);
        }

        /// <summary>
        /// 获取秒付宝存款子节点
        /// </summary>
        /// <returns>JsonResult</returns>
        [AuthorizeFilter(AuthCode.Menu0001)]
        public JsonResult GetDepositZtreeChildNodes(int id)
        {
            var response = _menuService.GetZtreeChildNodes(MenuType.秒付宝付款.GetHashCode(),id);

            return Json(response);
        }

        /// <summary>
        /// 获取秒付宝付款子节点
        /// </summary>
        /// <returns>JsonResult</returns>
        [AuthorizeFilter(AuthCode.Menu0001)]
        public JsonResult GetPaymentZtreeChildNodes(int id)
        {
            var response = _menuService.GetZtreeChildNodes(MenuType.秒付宝存款.GetHashCode(), id);

            return Json(response);
        }
        #endregion

        // <summary>
        /// 删除菜单
        /// </summary>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.Menu0005)]
        public JsonResult Delete(int id)
        {
            //杈撳嚭
            var response = new JResult()
            {
                Success = false
            };
            response = _menuService.Delete(id);

            return Json(response);
        }

        /// <summary>
        /// 获取功能权限
        /// </summary>
        /// <returns>JsonResult</returns>
        [AuthorizeFilter(AuthCode.Menu0001)]
        public JsonResult GetMenuPermission(MenuPermissionQuery query)
        {
            query.NodeType = this._manage.data.MType;
            var response = _menuService.GetMenuPermissionPager(query);
            return Json(response);
        }

        #region #region 新增、编辑
        /// <summary>
        /// 根据编号获取角色
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AuthorizeFilter(AuthCode.Menu0002, AuthCode.Menu0003, AuthCode.AllowEdit)]
        public JsonResult GetAddOrEdit(int id)
        {
            var response = _menuService.GetMenuNode(id);

            return Json(response);
        }

        /// <summary>
        /// 菜单 保存或更新
        /// </summary>
        /// <param name="request">菜单</param>
        /// <param name="privileges">权限</param>
        /// <returns>JsonResult</returns>
        [HttpPost]
        [AuthorizeFilter(AuthCode.Menu0002, AuthCode.Menu0003)]
        public JsonResult SaveMenu(SaveMenuRequestViewModel menu, List<int> privileges)
        {
            if (!ModelState.IsValid)
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).FirstOrDefault();

                return Json(new JResult()
                {
                    Success = false,
                    ErrorMessage = message
                });
            }

            var menuRequest = new MenuRequest()
            {
                Mid = menu.Mid,
                MParent = menu.MParent,
                MName = menu.MName,
                MUrl = menu.MUrl,
                NodeType = menu.NodeType,
                SortNo = menu.SortNo,
                MType = menu.MType,
                Hide = menu.Hide,
            };

            //日志
            menuRequest.Ip = HttpContext.GetUserIp();
            menuRequest.CreateId = _manage.data.UserID;
            menuRequest.CreateName = _manage.data.UserName;
            menuRequest.CompanyId = _manage.data.CompanyID;
            menuRequest.RequestUrl = HttpContext.Request.Host.ToString();
            menuRequest.RequestData = JsonConvert.SerializeObject(menu);

            var response = _menuService.SaveMenu(menuRequest, privileges);

            return Json(response);
        }
        #endregion
    }
}