﻿using System;

namespace FlashPay.CardManagement.Controllers
{
    using FlashPay.Util;
    using FlashPay.Service.Interface;
    using FlashPay.Entity.Response.User;
    using FlashPay.DAO.Interface;
    using FlashPay.Entity.Parameter;
    using Microsoft.AspNetCore.Mvc;
    using FlashPay.Entity;
    using System.Collections.Generic;
    using System.Linq;
    using FlashPay.EF.Models;

    /// <summary>
    /// 用户控制器
    /// </summary>
    public class UserInfoController : BaseController
    {
        #region 注入
        /// <summary>
        /// 用户业务接口
        /// </summary>
        private readonly UserInfoService _userService;

        /// <summary>
        /// 用户业务接口
        /// </summary>
        private readonly SysRoleService _roleService;

        /// <summary>
        /// 公司数据接口
        /// </summary>
        private readonly CompanyDao _companyDao;

        /// <summary>
        /// 缓存
        /// </summary>
        private readonly MemoryCacheUtil _memoryCacheUtil;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_manage"></param>
        /// <param name="userService">用户业务接口</param>
        /// <param name="memoryCacheUtil">缓存</param>
        public UserInfoController(IAuthenticate<TicketResponse> _manage, UserInfoService userService, SysRoleService roleService, CompanyDao companyDao, MemoryCacheUtil memoryCacheUtil) : base(_manage)
        {
            _memoryCacheUtil = memoryCacheUtil;
            _roleService = roleService;
            _userService = userService;
            _companyDao = companyDao;
        }
        #endregion

        /// <summary>
        /// 获取用户
        /// </summary>
        /// <param name="id">用户编号</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.User0002, AuthCode.User0003)]
        public JsonResult GetUserInfo(int? id)
        {
            var userInfo = _userService.GetById(_manage.data, id);

            return Json(userInfo);
        }


        /// <summary>
        /// 获取公司角色
        /// </summary>
        /// <param name="companyId"></param>
        [AuthorizeFilter(AuthCode.User0002, AuthCode.User0003)]
        public JsonResult GetRoleList(int companyId)
        {
            var response = _userService.GetRoleList(companyId);

            return Json(response);
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        [AuthorizeFilter(AuthCode.User0001)]
        public JsonResult GetPager(UsersQuery query)
        {
            query.CompanyId = _manage.data.CompanyID;
            query.UserId = _manage.data.UserID;
            query.UserPermission = _manage.data.UserPermission;
            query.UStatus = new List<sbyte>()
            {
                (sbyte)Entity.Enum.UserInfoStatus.启用,
                (sbyte)Entity.Enum.UserInfoStatus.禁用
            };
            var response = _userService.GetUsersPager(query);

            return Json(response);
        }

        /// <summary>
        /// 根据公司编号获取角色列表
        /// </summary>
        /// <param name="query">查询参数</param>
        /// <returns>Json</returns>
        [AuthorizeFilter(AuthCode.User0002, AuthCode.User0003)]
        public JsonResult GetRoleByCompanyId(SysRoleQuery query)
        {
            //输出
            var response = new JResult<List<SysRole>>()
            {
                Success = false
            };

            try
            {
                if (!query.RoleCompanyId.HasValue) {
                    throw new Exception("请选择公司");
                }

                query.CompanyId = _manage.data.CompanyID;
                query.RoleCompanyId = query.RoleCompanyId;
                query.CreateUId = _manage.data.UserID;

                var list = _roleService.GetRoleByCompanyId(query);
                if (list != null && list.Any())
                {
                    response.Data = list.MyDistinct(s => s.RId).ToList();
                    response.Success = true;
                }
            }
            catch (Exception ex) {
                response.ErrorMessage = ex.Message;
            }

            return Json(response);
        }


    }
}