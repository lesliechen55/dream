﻿using System;
using System.Collections.Generic;
using System.Linq;
using FlashPay.Entity;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Response.User;
using FlashPay.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    public class DepositMatchRecordController : BaseController
    {
        #region 注入
        private readonly DepositMatchRecordService _depositMatchRecordService;
        public DepositMatchRecordController(IAuthenticate<TicketResponse> _manage,DepositMatchRecordService depositMatchRecordService) : base(_manage)
        {
            _depositMatchRecordService = depositMatchRecordService;
        }
        #endregion


        //获取收款匹配记录列表
        [AuthorizeFilter(AuthCode.ReceiptMatchList001)] 
        public JsonResult GetDepositMatchRecord(DepositMatchRecordQuery query)
        {
            if (query.StartTime == null)
            {
                query.StartTime = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 00:00:00");
            }
            else
            {
                query.StartTime = Convert.ToDateTime(query.StartTime).ToString("yyyy-MM-dd 00:00:00"); ;
            }
            if (query.EndTime == null)
            {
                query.EndTime = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");
            }
            else
            {
                query.EndTime = Convert.ToDateTime(query.EndTime).ToString("yyyy-MM-dd 23:59:59");
            }
            query.CompanyId = _manage.data.CompanyID;
            query.UserPermission = _manage.data.UserPermission;

            var response = _depositMatchRecordService.GetDepositMatchRecordList(query);
            return Json(response);
        }

        //根据ID查询详细信息
        public JsonResult GetMatchRecordDetail(DepositMatchRecordQuery query)
        {
            var response = _depositMatchRecordService.GetMatchRecordDetail(query);
            return Json(response);
        }

        /// <summary>
        /// 根据规则信息查询收款记录
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        //[AuthorizeFilter(AuthCode.ReceiptMatchList005)]
        public JsonResult GetRecordListByRuleInfo(DepositMatchRecordQuery query)
        {
            var response = _depositMatchRecordService.GetRecordListByRuleInfo(query);
            return Json(response);
        }

        //设置匹配
        [AuthorizeFilter(AuthCode.ReceiptMatchList005)]
        public JsonResult SetMatchRule(DepositMatchRecordQuery query)
        {
            var response = _depositMatchRecordService.SetMatchRule(query);
            return Json(response);
        }

        //补推送
        [AuthorizeFilter(AuthCode.ReceiptMatchList006)] 
        public JsonResult AddPush(DepositMatchRecordQuery query)
        {
            var response = _depositMatchRecordService.SetMatchRule(query);
            return Json(response);
        }
    }
}