﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.DepositMatchRule;
    using FlashPay.Entity.Response.User;
    using FlashPay.Service.Interface;

    /// <summary>
    /// 匹配控制器
    /// </summary>
    /// <remarks>2018-10-01 immi 创建</remarks>
    public class DepositMatchRuleController : BaseController
    {
        #region 注入
        /// <summary>
        /// 用户业务接口
        /// </summary>
        private readonly DepositMatchRuleService _depositMatchRuleService;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_manage"></param>
        public DepositMatchRuleController(IAuthenticate<TicketResponse> _manage, DepositMatchRuleService depositMatchRuleService) : base(_manage)
        {
            _depositMatchRuleService = depositMatchRuleService;
        }
        #endregion

        /// <summary>
        /// 收款匹配规则
        /// </summary>
        [AuthorizeFilter(AuthCode.DepositMatchRule002, AuthCode.DepositMatchRule003)]
        public JsonResult GetAddOrEdit(int id)
        {
            var response = _depositMatchRuleService.Get(id,_manage.data.CompanyID);

            return Json(response);
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        [AuthorizeFilter(AuthCode.DepositMatchRule002, AuthCode.DepositMatchRule003)]
        public JsonResult DepositMatchRuleAddOrEdit(DepositMatchRuleAddOrEditRequest request)
        {
            request.CreateId = _manage.data.UserID;
            var response = _depositMatchRuleService.DepositMatchRuleAddOrEdit(request);

            return Json(response);
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="model"></param>
        [AuthorizeFilter(AuthCode.DepositMatchRule004)]
        public JsonResult DepositMatchRuleDelete(int id)
        {
            var response = _depositMatchRuleService.Delete(id,_manage.data.CompanyID);

            return Json(response);
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<PermissionResponse></returns>
        [AuthorizeFilter(AuthCode.DepositMatchRule001)]
        public JsonResult GetPager(DepositMatchRuleQuery query)
        {
            query.CompanyId = _manage.data.CompanyID;
            var pager = _depositMatchRuleService.GetPager(query);

            return Json(pager);
        }

        /// <summary>
        /// 根据companyId、bankcode查询匹配规则
        /// </summary>
        /// <param name="id">编号</param>
        public JsonResult GetRuleByCompanyId(int companyId,string bankcode)
        {
            var response = new JResult()
            {
                Success = false
            };
            if (companyId == 0)
            {
                response.ErrorMessage = "未获取公司ID";
                return Json(response);
            }
           var pager = _depositMatchRuleService.GetRuleByCompanyId(companyId, bankcode);
           return Json(pager);
        }
    }
}