﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration;

namespace FlashPay.CardManagement.Controllers
{
    using AutoMapper;
    using Demo.Entity.Config;
    using FlashPay.Entity;
    using FlashPay.Entity.Enum;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.Bank;
    using FlashPay.Entity.Response.Bank;
    using FlashPay.Entity.Response.BankCard;
    using FlashPay.Entity.Response.User;
    using FlashPay.Service.Company;
    using FlashPay.Service.Interface;
    using FlashPay.Service.Order;

    /// <summary>
    /// 银行卡控制器
    /// </summary>
    public class BankController : BaseController
    {
        #region 注入
        /// <summary>
        /// 用户业务接口
        /// </summary>
        private readonly BankService _bankService;

        /// <summary>
        /// 订单业务接口
        /// </summary>
        private readonly OrderService _orderService;

        /// <summary>
        /// 订单业务接口
        /// </summary>
        private readonly OrderRecordDetailService _recordDetailService;

        /// <summary>
        /// 公司业务接口
        /// </summary>
        private readonly CompanyService _companyService;

        /// <summary>
        /// 
        /// </summary>
        private IHostingEnvironment _hostingEnv;

        /// <summary>
        /// mapper
        /// </summary>
        private readonly IMapper _mapper;

        /// <summary>
        /// 上传配置
        /// </summary>
        private readonly UploadConfig _uploadConfig;

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="sysRoleService"></param>
        public BankController(IAuthenticate<TicketResponse> _manage, BankService bankService, OrderService orderService, OrderRecordDetailService recordDetailService, CompanyService companyService,IHostingEnvironment hostingEnv, IMapper mapper, IOptions<UploadConfig> option) : base(_manage)
        {
            _bankService = bankService;
            _orderService = orderService;
            _recordDetailService = recordDetailService;
            _companyService = companyService;
            _mapper = mapper;
            _hostingEnv = hostingEnv;
            _uploadConfig = option.Value;
        }
        #endregion

        #region 银行卡

        #region 获取银行卡
        /// <summary>
        /// 获取银行卡
        /// </summary>
        /// <param name="bcId">银行卡编号</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCard0002, AuthCode.BankCard0003)]
        public JsonResult GetBank(int bcId)
        {
            var response = _bankService.Get(_manage.data.CompanyID, bcId);
            if (response != null)
            {
                try
                {
                    var documentResponse = new List<DocumentResponse>();

                    if (response.DocumentResponse != null && response.DocumentResponse.Any())
                    {
                        response.DocumentResponse.ForEach(item =>
                        {
                            documentResponse.Add(new DocumentResponse()
                            {
                                Domain = _uploadConfig.Url,
                                URL = item.URL,
                                Sort = item.Sort
                            });
                        });

                        if (documentResponse != null && documentResponse.Any())
                        {
                            response.DocumentResponse = documentResponse;
                        }
                    }
                }
                catch (Exception ex) {

                }

            }
            //最大上传图片数量
            response.Maximum = _uploadConfig.Maximum;
            return Json(response);
        }
        #endregion

        #region 银行卡修改
        /// <summary>
        /// 银行卡
        /// </summary>
        /// <param name="request">参数</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCard0002, AuthCode.BankCard0003)]
        public JsonResult BankEditOrAdd(BankEditOrAddRequest request)
        {
            var response = _bankService.EditOrAdd(request);
            return Json(response);
        }
        #endregion

        #region 银行卡分页查询
        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        [AuthorizeFilter(AuthCode.BankCard0001)]
        public JsonResult GetPager(BankQuery query)
        {
            query.CompanyId = this._manage.data.CompanyID;
            query.UserID = this._manage.data.UserID;

            //银行卡状态
            var enableStatus = new List<sbyte>()
            {
                (sbyte)EnableStatus.有效.GetHashCode(),
                (sbyte)EnableStatus.禁用.GetHashCode()
            };
            //移除不能自己sbyte
            if (query.EnableStatus.HasValue) {
                //验证参数是否包含在数组中
                if (enableStatus.Contains(query.EnableStatus.Value)){
                    enableStatus.RemoveAll(p => p != query.EnableStatus.Value);
                }
            }

            query.EnableStatusArray = enableStatus;

            var companys = _companyService.GetList();

            var pager = _bankService.GetPager(query);

            var list = new List<BankPagerResponse>();

            foreach (var item in pager.TData) {

                var bankPagerResponse = _mapper.Map<BankPagerResponse>(item);

                var company = companys.FirstOrDefault(p => p.CompanyId == item.BankCardCompanyId);
                if (company != null) {
                    bankPagerResponse.CompanyName = company.CompanyName;
                    bankPagerResponse.CompanyNameEN = company.CompanyNameEn;
                }

                list.Add(bankPagerResponse);
            }

            pager.TData = list;
            return Json(pager);
        }
        #endregion

        #region 银行卡更新状态
        /// <summary>
        /// 更新状态
        /// </summary>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCard0004)]
        public JsonResult UpdateStatus(int id, SByte status)
        {
            //输出
            var response = new JResult()
            {
                Success = false
            };

            //银行卡状态
            var enableStatus = new List<sbyte>()
            {
                (sbyte)EnableStatus.有效.GetHashCode(),
                (sbyte)EnableStatus.禁用.GetHashCode()
            };

            //验证参数是否包含在数组中
            if (enableStatus.Contains(status))
            {
                response = _bankService.UpdateEnableStatus(id, status);
            }
            else {
                response.ErrorMessage = "参数错误！";
            }
            

            return Json(response);
        }


        #endregion

        #endregion

        #region 库存卡

        #region 获取银行卡
        /// <summary>
        /// 获取银行卡
        /// </summary>
        /// <param name="bcId">银行卡编号</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0002, AuthCode.BankCardSpare0003)]
        public JsonResult GetStockBank(int bcId)
        {
            var response = _bankService.Get(_manage.data.CompanyID, bcId);
            if (response != null)
            {
                try
                {
                    var documentResponse = new List<DocumentResponse>();

                    if (response.DocumentResponse != null && response.DocumentResponse.Any())
                    {
                        response.DocumentResponse.ForEach(item =>
                        {
                            documentResponse.Add(new DocumentResponse()
                            {
                                Domain = _uploadConfig.Url,
                                URL = item.URL,
                                Sort = item.Sort
                            });
                        });

                        if (documentResponse != null && documentResponse.Any())
                        {
                            response.DocumentResponse = documentResponse;
                        }
                    }
                }
                catch (Exception ex)
                {

                }

            }
            //最大上传图片数量
            response.Maximum = _uploadConfig.Maximum;
            response.Domain = _uploadConfig.Url;
            return Json(response);
        }
        #endregion

        #region 库存卡银行卡修改
        /// <summary>
        /// 银行卡
        /// </summary>
        /// <param name="request">参数</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0002, AuthCode.BankCardSpare0003)]
        public JsonResult StockCardAddOrEdit(StockCardAddOrEditRequest request)
        {
            request.CompanyId = this._manage.data.CompanyID;
            request.CreateUid = this._manage.data.UserID;
            var response = _bankService.StockCardAddOrEdit(request);
            return Json(response);
        }
        #endregion

        #region 库存卡更新授权状态
        /// <summary>
        /// 更新授权状态
        /// </summary>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0004)]
        public JsonResult UpdateAuthStatus(int id, SByte status)
        {
            //输出
            var response = new JResult()
            {
                Success = false
            };

            //银行卡状态
            var enableStatus = new List<sbyte>()
            {
                (sbyte)EnableStatus.禁用.GetHashCode(),
                (sbyte)EnableStatus.未授权.GetHashCode()
            };

            //验证参数是否包含在数组中
            if (enableStatus.Contains(status))
            {
                response = _bankService.UpdateAuthStatus(id, status);
            }
            else
            {
                response.ErrorMessage = "参数错误！";
            }


            return Json(response);
        }
        #endregion

        #region 库存卡刪除
        /// <summary>
        /// 库存卡刪除
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0005)]
        public JsonResult StockCardDelete(int id)
        {
            var response = new JResult()
            {
                Success = false
            };

            response = _bankService.StockCardDelete(id);

            return Json(response);
        }
        #endregion

        #region 作废
        /// <summary>
        /// 作废
        /// </summary>
        /// <param name="bcId"></param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0008)]
        public JsonResult Obsolete(int id)
        {
            var response = new JResult()
            {
                Success = false
            };

            response = _bankService.Obsolete(id);

            return Json(response);
        }
        #endregion

        #region 库存卡分页
        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0001, AuthCode.BankCardSpare0006, AuthCode.BankCardSpare0007)]
        public JsonResult GetStockPager(BankCardQuery query)
        {
            query.CompanyId = this._manage.data.CompanyID;
            query.CreateUid = this._manage.data.UserID;
            query.CardType = (sbyte)CardType.备用卡.GetHashCode();
            query.UserPermission = _manage.data.UserPermission;
            query.EnableStatusList = new List<sbyte>
            {
                (sbyte)EnableStatus.禁用.GetHashCode(),
                (sbyte)EnableStatus.未授权.GetHashCode()
            };

            var pager = _bankService.GetSparePager(query);

            return Json(pager);
        }
        #endregion

        #endregion

        #region B2B银行卡

        #region 银行卡获取
        /// <summary>
        /// 获取银行卡
        /// </summary>
        /// <param name="bcId">银行卡编号</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCard0002, AuthCode.BankCard0003)]
        public JsonResult GetB2BBank(int bcId)
        {
            var response = _bankService.Get(_manage.data.CompanyID, bcId);
            if (response != null)
            {
                try
                {
                    var documentResponse = new List<DocumentResponse>();

                    if (response.DocumentResponse != null && response.DocumentResponse.Any())
                    {
                        response.DocumentResponse.ForEach(item =>
                        {
                            documentResponse.Add(new DocumentResponse()
                            {
                                Domain = _uploadConfig.Url,
                                URL = item.URL,
                                Sort = item.Sort
                            });
                        });

                        if (documentResponse != null && documentResponse.Any())
                        {
                            response.DocumentResponse = documentResponse;
                        }
                    }
                }
                catch (Exception ex)
                {

                }

            }
            //最大上传图片数量
            response.Maximum = _uploadConfig.Maximum;
            return Json(response);
        }
        #endregion

        #region 银行卡修改
        /// <summary>
        /// 银行卡
        /// </summary>
        /// <param name="request">参数</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCard0002, AuthCode.BankCard0003)]
        public JsonResult B2BBankEditOrAdd(BankEditOrAddRequest request)
        {
            request.UserId = _manage.data.UserID;

            var response = _bankService.B2BEditOrAdd(request);
            return Json(response);
        }
        #endregion

        #region 银行卡更新状态
        /// <summary>
        /// 更新状态
        /// </summary>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCard0004)]
        public JsonResult B2BUpdateStatus(int id, SByte status)
        {
            //输出
            var response = new JResult()
            {
                Success = false
            };

            //银行卡状态
            var enableStatus = new List<sbyte>()
            {
                (sbyte)EnableStatus.有效.GetHashCode(),
                (sbyte)EnableStatus.禁用.GetHashCode()
            };

            //验证参数是否包含在数组中
            if (enableStatus.Contains(status))
            {
                response = _bankService.B2BUpdateEnableStatus(id, status);
            }
            else
            {
                response.ErrorMessage = "参数错误！";
            }


            return Json(response);
        }


        #endregion

        #region 银行卡分页
        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        [AuthorizeFilter(AuthCode.BankCard0001)]
        public JsonResult GetB2BPager(BankQuery query)
        {
            query.CompanyId = this._manage.data.CompanyID;
            query.UserID = this._manage.data.UserID;
            //银行卡状态
            var enableStatus = new List<sbyte>()
            {
                (sbyte)EnableStatus.有效.GetHashCode(),
                (sbyte)EnableStatus.禁用.GetHashCode()
            };
            //移除不能自己sbyte
            if (query.EnableStatus.HasValue)
            {
                //验证参数是否包含在数组中
                if (enableStatus.Contains(query.EnableStatus.Value))
                {
                    enableStatus.RemoveAll(p => p != query.EnableStatus.Value);
                }
            }

            query.EnableStatusArray = enableStatus;

            var companys = _companyService.GetList();

            var pager = _bankService.GetB2BPager(query);

            var list = new List<BankPagerResponse>();

            foreach (var item in pager.TData)
            {

                var bankPagerResponse = _mapper.Map<BankPagerResponse>(item);

                var company = companys.FirstOrDefault(p => p.CompanyId == item.BankCardCompanyId);
                if (company != null)
                {
                    bankPagerResponse.CompanyName = company.CompanyName;
                    bankPagerResponse.CompanyNameEN = company.CompanyNameEn;
                }

                list.Add(bankPagerResponse);
            }

            pager.TData = list;
            return Json(pager);
        }
        #endregion

        #endregion

        #region B2B库存卡

        #region 库存卡获取
        /// <summary>
        /// 获取银行卡
        /// </summary>
        /// <param name="bcId">银行卡编号</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0002, AuthCode.BankCardSpare0003)]
        public JsonResult GetB2BStockBank(int bcId)
        {
            var response = _bankService.Get(_manage.data.CompanyID, bcId);
            if (response != null)
            {
                try
                {
                    var documentResponse = new List<DocumentResponse>();

                    if (response.DocumentResponse != null && response.DocumentResponse.Any())
                    {
                        response.DocumentResponse.ForEach(item =>
                        {
                            documentResponse.Add(new DocumentResponse()
                            {
                                Domain = _uploadConfig.Url,
                                URL = item.URL,
                                Sort = item.Sort
                            });
                        });

                        if (documentResponse != null && documentResponse.Any())
                        {
                            response.DocumentResponse = documentResponse;
                        }
                    }
                }
                catch (Exception ex)
                {

                }

            }
            //最大上传图片数量
            response.Maximum = _uploadConfig.Maximum;
            response.Domain = _uploadConfig.Url;
            return Json(response);
        }
        #endregion

        #region 库存卡修改
        /// <summary>
        /// 银行卡
        /// </summary>
        /// <param name="request">参数</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0002, AuthCode.BankCardSpare0003)]
        public JsonResult B2BStockCardAddOrEdit(StockCardAddOrEditRequest request)
        {
            request.CompanyId = this._manage.data.CompanyID;
            request.CreateUid = this._manage.data.UserID;
            var response = _bankService.B2BStockCardAddOrEdit(request);
            return Json(response);
        }
        #endregion

        #region 库存卡授权
        /// <summary>
        /// 更新授权状态
        /// </summary>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0004)]
        public JsonResult B2BUpdateAuthStatus(int id, SByte status)
        {
            //输出
            var response = new JResult()
            {
                Success = false
            };

            //银行卡状态
            var enableStatus = new List<sbyte>()
            {
                (sbyte)EnableStatus.禁用.GetHashCode(),
                (sbyte)EnableStatus.未授权.GetHashCode()
            };

            //验证参数是否包含在数组中
            if (enableStatus.Contains(status))
            {
                response = _bankService.B2BUpdateAuthStatus(id, status);
            }
            else
            {
                response.ErrorMessage = "参数错误！";
            }


            return Json(response);
        }
        #endregion

        #region 库存卡刪除
        /// <summary>
        /// 库存卡刪除
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0005)]
        public JsonResult B2BStockCardDelete(int id)
        {
            var response = new JResult()
            {
                Success = false
            };

            response = _bankService.B2BStockCardDelete(id);

            return Json(response);
        }
        #endregion

        #region 库存卡分页
        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        [AuthorizeFilter(AuthCode.BankCardSpare0001, AuthCode.BankCardSpare0006, AuthCode.BankCardSpare0007)]
        public JsonResult GetB2BStockPager(BankCardQuery query)
        {
            query.CompanyId = this._manage.data.CompanyID;
            query.CreateUid = this._manage.data.UserID;
            query.CardType = (sbyte)CardType.备用卡.GetHashCode();
            query.UserPermission = _manage.data.UserPermission;
            query.EnableStatusList = new List<sbyte>
            {
                (sbyte)EnableStatus.禁用.GetHashCode(),
                (sbyte)EnableStatus.未授权.GetHashCode()
            };

            var pager = _bankService.GetB2BSparePager(query);

            return Json(pager);
        }
        #endregion

        #endregion

        #region 作废卡管理列表
        [AuthorizeFilter(AuthCode.BankCardSpare0009)]
        public JsonResult GetObsoleteCard(BankCardQuery query)
        {
            query.CompanyId = this._manage.data.CompanyID;
            query.CreateUid = this._manage.data.UserID;
            query.CardType = (sbyte)CardType.作废卡.GetHashCode();
            query.UserPermission = _manage.data.UserPermission;
            query.EnableStatusList = new List<sbyte>
            {
                (sbyte)EnableStatus.禁用.GetHashCode(),
                (sbyte)EnableStatus.未授权.GetHashCode()
            };

            if (query.StartTime == null)
            {
                query.StartTime = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 00:00:00");
            }
            else
            {
                query.StartTime = Convert.ToDateTime(query.StartTime).ToString("yyyy-MM-dd 00:00:00");
            }
            if (query.EndTime == null)
            {
                query.EndTime = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");
            }
            else
            {
                query.EndTime = Convert.ToDateTime(query.EndTime).ToString("yyyy-MM-dd 23:59:59");
            }

            var pager = _bankService.GetB2BSparePager(query);

            return Json(pager);
        }
        #endregion

        #region 上传图片
        public IConfiguration Configuration { get; set; }
        public JsonResult UploadFiles(int filecount)
        {
            var response = new JResult<List<DocumentResponse>>
            {
                Success = false
            };

            var list = new List<DocumentResponse>();
            string WebRootPath = _uploadConfig.SavePath;
            string ShowPath = _uploadConfig.Url;
            int Maximum = _uploadConfig.Maximum;

            if (string.IsNullOrEmpty(WebRootPath) || string.IsNullOrEmpty(ShowPath))
            {
                response.ErrorMessage = "无法上传,未配置上传地址！";
                return Json(response);
            }

            var files = Request.Form.Files;

            try
            {
                if (files.Count == 0)
                {
                    response.ErrorMessage = "未检测到文件";
                    return Json(response);
                }

                if (Maximum == 0)
                {
                    response.ErrorMessage = "不支持上传文件,请修改配置！";
                    return Json(response);
                }

                if (filecount + files.Count > Maximum)
                {
                    response.ErrorMessage = "最多只能上传" + Maximum + "张图片,您选择的图片过多";
                    return Json(response);
                }

                //格式限制
                var allowType = new string[] { ".jpg", ".jpeg", ".png", ".gif" };

                for (int i = 0; i < files.Count; i++)
                {
                    int j = i + 1;
                    if (j <= Maximum)
                    {
                        //扩展名
                        var extensionName = Path.GetExtension(files[i].FileName);

                        if (allowType.Any(p => p == extensionName))
                        {
                            // 文件名
                            var fileName = Guid.NewGuid().ToString("N") + extensionName;

                            //创建文件夹
                            if (!Directory.Exists(WebRootPath))
                                Directory.CreateDirectory(WebRootPath);

                            //物理路径
                            string savePath = Path.Combine(WebRootPath, fileName);

                            //保存文件
                            using (FileStream fs = new FileStream(savePath, FileMode.CreateNew))
                            {
                                files[i].CopyTo(fs);
                                fs.Flush();

                                DocumentResponse dr = new DocumentResponse();
                                dr.Domain = ShowPath;
                                dr.URL = fileName;
                                dr.Sort = j.ToString();
                                dr.Description = files[i].FileName;
                                list.Add(dr);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                return Json(response);
            }

            if (list.Count > 0)
            {
                response.Success = true;
                response.SuccessMessage = "成功上传:" + files.Count + "张图片,失败:" + (files.Count - list.Count) + "张";
                response.Data = list;
            }
            else
            {
                response.ErrorMessage = "图片格式不正确";
            }
            return Json(response);
        }
        #endregion
    }
}