﻿using FlashPay.Entity;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Response.User;
using FlashPay.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    public class LogRecordController : BaseController
    {
        private readonly LogService log_service;
        public LogRecordController(IAuthenticate<TicketResponse> _manage, LogService logService) : base(_manage)
        {
            this.log_service = logService;
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList</returns>
        [AuthorizeFilter(AuthCode.Log0001)]
        public JsonResult Get([FromBody]LogQuery query)
        {
            //只能看到自己下属公司的日志列表
            query.CompanyId = _manage.data.CompanyID;

            //获取分页列表
            var pager = log_service.GetPager(query);
            return Json(pager);
        }

        public JsonResult Delete(int logId)
        {
            var pager = log_service.Delete(logId);
            return Json(pager);
        }

        public JsonResult GetLogTypes()
        {
            var result = log_service.GetLogTypes();
            return Json(result);
        }

        public JsonResult GetIPs([FromBody]LogQuery query)
        {
            query.CompanyId = _manage.data.CompanyID;
            var result = log_service.GetIPs(query);
            return Json(result);
        }
    }
}