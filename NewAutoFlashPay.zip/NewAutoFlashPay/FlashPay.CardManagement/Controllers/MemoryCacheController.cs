﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace FlashPay.CardManagement.Controllers
{
    using FlashPay.Entity;
    using FlashPay.Entity.Response.User;
    using FlashPay.Util;

    /// <summary>
    /// 缓存控制器
    /// </summary>
    /// <remarks>2018-10-01 immi 创建</remarks>
    public class MemoryCacheController : BaseController
    {
        #region 注入
        /// <summary>
        /// 缓存
        /// </summary>
        private readonly  MemoryCacheUtil _memoryCacheUtil;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_manage"></param>
        public MemoryCacheController(IAuthenticate<TicketResponse> _manage, MemoryCacheUtil memoryCacheUtil) : base(_manage)
        {
            _memoryCacheUtil = memoryCacheUtil;
        }
        #endregion

        /// <summary>
        /// 获取所有缓存键
        /// </summary>
        public JsonResult GetCacheKeys()
        {
            var response = new JResult<List<string>>() {
                Success = false
            };

            var cacheKeys = _memoryCacheUtil.GetCacheKeys();

            return Json(response);
        }
    }
}