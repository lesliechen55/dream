﻿using System;
using System.Collections.Generic;

namespace FlashPay.CardManagement.Controllers
{
    using FlashPay.Entity;
    using FlashPay.Entity.Enum;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.Payment;
    using FlashPay.Entity.Response.Payment;
    using FlashPay.Entity.Response.User;
    using FlashPay.Service.Interface;
    using FlashPay.Util;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;
    using System.IO;

    /// <summary>
    /// 付款控制器
    /// </summary>
    /// <remarks>2018-08-27 immi 创建</remarks>
    public class PaymentController : BaseController
    {
        #region 注入
        /// <summary>
        /// 余额变化业层接口
        /// </summary>
        private readonly AdjustBalanceService _adjustBalanceService;

        /// <summary>
        /// 付款记录业务接口
        /// </summary>
        private readonly PaymentRecordService _paymentRecordService;

        /// <summary>
        /// 实际付款记录业务接口
        /// </summary>
        private readonly RecordRealService _recordRealService;

        /// <summary>
        /// 用户业务接口
        /// </summary>
        private readonly BankService _bankService;

        /// <summary>
        /// 
        /// </summary>
        private IHostingEnvironment _hostingEnv;

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="_manage"></param>
        /// <param name="paymentRecordService">余额变化业层接口</param>
        /// <param name="adjustBalanceService">付款记录业务接口</param>
        /// <param name="recordRealService">实际付款记录业务接口</param>
        public PaymentController(IAuthenticate<TicketResponse> _manage, PaymentRecordService paymentRecordService, AdjustBalanceService adjustBalanceService, RecordRealService recordRealService, BankService bankService, IHostingEnvironment env) : base(_manage)
        {
            _paymentRecordService = paymentRecordService;
            _adjustBalanceService = adjustBalanceService;
            _recordRealService = recordRealService;
            _bankService = bankService;
            _hostingEnv = env;
        }
        #endregion

        #region 付款卡
        /// <summary>
        /// 付款卡管理
        /// </summary>
        /// <returns>JResult</returns>
        [AuthorizeFilter(AuthCode.PaymentCard0001)]
        public JsonResult PaymentCardPager(PaymentCardQuery query)
        {
            query.CompanyId = _manage.data.CompanyID;
            query.UserPermission = _manage.data.UserPermission;
            var list = _paymentRecordService.GetPaymentCardPager(query);
            return Json(list);
        }

        /// <summary>
        /// 获取付款卡
        /// </summary>
        /// <param name="bcId">银行卡编号</param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.PaymentCard0002)]
        public JsonResult GetPaymentCard(int bcId)
        {
            var response = _bankService.Get(_manage.data.CompanyID, bcId);
            
            return Json(response);
        }

        /// <summary>
        /// 付款卡编辑
        /// </summary>
        /// <param name="bcId">银行卡编号</param>
        [AuthorizeFilter(AuthCode.PaymentCard0002)]
        public JsonResult PaymentCardEdit(PaymentCardEditRequest request)
        {
            var response = _bankService.PaymentCardEdit(request);

            return Json(response);
        }

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.PaymentCard0003)]
        public JsonResult PaymentCardUpdateStatus(int id, SByte status)
        {
            //输出
            var response = new JResult()
            {
                Success = false
            };

            //银行卡状态
            var enableStatus = new List<sbyte>()
            {
                (sbyte)EnableStatus.有效.GetHashCode(),
                (sbyte)EnableStatus.禁用.GetHashCode()
            };

            //验证参数是否包含在数组中
            if (enableStatus.Contains(status))
            {
                response = _bankService.UpdateEnableStatus(id, status);
            }
            else
            {
                response.ErrorMessage = "参数错误！";
            }


            return Json(response);
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        public JsonResult UploadFiles()
        {
            var response = new JResult()
            {
                Success = false
            };

            try
            {
                // 文件大小
                long size = 0;

                if (Request.Form.Files.Count == 0)
                {
                    throw new Exception("未检测到文件");
                }

                var files = Request.Form.Files;

                foreach (var file in files)
                {
                    //扩展名
                    var extensionName = Path.GetExtension(file.FileName);
                    // 原文件名（包括路径）
                    var fileName = Path.Combine("uploadfiles", Guid.NewGuid().ToString("N") + extensionName);
                    //创建文件夹
                    if (!Directory.Exists(_hostingEnv.WebRootPath + @"\uploadfiles"))
                        Directory.CreateDirectory(_hostingEnv.WebRootPath + @"\uploadfiles");
                    //物理路径
                    string savePath = Path.Combine(_hostingEnv.WebRootPath, fileName);
                    //保存文件
                    using (FileStream fs = new FileStream(savePath, FileMode.CreateNew))
                    {
                        file.CopyTo(fs);
                        fs.Flush();
                    }
                }

                //var file = Request.Form.Files[0];

                //格式限制
                //var allowType = new string[] { "image/jpg", "image/png" };

            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
            }

            return Json(response);
        }
        #endregion

        #region 付款记录
        /// <summary>
        /// 付款记录
        /// </summary>
        /// <returns>JResult</returns>
        [AuthorizeFilter(AuthCode.PaymentRecord0001)]
        public JsonResult GetPaymentRecords(PaymentRecordQuery query)
        {
            query.PaymentType = PaymentType.付款;
            if (!string.IsNullOrEmpty(query.StartTime) && !string.IsNullOrEmpty(query.EndTime))
            {
                if (WebUtil.IsDate(query.StartTime) && WebUtil.IsDate(query.EndTime))
                {

                    var startTime = Convert.ToDateTime(query.StartTime);
                    var endTime = Convert.ToDateTime(query.EndTime);

                    query.StartTime = Convert.ToDateTime(query.StartTime).ToString("yyyy-MM-dd 00:00:00");
                    query.EndTime = Convert.ToDateTime(query.EndTime).ToString("yyyy-MM-dd 23:59:59");
                }
                else
                {
                    query.StartTime = DateTime.Now.ToString("yyyy-MM-dd 00:00:00");
                    query.EndTime = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");
                }
            }
            else
            {
                query.StartTime = DateTime.Now.ToString("yyyy-MM-dd 00:00:00");
                query.EndTime = DateTime.Now.ToString("yyyy-MM-dd 23:59:59");
            }
            query.CompanyId = _manage.data.CompanyID;
            var list = _paymentRecordService.GetPaymentRecordPager(query);
            return Json(list);
        }

        /// <summary>
        /// 获取付款记录
        /// </summary>
        /// <param name="request"></param>
        /// <returns>JResult</returns>
        [AuthorizeFilter(AuthCode.PaymentRecord0002)]
        public JsonResult GetPaymentRecord(PaymentCardRequest request)
        {
            var response = new JResult<PaymentCardResponse>()
            {
                Success = true
            };

            request.CompanyId = _manage.data.CompanyID;

            var paymentRecord = _paymentRecordService.GetPaymentCard(request);
            if (paymentRecord != null)
            {
                response.Data = paymentRecord;
            }

            return Json(response);
        }

        /// <summary>
        /// 新增付款卡
        /// </summary>
        /// <returns>JResult</returns>
        [AuthorizeFilter(AuthCode.PaymentRecord0002)]
        public JsonResult PaymentRecordAdd(PaymentRecordAddRequest request)
        {
            request.CurrentCompanyId = _manage.data.CompanyID;

            var response = _paymentRecordService.PaymentRecordAdd(request);

            return Json(response);
        }

        /// <summary>
        /// 付款记录取消
        /// </summary>
        /// <returns>JResult</returns>
        [AuthorizeFilter(AuthCode.PaymentRecord0004)]
        public JsonResult PaymentRecordCancel(long orderNo)
        {
            //验证订单
            var response = _paymentRecordService.PaymentRecordCancel(orderNo);
            return Json(response);
        }

        /// <summary>
        /// 付款记录重置
        /// </summary>
        /// <returns>JResult</returns>
        [AuthorizeFilter(AuthCode.PaymentRecord0003)]
        public JsonResult PaymentRecordReset(long orderNo)
        {
            //验证订单

            var response = _paymentRecordService.PaymentRecordReset(orderNo);
            return Json(response);
        }

        /// <summary>
        /// 获取付款记录的真实付款记录
        /// </summary>
        /// <returns>JResult</returns>
        [AuthorizeFilter(AuthCode.PaymentRecord0005)]
        public JsonResult PaymentRecordReals(long orderNo,int minutes)
        {

            var response = new JResult<List<PaymentRecordRealResponse>>()
            {
                Success = true
            };

            if (minutes < 10 || minutes > 1440)
            {
                response.Success = false;
                response.ErrorMessage = "匹配时间(分)介于 10 和 1440 之间";
                return Json(response);
            }

            response.Data = _recordRealService.GetPaymentRecordReals(new PaymentRecordRealQuery() { OrderNo = orderNo,Minutes = minutes });

            return Json(response);
        }

        /// <summary>
        /// 转成功
        /// </summary>
        /// <param name="reqeust">参数</param>
        /// <returns>JResult</returns>
        [AuthorizeFilter(AuthCode.PaymentRecord0006)]
        public JsonResult TurnSuccess(TurnReqeust reqeust)
        {
            //验证订单

            reqeust.UserId = _manage.data.UserID;
            var response = _recordRealService.TurnSuccess(reqeust);
            return Json(response);
        }

        /// <summary>
        /// 转失败
        /// </summary>
        /// <param name="reqeust">参数</param>
        /// <returns>JResult</returns>
        [AuthorizeFilter(AuthCode.PaymentRecord0006)]
        public JsonResult TurnFailure(TurnReqeust reqeust)
        {
            //验证订单
            reqeust.UserId = _manage.data.UserID;
            var response = _recordRealService.TurnFailure(reqeust);
            return Json(response);
        }

        /// <summary>
        /// 付款确认(获取付款记录)
        /// </summary>
        /// <param name="request">参数</param>
        [AuthorizeFilter(AuthCode.PaymentRecord0008)]
        public JsonResult GetPaymentConfirm(long id)
        {
            var response = new JResult<RecordRealResponse>() {
                Success = false
            };

            response.Data = _paymentRecordService.Get(id);
            response.Success = true;

            return Json(response);
        }

        /// <summary>
        /// 付款确认
        /// </summary>
        /// <param name="request">参数</param>
        [AuthorizeFilter(AuthCode.PaymentRecord0008)]
        public JsonResult PaymentConfirm(long orderNo)
        {
            //验证订单
            var request = new PaymentConfirmRequest()
            {
                OrderNo = orderNo,
                ConfirmUID = _manage.data.UserID,
                ConfirmName = _manage.data.UserName
            };

            var response = _paymentRecordService.PaymentConfirm(request);

            return Json(response);
        }
        #endregion

        #region 实际付款记录
        /// <summary>
        /// 实际付款记录
        /// </summary>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.RecordReal0001)]
        public JsonResult RecordReal(RecordRealQuery query)
        {
            query.RecordType = (int)AdjustStatus.付款;
            return CommonReal(query);
        }

        //公共方法
        private JsonResult CommonReal(RecordRealQuery query)
        {
            var response = new JResult()
            {
                Success = false
            };
            var now = DateTime.Now;
            //本月的第一天
            var firstDay = new DateTime(now.Year, now.Month, 1);
            //本月的最后一天
            var lastDay = now.AddDays(1 - now.Day).AddMonths(1).AddDays(-1);

            query.RecordType = query.RecordType;

            if (!string.IsNullOrEmpty(query.StartTime) && !string.IsNullOrEmpty(query.EndTime))
            {
                if (WebUtil.IsDate(query.StartTime) && WebUtil.IsDate(query.EndTime))
                {
                    //TODO 两个时间之差不能大于6个月
                    var startTime = Convert.ToDateTime(query.StartTime);
                    var endTime = Convert.ToDateTime(query.EndTime);
                    if (startTime > endTime)
                    {
                        response.ErrorMessage = "开始时间不能大于结束时间";
                        return Json(response);
                    }
                    query.StartTime = Convert.ToDateTime(query.StartTime).AddDays(-1).ToString("yyyy-MM-dd 00:00:00");
                    query.EndTime = Convert.ToDateTime(query.EndTime).ToString("yyyy-MM-dd 23:59:59");
                }
                else
                {
                    query.StartTime = firstDay.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss");
                    query.EndTime = lastDay.ToString("yyyy-MM-dd 23:59:59");
                }
            }
            else
            {
                query.StartTime = firstDay.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss");
                query.EndTime = lastDay.ToString("yyyy-MM-dd 23:59:59");
            }
            query.CompanyId = _manage.data.CompanyID;
            var list = _recordRealService.GetPaymentRecordPager(query);
            return Json(list);
        }
        #endregion

        #region 未入账收款纪录
        /// <summary>
        /// 未入账收款纪录
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.ReceiptAccounted0001)]
        public JsonResult ReceiptList(RecordRealQuery query)
        {
            query.RecordType = (int)AdjustStatus.收款;
            return CommonReal(query);
        }

        /// <summary>
        /// 补单
        /// </summary>
        /// <param name="request"></param>
        [AuthorizeFilter(AuthCode.ReceiptAccounted0002)]
        public JsonResult GetReceiptMakeUp(long orderNo)
        {
            var response = _recordRealService.GetByOrderNo(orderNo);
            return Json(response);
        }

        /// <summary>
        /// 补单
        /// </summary>
        /// <param name="request"></param>
        [AuthorizeFilter(AuthCode.ReceiptAccounted0002)]
        public JsonResult ReceiptMakeUp(ReceiptMakeUpRequest request)
        {
            var response = _paymentRecordService.ReceiptMakeUp(request);

            return Json(response);
        }
        #endregion

        #region 付款余额变化表
        /// <summary>
        /// 付款余额变化表
        /// </summary>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.PaymentAdjustBalance0001)]
        public JsonResult PaymentAdjustBalance(PaymentAdjustBalanceQuery query)
        {
            var response = new JResult()
            {
                Success = false
            };
            var now = DateTime.Now;

            if (!string.IsNullOrEmpty(query.StartTime))
            {
                if (WebUtil.IsDate(query.StartTime))
                {
                    query.StartTime = Convert.ToDateTime(query.StartTime).ToString("yyyy-MM-dd 00:00:00");
                    query.EndTime = Convert.ToDateTime(query.StartTime).ToString("yyyy-MM-dd 23:59:59");
                }
                else
                {
                    query.StartTime = now.ToString("yyyy-MM-dd HH:mm:ss");
                    query.EndTime = now.ToString("yyyy-MM-dd 23:59:59");
                }
            }
            else
            {
                query.StartTime = now.ToString("yyyy-MM-dd HH:mm:ss");
                query.EndTime = now.ToString("yyyy-MM-dd 23:59:59");
            }

            query.CompanyId = _manage.data.CompanyID;
            var list = _adjustBalanceService.GetPaymentAdjustBalancePager(query);
            return Json(list);
        }
        #endregion

        #region 收款卡余额变化表
        /// <summary>
        /// 收款余额变化表
        /// </summary>
        /// <returns></returns>
        [AuthorizeFilter(AuthCode.ReceiptBalance0001)]
        public JsonResult ReceiptBalance(PaymentAdjustBalanceQuery query)
        {
            var response = new JResult()
            {
                Success = false
            };

            if (!string.IsNullOrEmpty(query.StartTime) && WebUtil.IsDate(query.StartTime))
            {
                var startTime = Convert.ToDateTime(query.StartTime);
                query.StartTime = startTime.ToString("yyyy-MM-dd 00:00:00");
                query.EndTime = startTime.ToString("yyyy-MM-dd 23:59:59");
            }
            else
            {
                var now = DateTime.Now;
                query.StartTime = now.ToString("yyyy-MM-dd 00:00:00");
                query.EndTime = now.ToString("yyyy-MM-dd 23:59:59");
            }
            query.CompanyId = _manage.data.CompanyID;
            var list = _adjustBalanceService.GetPaymentAdjustBalancePager(query);
            return Json(list);
        }
        #endregion


    }
}