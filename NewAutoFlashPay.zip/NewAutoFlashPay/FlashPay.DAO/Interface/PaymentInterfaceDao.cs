﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF;
    using FlashPay.EF.Models;

    /// <summary>
    /// 付款接口
    /// </summary>
    public interface PaymentInterfaceDao
    {
        /// <summary>
        /// 根据付款接口
        /// </summary>
        PaymentInterface GetById(int companyId);

        /// <summary>
        /// 新增付款接口
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        int Add(PaymentInterface model);

        /// <summary>
        /// 更新付款接口
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool Update(PaymentInterface model);
    }
}
