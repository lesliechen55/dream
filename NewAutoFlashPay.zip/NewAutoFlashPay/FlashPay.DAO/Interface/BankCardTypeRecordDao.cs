﻿using FlashPay.EF.Models;
using FlashPay.Entity.Parameter;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    public interface BankCardTypeRecordDao
    {
        List<BankCardTypeRecord> GetCardTypeRecordList(BankCardTypeRecordQuery query);
    }
}
