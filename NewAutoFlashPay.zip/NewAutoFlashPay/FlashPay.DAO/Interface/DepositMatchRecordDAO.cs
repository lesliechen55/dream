﻿using FlashPay.EF.Models;
using FlashPay.Entity;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Request.DepositMatchRecord;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    public interface DepositMatchRecordDAO
    {
        /// <summary>
        /// 获取收款匹配记录列表
        /// </summary>
        DataGrid<DepositMatchRecordResponse> GetDepositMatchRecordList(DepositMatchRecordQuery query);

        /// <summary>
        /// 根据ID查询详细信息
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        DepositMatchRecord GetMatchRecordDetail(DepositMatchRecordQuery query);

        /// <summary>
        /// 设置匹配
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        int SetMatchRule(DepositMatchRecordQuery query);
        
    }
}
