﻿using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.Payment;

    /// <summary>
    /// 余额变化数据接口			
    /// </summary>
    public interface AdjustBalanceDao
    {
        /// <summary>
        /// 根据编号获取余额变化记录
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>Company</returns>
        AdjustBalance Get(long id);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        long Add(AdjustBalance model);

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool Update(AdjustBalance model);

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        bool UpdateStatus(int id, SByte status);

        /// <summary>
        /// 获取所有记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<UserInfo></returns>
        List<AdjustBalance> GetList(AdjustBalanceQuery query);

        /// <summary>
        /// 付款卡余额变化查询
        /// </summary>
        /// <param name="query">参数</param>
        PagedList<PaymentAdjustBalanceResponse> GetPaymentAdjustBalancePager(PaymentAdjustBalanceQuery query);
    }
}
