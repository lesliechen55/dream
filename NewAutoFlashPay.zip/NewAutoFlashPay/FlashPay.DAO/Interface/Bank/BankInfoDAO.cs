﻿using FlashPay.EF.Models;
using FlashPay.Entity;
using FlashPay.Entity.DAORequest.Bank;
using FlashPay.Entity.Parameter;
using FlashPay.Util;
using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Bank
{
   public interface BankInfoDAO : IDisposable
   {
        /// <summary>
        /// 根据银行编码获取银行
        /// </summary>
        /// <param name="bankCode">银行编码</param>
        /// <returns>菜单</returns>
        BankInfo GetByBankCode(string bankCode);

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        PagedList<BankInfo> GetList(BankInfoQuery query);

        /// <summary>
        /// 获取所有銀行信息
        /// </summary>
        /// <returns></returns>
        List<BankInfo> GetBankInfoList();
        

        void Add(BaseModel<String> result, BankInfo model);
        void EditUseBankId(BaseModel<String> result, BankInfo model);
        void Get(BaseModel<List<BankInfo>> result, BankInfo model);
        void Get(BaseModel<List<BankInfo>> result, BankInfoRequest model);
        BankInfo GetBankInfoByBankCode(string BankCode);

        /// <summary>
        /// 新增银行信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        JResult AddBankInfo(BankInfo model);

        /// <summary>
        /// 修改銀行信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        bool UpdateBankInfo(BankInfo model);

        bool Delete(string bankCode, out bool isUse);

        //根据bankcode字符串查询中文银行名称
        string GetBankNameByStr(string withdrawalBank);
    }
}
