﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.Transfer;

    /// <summary>
    /// 中转卡数据接口
    /// </summary>
    public interface TransferDao : IDisposable
    {
        /// <summary>
        /// 获取中转卡
        /// </summary>
        /// <param name="query">查看参数</param>
        PagedList<TransferCardResponse> TransferCardPager(TransferCardQuery query);

        /// <summary>
        /// 获取中转卡记录
        /// </summary>
        /// <param name="query">查看参数</param>
        DataGrid<TransferCardRecordResponse> TransferCardRecordPager(TransferCardRecordQuery query);
    }
}
