﻿using System;

namespace FlashPay.DAO.Report
{
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.Report;
    using System.Collections.Generic;

    /// <summary>
    /// 报表数据接口
    /// </summary>
    public interface ReportStatisticsDao : IDisposable
    {
        /// <summary>
        /// 获取所有报表
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<UserInfo></returns>
        List<ReportStatistics> GetList(ReportStatisticsQuery query);

        /// <summary>
        /// 获取公司月报表
        /// </summary>
        List<ReportByMonthResponse> GetReportByMonth(ReportStatisticsQuery query);

        /// <summary>
        /// 获取公司年报表
        /// </summary>
        List<ReportStatisticsNew> GetReportByYear(ReportStatisticsQuery query);
    }
}
