﻿using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF.Models;
    using FlashPay.Entity.Request.Menu;

    /// <summary>
    /// 菜单数据接口
    /// </summary>
    public interface MenuDao
    {
        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>Menu</returns>
        Menu Get(int id);

        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        Company GetById(int id);

        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        BankInfo GetBankInfoByBankCode(string bankCode);

        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        OrderRecord GetOrderRecordByOrderNo(long orderNo);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        int Add(Menu model);

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool Update(Menu model);

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        bool UpdateStatus(int id, sbyte status);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <returns></returns>
        bool Delete(int mId);

        /// <summary>
        /// 获取菜单列表
        /// </summary>
        /// <param name="ids">系统编号列表</param>
        /// <returns>菜单列表</returns>
        List<Menu> GetListByIds(List<int> ids);

        /// <summary>
        /// 根据条件获取菜单列表
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<Menu></returns>
        List<Menu> GetList(MenuQueryRequest request);
    }
}
