﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Util;

    /// <summary>
    /// 角色数据接口
    /// </summary>
    public interface SysRoleDao : IDisposable
    {
        /// <summary>
        /// 根据编号获取用户
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>Company</returns>
        SysRole Get(int id, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 根据编号获取系统角色
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>SysRole</returns>
        List<SysRole> GetByUserId(int userId, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 获取用户角色
        /// </summary>
        /// <returns>List<UserRole></returns>
        List<SysRole> GetByCompanyIds(List<int> ids, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        JResult<SysRole> Add(SysRole model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        JResult<SysRole> Update(SysRole model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        bool UpdateStatus(int id, SByte status);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <returns></returns>
        bool Delete(int rId);

        /// <summary>
        /// 根据条件获取所有角色记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<SysRole></returns>
        List<SysRole> GetList(SysRoleQuery query, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 获取公司角色编号
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<UserInfo></returns>
        List<SysRole> GetRoleByCompanyId(SysRoleQuery query);

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        PagedList<SysRole> GetPager(SysRoleQuery query);


        void Get(BaseModel<List<SysRole>> result, SysRole model);

        List<SysRole> GetRoleByCompanyId(int companyId, FlashPayContext flashPayContext = null);
        List<SysRole> GetRoleByCreateIdAndCompanyId(int companyId, List<int> createIds, FlashPayContext flashPayContext = null);

    }
}
