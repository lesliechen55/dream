﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlashPay.Entity;
using FlashPay.EF.Models;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Response.CardMerchant;
using FlashPay.Util;
using FlashPay.Entity.DAORequest.CardMerchant;

namespace FlashPay.DAO.Interface
{
    /// <summary>
    /// 卡商数据接口
    /// </summary>
    public interface CardMerchantDao : IDisposable
    {
        /// <summary>
        /// 根据编号获取卡商
        /// </summary>
        /// <param name="Cmid">编号</param>
        /// <returns>CardMerchant</returns>
        CardMerchant Get(int Cmid);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="CardMerchant">新增对象</param>
        /// <returns></returns>
        bool Add(CardMerchant model, out bool isExist);

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool Update(CardMerchant model);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="Cmid">编号</param>
        /// <returns></returns>
        bool Delete(int Cmid, out bool isUse);

        /// <summary>
        /// 获取所有卡商记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<CardMerchant></returns>
        List<CardMerchant> GetList(CardMerchantQuery query);

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<CardMerchant></returns>
        PagedList<CardMerchantResponse> GetPager(CardMerchantQuery model);

        void Get(BaseModel<List<CardMerchant>> result, CardMerchantRequest model);
        void Get2(BaseModel<List<CardMerchant>> result, CardMerchantRequest model);
        /// <summary>
        /// 通过条件获取卡商信息
        /// </summary>
        /// <param name="SearchValue">搜索值</param>
        /// <param name="SearchType">值类型</param>
        /// <returns>List<CardMerchant></returns>
        List<CardMerchantResponse> SearchCardMerchant(CardMerchantQuery query);
    }
}
