﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using System.Collections.Generic;

    /// <summary>
    /// 用户数据接口
    /// </summary>
    public interface UserRoleDao
    {
        /// <summary>
        /// 根据编号获取用户
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>Company</returns>
        UserRole Get(int id);

        /// <summary>
        /// 获取用户角色
        /// </summary>
        /// <returns>List<UserRole></returns>
        List<UserRole> GetByUserIds(List<int> ids);

        /// <summary>
        /// 删除用户角色
        /// </summary>
        /// <param name="menuId">用户编号</param>
        /// <returns></returns>
        bool DeleteByUserId(int userId, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        JResult<UserRole> Add(UserRole model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 根据角色编号获取用户角色数据
        /// </summary>
        /// <param name="roleId">角色编号</param>
        List<UserRole> GetByRoleId(int roleId);

        /// 根据用户ID获取角色信息
        PagedList<UserRole> GetRoleByUID(int uID);

        //获取用户角色值
        ICollection<UserRole> GetUserRoleList(int uID);

        //更新用户角色
        int UpdateUserRole(UserInfoQuery query);

        /// <summary>
        /// 删除URId等于roleId
        /// </summary>
        /// <param name="menuId">角色编号</param>
        /// <returns></returns>
        bool DeleteByroleRId(int roleRId);
    }
}
