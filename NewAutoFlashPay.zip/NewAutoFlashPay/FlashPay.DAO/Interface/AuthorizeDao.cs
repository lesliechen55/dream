﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Util;

    /// <summary>
    /// 授权数据接口
    /// </summary>
    public interface AuthorizeDao : IDisposable
    {
        /// <summary>
        /// 获取功能权限列表
        /// </summary>
        /// <param name="roleSysNo">角色编号</param>
        /// <returns>功能权限列表</returns>
        IList<Authorize> GetPermissionListRoleSysNo(int roleSysNo);

        /// <summary>
        /// 获取功能权限列表
        /// </summary>
        /// <param name="roleId">角色编号</param>
        /// <returns>功能权限列表</returns>
        IList<Authorize> GetPermissionListRole(int userId);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        int Add(Authorize model,FlashPayContext flashPayContext = null);

        /// <summary>
        /// 删除角色所有数据
        /// </summary>
        /// <param name="roleSysNo">角色编号</param>
        /// <returns></returns>
        bool DeleteByRoleSysNo(int roleSysNo, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="authPId">系统编号</param>
        /// <returns></returns>
        bool DeleteByAuthId(int authId, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="authPId">系统编号</param>
        /// <returns></returns>
        bool DeleteByAuthId(List<int> authIds, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 获取功能权限列表
        /// </summary>
        /// <param name="roleId">角色编号</param>
        /// <param name="authType">授权类型</param>
        /// <returns>功能权限列表</returns>
        IList<Authorize> GetPermissionByRoleSysNo(List<int> roleId, List<int> unselectedPIds, int authType, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 获取所有用户记录
        /// </summary>
        /// <param name="request">查询条件</param>
        /// <returns>List<UserInfo></returns>
        List<Authorize> GetList(AuthorizeQuery request);

        /// <summary>
        /// 获取所有用户记录
        /// </summary>
        /// <param name="request">查询条件</param>
        /// <returns>List<UserInfo></returns>
        List<Authorize> GetMenuAuthorizes(AuthorizeQuery request);
    }
}
