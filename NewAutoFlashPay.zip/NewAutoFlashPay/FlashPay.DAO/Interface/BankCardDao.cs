﻿using FlashPay.EF.Models;
using FlashPay.Entity;
using FlashPay.Entity.DAORequest.Bank;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Response.BankCard;
using FlashPay.Entity.Response.Order;
using FlashPay.Util;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    public interface BankCardDao: IDisposable
    {
        void Get(BaseModel<List<BankCard>> result, BankCardRequest model);

        /// <summary>
        /// 获取所有銀行卡记录
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        List<BankCard> GetList(BankCardQuery query);

        /// <summary>
        /// 获取库存卡报表
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<CardMerchant></returns>
        List<BankCardExpResponse> GetPareListExp(BankCardQuery query);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        long Insert(BankCard model);

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="model"></param>
        bool Update(BankCard model);

        /// <summary>
        /// 库存卡查询
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        PagedList<SpareBankCardResponse> GetSparePager(BankCardQuery query);

        /// <summary>
        /// 分頁查詢所有銀行卡
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        PagedList<BankCardResponse> GetPager(BankCardQuery query, bool isSpare = false);

        /// <summary>
        /// 根据编号获取银行卡信息
        /// </summary>
        /// <param name="bcid">银行卡编号</param>
        /// <returns>CardMerchant</returns>
        BankCard GetBankCardByBcid(int bcid);

        /// <summary>
        /// 根据银行卡号获取银行卡额外信息
        /// </summary>
        /// <param name="CardNumber"></param>
        /// <returns></returns>
        List<BankCardExtraLimit> GetBankCardLimitByCardNumber(string CardNum);

        /// <summary>
        /// 根据银行卡号获取银行卡是否存在
        /// </summary>
        /// <param name="cardnumber">银行卡号</param>
        /// <returns>CardMerchant</returns>
        bool GetBankCardByCardnumber(string Cardnumber);

        /// <summary>
        /// 根据银行卡号获取银行卡额外限制是否存在
        /// </summary>
        /// <param name="cardnumber">银行卡号</param>
        /// <returns>CardMerchant</returns>
        bool GetBankCardLimitByCardnumber(string Cardnumber);

        /// <summary>
        /// 根据卡号或者用户名获取银行卡信息
        /// </summary>
        /// <param name="NumberOrName">银行卡号或者银行卡用户名</param>
        /// <param name="Strwhere">栏位</param>
        /// <returns></returns>
        List<BankCard> GetBankCardByNumberOrName(string NumberOrName, string Strwhere);

        /// <summary>
        /// 新增銀行卡信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        bool AddBankCard(BankCard model, bool isSpare = false);
        /// <summary>
        /// 修改銀行卡信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        bool UpdateBankCard(BankCard model, BankCardExtraLimit modelEx);
        /// <summary>
        /// 刪除銀行卡
        /// </summary>
        /// <param name="bcid"></param>
        /// <returns></returns>
        bool DeleteBankCard(int Bcid, bool isSpare = false);
        /// <summary>
        /// 更改银行卡启用状态
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        bool ChangeBankCardSta(BankCard model);

        #region 获取订单
        /// <summary>
        /// 查询(押金审核人>0 And 收货审核人=0 And 付款审核人=0 )
        /// </summary>
        /// <param name="query"></param>
        List<AuditingOrderRecordResponse> GetAuditingOrderRecord(UserInfoQuery query);
        #endregion
    }
}
