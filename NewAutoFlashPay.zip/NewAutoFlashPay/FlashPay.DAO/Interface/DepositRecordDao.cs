﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF.Models;

    /// <summary>
    /// 收款记录数据接口
    /// </summary>
    /// <remarks>2018-07-09 immi 创建</remarks>
    public interface DepositRecordDao
    {
    }
}
