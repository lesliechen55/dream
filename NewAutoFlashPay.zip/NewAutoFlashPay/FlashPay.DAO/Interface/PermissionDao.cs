﻿using FlashPay.EF.Models;
using FlashPay.Entity;
using FlashPay.Entity.Parameter;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    public interface PermissionDao
    {
        /// <summary>
        /// 根据编号获取权限功能
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>Permission</returns>
        Permission Get(int id);

        //查詢所有功能列表
        List<Permission> GetList(PermissionQuery query);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        int Add(Permission model);

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="model"></param>
        bool Update(Permission model);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <returns></returns>
        bool Delete(int id);

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        bool UpdateStatus(int id, sbyte status);

        /// <summary>
        /// 获取功能权限列表
        /// </summary>
        /// <param name="sysNoList">系统编号列表</param>
        /// <returns>功能权限列表</returns>
        List<Permission> GetListByIds(List<int> ids);

        /// <summary>
        /// 获取功能权限列表
        /// </summary>
        /// <param name="sysNoList">权限编号列表</param>
        /// <returns>功能权限列表</returns>
        List<Permission> GetListByCodes(List<string> codes);

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<Permission></returns>
        PagedList<Permission> GetPager(PermissionQuery query);
    }
}
