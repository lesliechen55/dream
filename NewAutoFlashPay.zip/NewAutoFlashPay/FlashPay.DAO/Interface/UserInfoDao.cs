﻿using System;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.DAORequest.User;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.Role;
    using FlashPay.Entity.Response.User;
    using FlashPay.Util;
    using System.Collections.Generic;

    /// <summary>
    /// 用户数据接口
    /// </summary>
    public interface UserInfoDao : IDisposable
    {
        /// <summary>
        /// 根据编号获取用户
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>Company</returns>
        UserInfo Get(int id);

        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="loginName"></param>
        /// <returns></returns>
        UserInfo Login(string loginName);

        /// <summary>
        /// 根据编号获取用户(SQL)
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>UserInfo</returns>
        UserInfo GetUserInfo(int id);

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="model"></param>
        bool UpdateUserInfo(UserInfo model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更新用户密码
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <param name="passWord">用户密码</param>
        /// <returns></returns>
        bool UpdatePassWord(int id, string passWord);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        int Insert(UserInfo model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="model"></param>
        bool Update(UserInfo model);

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        int UpdateStatus(UserInfoQuery query);

        /// <summary>
        /// 更新谷歌验证状态
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        int ChangeLoggedIn(UserInfo query);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <returns></returns>
        int Delete(UserInfoQuery query, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 获取用户下拉列表
        /// </summary>
        /// <returns>List<UserInfo></returns>
        List<UserInfo> GetList(UserInfoQuery query);

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        PagedList<UserInfo> GetPager(UserInfoQuery query);

        //根据id集合查出用户信息
        PagedList<UserInfo> GetUserInfoByIds(List<int> query, int pageIndex, int pageSize);

        //登录名是否已存在
        bool CheckLoginName(UserInfoQuery query);

        //原密码是否正确
        bool CheckOldPwd(UserInfoQuery query);

        //保存用户信息
        int SaveUserInfo(UserInfo query);

        void Get(BaseModel<List<UserInfo>> result, UserRequest model);

        // 通过条件获取用户信息
        List<UserInfo> SearchUserInfo(string SearchValue, int CompanyId);

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        PagedList<UsersResponse> GetUsersPager(UsersQuery query);

        /// <summary>
        /// 获取公司角色
        /// </summary>
        /// <param name="companyId"></param>
        List<RoleResponse> GetRoleList(int companyId);
    }
}
