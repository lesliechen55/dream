﻿
using System.Collections.Generic;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.Bank;
    using FlashPay.Entity.Response.BankCard;
    using FlashPay.Entity.Response.Company;

    /// <summary>
    /// 银行数据接口
    /// </summary>
    public interface BankDao
    {
        /// <summary>
        /// 根据银行卡信息
        /// </summary>
        BankCard GetById(int bcId, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 新增行卡信息
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        int Add(BankCard model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更新行卡信息
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool Update(BankCard model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 银行额外限制[根据银行卡信息]
        /// </summary>
        BankCardExtraLimit GetByCardNumber(string cardNumber, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 银行额外限制【新增行卡信息】
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        string BankCardExtraLimitAdd(BankCardExtraLimit model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 银行额外限制【更新行卡信息】
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool BankCardExtraLimitUpdate(BankCardExtraLimit model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更改银行卡启用状态
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        bool UpdateEnableStatus(int bcId, sbyte enableStatus);

        /// <summary>
        /// 刪除銀行卡
        /// </summary>
        /// <param name="bcid">系统编号</param>
        /// <returns></returns>
        bool DeleteByBcId(int bcId);

        /// <summary>
        /// 作废
        /// </summary>
        /// <param name="bcId"></param>
        /// <returns></returns>
        bool Obsolete(int bcId);

        /// <summary>
        /// 获取所有銀行卡记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<CardMerchant></returns>
        List<BankCard> GetList(BankQuery query);

        /// <summary>
        /// 获取所有銀行卡记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<CardMerchant></returns>
        List<BankPagerResponse> GetList();

        /// <summary>
        /// 根据编号获取公司
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>Company</returns>
        List<CompanyResponse> GetCompany(int companyId, int level = 2);

        //获取CompanyID集合
        List<int> GetCompanyIDList(int companyId, int level = 2);

        /// <summary>
        /// 银行卡分页
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        PagedList<BankPagerResponse> GetPager(BankQuery query);

        /// <summary>
        /// 库存卡分页
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        PagedList<SpareBankCardResponse> GetSparePager(BankCardQuery query);

        /// <summary>
        /// 库存卡分页
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        PagedList<SpareBankCardResponse> GetB2BSparePager(BankCardQuery query);

        /// <summary>
        /// 银行卡分页
        /// </summary>
        /// <param name="query">查询参数</param>
        /// <returns></returns>
        PagedList<BankPagerResponse> GetB2BPager(BankQuery query);

        /// <summary>
        /// 获取中转卡
        /// </summary>
        /// <param name="bcId"></param>
        TransportCard GetTransportCard(int bcId, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 新增中转卡
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        int TransportCardAdd(TransportCard model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更新中转卡
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool TransportCardUpdate(TransportCard model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 新增银行卡类型记录
        /// </summary>
        /// <param name="userInfo">银行卡类型记录对象</param>
        /// <returns></returns>
        int BankCardTypeRecordAdd(BankCardTypeRecord model, FlashPayContext flashPayContext = null);
    }
}
