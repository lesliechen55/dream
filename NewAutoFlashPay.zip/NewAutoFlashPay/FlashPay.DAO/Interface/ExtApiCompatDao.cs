﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity.Parameter;

    /// <summary>
    /// 授权数据接口
    /// </summary>
    public interface ExtApiCompatDao
    {
        /// <summary>
        /// 获取
        /// </summary>
        /// <param name="id">编号</param>
        ExtApiCompat Get(int id);

        /// <summary>
        /// 获取
        /// </summary>
        /// <param name="id">编号</param>
        ExtApiCompat Get(int id, int type);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        int Add(ExtApiCompat model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更新授权
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool Update(ExtApiCompat model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 查看
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        List<ExtApiCompat> GetList(ExtApiCompatQuery query);
    }
}
