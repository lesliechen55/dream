﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.DepositMatchRule;

    /// <summary>
    /// 收款匹配规则数据接口
    /// </summary>
    public interface DepositMatchRuleDao
    {
        /// <summary>
        /// 获取
        /// </summary>
        /// <param name="id">编号</param>
        DepositMatchRule Get(int id);

        /// <summary>
        /// 根据companyId、bankcode查询匹配规则
        /// </summary>
        /// <param name="companyId"></param>
        /// <returns></returns>
        DepositMatchRule GetRuleByCompanyId(int companyId,string bankcode);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        int Add(DepositMatchRule model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool Update(DepositMatchRule model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <returns></returns>
        bool Delete(int id);

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        List<DepositMatchRule> GetList(DepositMatchRuleQuery query);

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<Permission></returns>
        PagedList<DepositMatchRuleResponse> GetPager(DepositMatchRuleQuery query);
    }
}
