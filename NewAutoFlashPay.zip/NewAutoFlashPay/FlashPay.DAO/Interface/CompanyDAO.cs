﻿using FlashPay.EF;
using FlashPay.EF.Models;
using FlashPay.Entity.DAORequest.Company;
using FlashPay.Entity.Parameter;
using FlashPay.Util;
using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Interface
{
    public interface CompanyDao : IDisposable
    {
        /// <summary>
        /// 获取公司
        /// </summary>
        EF.Models.Company GetById(int companyId, FlashPayContext flashPayContext = null);

        void Add(BaseModel<String> result, EF.Models.Company model);
        void EditUseCompanyIdAndCompanyPid(BaseModel<String> result, EF.Models.Company model);
        void Get(BaseModel<List<EF.Models.Company>> result, EF.Models.Company model, Int32 level = 1);
        void Get(BaseModel<List<EF.Models.Company>> result, CompanyRequest model, Int32 level = 1);
        BaseModel<List<EF.Models.Company>> Get();

        /// <summary>
        /// 获取所有公司
        /// </summary>
        /// <returns>List<Company></returns>
        List<Company> GetList(CompanyQuery query);

        /// <summary>
        /// 根据ID集合获取所有公司列表
        /// </summary>
        /// <returns>List<Company></returns>
        List<EF.Models.Company> GetCompanyListByIds(List<int> ids);
    }
}
