﻿using FlashPay.EF.Models;
using FlashPay.Entity;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Response.Order;
using FlashPay.Util;
using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Order
{
    public interface OrderRecordDetailDao : IDisposable
    {
        /// <summary>
        /// 根据编号获取订单明细
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>SysRole</returns>
        OrderRecordDetailResponse Get(int detailId);

        /// <summary>
        /// 根据编号获取系统订单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>SysRole</returns>
        OrderRecordDetail GetOrderRecordDetail(long DetailId);

        /// <summary>
        /// 根据编号获取系统订单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>SysRole</returns>
        OrderRecord GetOrderRecord(long orderNo);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        JResult<OrderRecordDetail> Add(OrderRecordDetail model);

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="model"></param>
        bool Update(OrderRecordDetail model);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="detailId">系统编号</param>
        /// <returns></returns>
        bool DeleteByDetailId(int detailId);

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<Permission></returns>
        PagedList<OrderRecordDetailResponse> GetPager(OrderRecordDetailQuery query);

        /// <summary>
        /// 订单明细查找
        /// </summary>
        /// <param name="query">参数</param>
        List<OrderRecordDetail> GetList(OrderRecordDetailQuery query);

        #region 老代码
        void Add(BaseModel<String> result, OrderRecordDetail model);
        void EditUseDetailId(BaseModel<String> result, OrderRecordDetail model);
        void DeleteUseDetailId(BaseModel<String> result, OrderRecordDetail model);
        void Get(BaseModel<List<OrderRecordDetail>> result, OrderRecordDetail model);
        #endregion
    }
}
