﻿using FlashPay.EF.Models;
using FlashPay.Entity.DAORequest.Order;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Response.Order;
using FlashPay.Util;
using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Order
{
    public interface OrderRecordDAO : IDisposable
    {
        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        OrderRecord Get(long orderNo);
        void Add(BaseModel<String> result, OrderRecord model);
        void EditUseOrderNo(BaseModel<String> result, OrderRecord model);
        void DeleteUseOrderNo(BaseModel<String> result, OrderRecord model);
        void Get(BaseModel<List<OrderRecord>> result, OrderRecordRequest model);
        List<OrderRecord> GetFinishOrderNo(BankCardQuery query);
        List<OrderRecord> GetNoFinishOrderNo(BankCardQuery query);

        /// <summary>
        /// 查询(押金审核人>0 And 收货审核人=0 And 付款审核人=0 )
        /// </summary>
        /// <param name="companyIds"></param>
        List<OrderRecord> GetAuditingOrderRecord(List<int> companyIds);
    }
}
