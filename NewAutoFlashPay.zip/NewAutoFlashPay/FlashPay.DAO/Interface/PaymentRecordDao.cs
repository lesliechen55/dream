﻿using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.Payment;
    using FlashPay.Entity.Response.Company;
    using FlashPay.Entity.Response.Payment;

    /// <summary>
    /// 付款记录数据接口
    /// </summary>
    /// <remarks>2018-07-09 immi 创建</remarks>
    public interface PaymentRecordDao
    {
        /// <summary>
        /// 根据编号获取余额变化记录
        /// </summary>
        /// <param name="orderNo">编号</param>
        /// <returns>Company</returns>
        PaymentRecord Get(long orderNo);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        long Add(PaymentRecord model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool Update(PaymentRecord model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// UpdateRecordRealOrderNo
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool UpdateRecordRealOrderNo(long orderNo, long recordRealOrderNo, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="orderNo">编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        bool UpdatePaymentStatus(long orderNo, SByte paymentStatus);

        /// <summary>
        /// 更新通知状态
        /// </summary>
        /// <param name="orderNo">编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        bool UpdateNoticeStatus(long orderNo, SByte noticeStatus, int noticeTimes);

        /// <summary>
        /// 付款确认
        /// </summary>
        /// <param name="request">参数</param>
        bool PaymentConfirm(PaymentConfirmRequest request);

        /// <summary>
        /// 获取所有记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<UserInfo></returns>
        List<PaymentRecord> GetList(PaymentRecordQuery query);

        /// <summary>
        ///  获取付款卡公司
        /// </summary>
        List<CompanyResponse> GetPaymentRecordCompanys(PaymentRecordCompanyQuery query);

        /// <summary>
        /// 付款卡查询
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        PagedList<PaymentCardResponse> GetPaymentCardPager(PaymentCardQuery query);

        /// <summary>
        /// 付款记录查询
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        DataGrid<PaymentRecordResponse> GetPaymentRecordPager(PaymentRecordQuery query);

        /// <summary>
        /// 补单
        /// </summary>
        /// <param name="request"></param>
        JResult ReceiptMakeUp(ReceiptMakeUpRequest request);
    }
}
