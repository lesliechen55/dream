﻿using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.Payment;
    using FlashPay.Entity.Response.Payment;

    /// <summary>
    /// 实际付款数据接口			
    /// </summary>
    public interface RecordRealDao
    {
        /// <summary>
        /// 根据编号获取余额变化记录
        /// </summary>
        /// <param name="orderNo">编号</param>
        /// <returns>Company</returns>
        RecordReal Get(long orderNo);

        /// <summary>
        /// 根据编号获取余额变化记录
        /// </summary>
        /// <param name="orderNo">编号</param>
        /// <returns>Company</returns>
        RecordRealGetResponse GetByOrderNo(long orderNo);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        long Add(RecordReal model);

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool Update(RecordReal model);

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        bool UpdateStatus(int id, SByte status);

        /// <summary>
        /// 转成功
        /// </summary>
        /// <param name="reqeust">参数</param>
        /// <returns></returns>
        JResult TurnSuccess(TurnReqeust reqeust);

        /// <summary>
        /// 转失败
        /// </summary>
        /// <param name="reqeust">参数</param>
        /// <returns></returns>
        JResult TurnFailure(TurnReqeust reqeust);

        /// <summary>
        /// 获取所有记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<UserInfo></returns>
        List<RecordReal> GetList(RecordRealQuery query);

        /// <summary>
        /// 获取付款记录的真实付款记录
        /// </summary>
        /// <returns></returns>
        List<PaymentRecordRealResponse> GetPaymentRecordReals(PaymentRecordRealQuery query);

        /// <summary>
        /// 已实际付款记录
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        DataGrid<RecordRealResponse> GetPaymentRecordPager(RecordRealQuery query);
    }
}
