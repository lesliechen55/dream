﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.ExtApi;

    /// <summary>
    /// 推送数据接口
    /// </summary>
    public interface ExtApiPushUrlDao
    {
        /// <summary>
        /// 获取
        /// </summary>
        /// <param name="id">编号</param>
        ExtApiPushUrl Get(int id);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        int Add(ExtApiPushUrl model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更新授权
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        bool Update(ExtApiPushUrl model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        List<ExtApiPushUrl> GetList(ExtApiPushUrlQuery query);

        /// <summary>
        /// 删除授权
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        int ExtApiPushUrlDel(ExtApiPushUrlAddOrEditRequest model);
    }
}
