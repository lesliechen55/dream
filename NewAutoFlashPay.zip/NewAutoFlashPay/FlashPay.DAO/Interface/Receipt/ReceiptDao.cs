﻿using FlashPay.Entity;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Response.Payment;
using System;

namespace FlashPay.DAO.Interface.Receipt
{
   public interface ReceiptDao : IDisposable
    {
        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<UserInfo></returns>
        PagedList<PaymentCardResponse> GetList(PaymentCardQuery query);

        //获取付款纪录列表
        PagedList<DepositOrPaymentRecordResponse> GetReceiptRecordList(PaymentRecordQuery query);

        /// <summary>
        /// 存款记录查询
        /// </summary>
        /// <param name="query">查询条件</param>
        DataGrid<DepositRecordResponse> GetReceiptRecord(DepositRecordQuery query);

        /// <summary>
        /// 重置付款记录
        /// </summary>
        /// <param name="orderNo">订单号</param>
        bool ResetNoticeStatus(long orderNo);

        /// <summary>
        /// 补推送
        /// </summary>
        /// <param name="orderNo">订单编号</param>
        /// <returns></returns>
        bool AddPush(long orderNo);
    }
}
