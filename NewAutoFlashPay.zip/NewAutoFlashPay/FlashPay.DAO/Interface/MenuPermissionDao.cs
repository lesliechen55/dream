﻿using FlashPay.EF.Models;
using FlashPay.EF.View;
using FlashPay.Entity;
using FlashPay.Entity.Parameter;
using System.Collections.Generic;

namespace FlashPay.DAO.Interface
{
    /// <summary>
    /// 菜单功能权限数据接口
    /// </summary>
    public interface MenuPermissionDao
    {
        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        MenuPermission Get(int id);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        int Add(MenuPermission model);

        /// <summary>
        /// 删除菜单权限
        /// </summary>
        /// <param name="menuId">菜单编号</param>
        /// <returns></returns>
        bool DeleteByMenuSysNo(int menuId);

        /// <summary>
        /// 权限菜单编号获取菜单权限列表
        /// </summary>
        /// <param name="menuSysNo">菜单编号</param>
        /// <returns>列表</returns>
        List<Permission> GetByMenuSysNo(int menuId);

        /// <summary>
        /// 获取菜单权限列表
        /// </summary>
        /// <returns>列表</returns>
        List<PermissionExt> GetMenuPermissionViewList();

        /// <summary>
        /// 获取所有用户记录
        /// </summary>
        /// <param name="request">查询条件</param>
        /// <returns>List<UserInfo></returns>
        List<MenuPermission> GetList(MenuPermissionQuery request);

        /// <summary>
        /// 菜单功能权限分页列表
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        PagedList<Permission> GetMenuPermissionPager(MenuPermissionQuery query);
    }
}
