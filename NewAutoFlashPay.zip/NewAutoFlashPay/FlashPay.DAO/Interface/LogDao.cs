﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Interface
{
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.Logs;

    /// <summary>
    /// 日志数据接口
    /// </summary>
    public interface LogDao
    {
        /// <summary>
        /// 新增日志
        /// </summary>
        /// <returns></returns>
        long Insert(LogRecord model);

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<LogRecordResponse></returns>
        PagedList<LogRecordResponse> GetPager(LogQuery query);

        //删除
        int Delete(int LogId);

        //日志类型列表
        List<string> GetLogTypes();

        /// <summary>
        /// 列表查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <param name="type">类型</param>
        /// <param name="num">数量</param>
        /// <returns>List<string></returns>
        List<string> GetList(LogQuery query, int type, int num);

    }
}
