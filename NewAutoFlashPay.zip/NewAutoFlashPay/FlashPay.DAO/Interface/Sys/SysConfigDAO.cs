﻿using System;

namespace FlashPay.DAO.Sys
{
    using FlashPay.EF.Models;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity;
    using FlashPay.Entity.Response.Sys;
    using FlashPay.EF;
    using System.Collections.Generic;
    using FlashPay.Entity.Request.Sys;

    public interface SysConfigDao : IDisposable
    {
        /// <summary>
        /// 根据编号获取系统配置
        /// </summary>
        /// <param name="id">编号</param>
        SysConfig Get(int configId);

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        int Add(SysConfig model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="model"></param>
        bool Update(SysConfig model, FlashPayContext flashPayContext = null);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="configId">系统编号</param>
        bool Delete(int configId);

        /// <summary>
        /// 分页
        /// </summary>
        /// <param name="query">条件</param>
        PagedList<SysConfigResponse> GetPager(SysConfigQuery query);

        #region 第三方接口相关
        /// <summary>
        /// 获取第三方接口列表
        /// </summary>
        PagedList<PaymentInterfaceNew> GetPayMentInterfaceList(PaymentInterfaceQuery query);

        /// <summary>
        /// 获取某第三方接口详细信息
        /// </summary>
        PaymentInterface GetDetail(int companyID);

        /// <summary>
        /// 添加第三方接口
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        int AddInterface(PaymentInterfaceQuery s);

        /// <summary>
        /// 修改第三方接口
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        int EditInterface(PaymentInterfaceQuery s);

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="configId"></param>
        /// <returns></returns>
        int DeleteInterface(int companyID);

        /// <summary>
        /// 修改状态
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        int UpdateStatus(PaymentInterfaceQuery request);

        #endregion

        /// <summary>
        /// 获取推送地址列表
        /// </summary>
        PagedList<ExtApiPushUrl> GetPushAddressList(PushAddressQuery query);

        /// <summary>
        /// 获取交易类型信息
        /// </summary>
        string GetTransType(int companyId, int ConfigValue, string ConfigCode);


        //获取系统配置集合
        List<SysConfig> GetTransTypeList(SysConfigAddOrEditRequest sysRequest);
    }
}
