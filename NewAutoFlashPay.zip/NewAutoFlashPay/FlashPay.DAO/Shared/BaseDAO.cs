﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FlashPay.DAO.Shared
{
    public class BaseDAO
    {
        public List<T> Split<T>(IQueryable<T> result, Int32 pageIndex, Int32 pageSize)
        {
            return result.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        }
    }
}