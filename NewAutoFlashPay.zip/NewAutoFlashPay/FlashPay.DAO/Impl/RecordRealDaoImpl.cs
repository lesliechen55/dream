﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Collections.Generic;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Enum;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.Payment;
    using FlashPay.Entity.Response.Payment;
    using FlashPay.Entity.Response.Sys;
    using Microsoft.EntityFrameworkCore;
    using MySql.Data.MySqlClient;
    using System.Data;

    /// <summary>
    /// 实际付款数据接口实现			
    /// </summary>
    /// <remarks>2018-07-06 immi 创建</remarks>
    public class RecordRealDaoImpl : RecordRealDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 日志模型
        /// </summary>
        private readonly LogRecord _logRecord;

        /// <summary>
        /// 日志模型
        /// </summary>
        private readonly LogDao _logDao;

        /// <summary>
        /// 锁对象
        /// </summary>
        private static object _lock = new object();

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public RecordRealDaoImpl(FlashPayContext context, LogRecord logRecord, LogDao logDao)
        {
            _context = context;
            _logRecord = logRecord;
            _logDao = logDao;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 获取订单月份
        /// </summary>
        /// <param name="month"></param>
        /// <returns></returns>
        private string GetOrderMonth(long orderNo)
        {
            return orderNo.ToString().Substring(4, 2);
        }

        /// <summary>
        /// 根据编号获取余额变化记录
        /// </summary>
        /// <param name="orderNo">编号</param>
        /// <returns>Company</returns>
        public RecordReal Get(long orderNo)
        {
            var month = GetOrderMonth(orderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }
            return _context.RecordReal.Where(x => x.OrderNo == orderNo).FirstOrDefault();
        }

        /// <summary>
        /// 根据编号获取余额变化记录
        /// </summary>
        /// <param name="orderNo">编号</param>
        /// <returns>Company</returns>
        public RecordRealGetResponse GetByOrderNo(long orderNo)
        {
            var month = GetOrderMonth(orderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }
            var recordReal = _context.RecordReal.Where(x => x.OrderNo == orderNo).FirstOrDefault();
            if (recordReal != null)
            {
                //获取银行卡
                var bankCard = _context.BankCard.FirstOrDefault(p => p.Bcid == recordReal.CardBcid);
                if (bankCard == null)
                {
                    throw new Exception("实际存款记录的银行卡不存在！");
                }

                //获取公司
                var company = _context.Company.FirstOrDefault(p => p.CompanyId == recordReal.CompanyId);
                if (bankCard == null)
                {
                    throw new Exception("实际存款记录的公司不存在！");
                }

                var recordRealResponse = new RecordRealGetResponse();
                recordRealResponse.OrderNo = recordReal.OrderNo.ToString();
                recordRealResponse.ClientOrderNo = recordReal.ClientOrderNo;
                recordRealResponse.AfterBalance = recordReal.AfterBalance;
                recordRealResponse.CompanyId = recordReal.CompanyId;
                recordRealResponse.CompanyName = company.CompanyName;

                recordRealResponse.Remark = recordReal.Remark;
                recordRealResponse.RecordType = recordReal.RecordType;
                recordRealResponse.CreateDate = recordReal.CreateDate.ToString("yyyy-MM-dd HH:mm:ss");
                recordRealResponse.CreateDbdate = recordReal.CreateDbdate.ToString("yyyy-MM-dd HH:mm:ss");
                recordRealResponse.OperatingDate = recordReal.OperatingDate.ToString("yyyy-MM-dd HH:mm:ss");
                recordRealResponse.CardBcid = recordReal.CardBcid;
                recordRealResponse.BankName = bankCard.BankName;
                recordRealResponse.BankCardName = bankCard.CardName;
                recordRealResponse.BankCardNumber = bankCard.CardNumber;
                recordRealResponse.Amount = recordReal.Amount.ToString("#0.00");
                recordRealResponse.ClientBankName = recordReal.ClientBankName;
                recordRealResponse.ClientAccountName = recordReal.ClientAccountName;
                recordRealResponse.ClientCardNumber = recordReal.ClientCardNumber;
                recordRealResponse.BankSerialNo = recordReal.BankSerialNo;
                recordRealResponse.VmClientId = recordReal.VmClientId;
                recordRealResponse.MatchOrderNo = recordReal.MatchOrderNo;

                var configs = _context.SysConfig.Where(p => p.ConfigCode == "Transtype" && p.CompanyId == 2).ToList();
                if (configs != null && configs.Any()) {

                    var sysConfigResponses = new List<SysConfigResponse>();
                    configs.ForEach(item => {
                        sysConfigResponses.Add(new SysConfigResponse() {
                            ConfigId = item.ConfigId,
                            ConfigValue = item.ConfigValue,
                            ConfigContent = item.ConfigContent
                        });
                    });
                    recordRealResponse.SysConfigResponse = sysConfigResponses;
                }
                return recordRealResponse;
            }
            else {
                return null;
            }
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        public long Add(RecordReal model)
        {
            _context.RecordReal.Add(model);
            _context.SaveChanges();
            return model.OrderNo;
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        public bool Update(RecordReal model)
        {
            bool result = false;

            var adjustBalance = _context.RecordReal.Find(model.OrderNo);
            if (adjustBalance != null)
            {
                _context.SaveChanges();
                result = true;
            }
            return result;
        }

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        public bool UpdateStatus(int id, SByte status)
        {
            var model = _context.RecordReal.Where(p => p.OrderNo.Equals(id)).FirstOrDefault();
            if (model != null)
            {
                return _context.SaveChanges() > 0;
            }
            else
            {
                throw new Exception("当前记录不存在！");
            }
        }

        /// <summary>
        /// 添加日志
        /// </summary>
        private void AddLog()
        {

        }

        /// <summary>
        /// UpdateRecordRealOrderNo
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        private bool UpdateRecordRealOrderNo(long orderNo, long recordRealOrderNo, FlashPayContext flashPayContext = null)
        {
            var month = GetOrderMonth(orderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }

            var model = _context.PaymentRecord.Where(p => p.OrderNo.Equals(orderNo)).FirstOrDefault();
            if (model != null)
            {
                model.RecordRealOrderNo = recordRealOrderNo;
                int row = _context.SaveChanges();
                return true;
            }
            else
            {
                throw new Exception("当前记录不存在！");
            }
        }

        /// <summary>
        /// 转成功
        /// </summary>
        /// <param name="reqeust">参数</param>
        /// <returns></returns>
        public JResult TurnSuccess(TurnReqeust reqeust)
        {
            var result = new JResult() {
                Success = false
            };

            System.Threading.Thread.Sleep(500);

            lock (_lock)
            {
                //using (var tran = _context.Database.BeginTransaction())
                //{

                //}
                try
                {
                    var month = GetOrderMonth(reqeust.OrderNo);
                    if (month != DateTime.Now.ToString("MM"))
                    {
                        _context.ReloadModelCreating(month);
                    }

                    var orderRecord = _context.PaymentRecord.FirstOrDefault(p => p.OrderNo == reqeust.OrderNo);
                    if (orderRecord == null)
                    {
                        throw new Exception("订单记录不存在！");
                    }

                    var recordReal = _context.RecordReal.FirstOrDefault(p => p.OrderNo == reqeust.RecordRealOrderNo);
                    if (recordReal != null)
                    {
                        //付款记录状态验证
                        if (orderRecord.PaymentStatus != (sbyte)PaymentRecordPaymentStatus.付款中.GetHashCode())
                        {
                            throw new Exception("付款记录状态发生改变！");
                        }
                        //确认状态(自动审核通过、人工审核通过)
                        var confirmStatus = new List<int>()
                            {
                                (sbyte)PaymentRecordConfirmStatus.自动审核通过.GetHashCode(),
                                (sbyte)PaymentRecordConfirmStatus.人工审核通过.GetHashCode()
                            };
                        if (!confirmStatus.Contains(orderRecord.ConfirmStatus))
                        {
                            throw new Exception("付款记录状态发生改变！");
                        }

                        //数据验证
                        if (recordReal.MatchOrderNo != null || recordReal.MatchOrderNo > 0)
                        {
                            throw new Exception("该实际支付记录已标记成功！");
                        }

                        var paymentRecordPaymentStatus = (sbyte)PaymentRecordPaymentStatus.付款成功.GetHashCode();

                        var sql = $"call sp_UpdateMatchPaymentRecord('{reqeust.OrderNo}', '{reqeust.RecordRealOrderNo}', '{paymentRecordPaymentStatus}');";

                        var connection = _context.Database.GetDbConnection();

                        using (var command = connection.CreateCommand())
                        {
                            command.CommandText = sql;
                            command.CommandType = CommandType.Text;
                            if (connection.State == ConnectionState.Closed)
                            {
                                connection.Open();
                            }

                            var updateSatatus = 0L;

                            using (var updateResult = command.ExecuteReader())
                            {
                                if (updateResult.Read())
                                {
                                    updateSatatus = updateResult.GetInt32(0);
                                }
                            }

                            if (updateSatatus <= 0) {
                                throw new Exception("更新付款RecordRealOrderNo失败！");
                            }
                        }

                        //var updateStatus = _context.Database.ExecuteSqlCommand(sql);
                        //if (updateStatus <= 0) {
                        //    throw new Exception("更新付款RecordRealOrderNo失败！");
                        //}

                        //更新付款记录（付款状态、真实记录订单号）
                        //orderRecord.PaymentStatus = (sbyte)PaymentRecordPaymentStatus.付款成功.GetHashCode();
                        //orderRecord.RecordRealOrderNo = recordReal.OrderNo;
                        //_context.Entry<PaymentRecord>(orderRecord);
                        //var updatePaymentRecordStatus = _context.SaveChanges();
                        //if (updatePaymentRecordStatus <= 0)
                        //{
                        //    throw new Exception("更新付款RecordRealOrderNo失败！");
                        //}
                        //付款真实记录
                        //recordReal.MatchOrderNo = reqeust.OrderNo;
                        //_context.Entry<RecordReal>(recordReal);
                        //var updateRecordRealStatus = _context.SaveChanges();
                        //if(updateRecordRealStatus<=0)
                        //{
                        //    throw new Exception("更新付款RecordRealOrderNo失败！");
                        //}

                        //call sp_UpdateMatchPaymentRecord(201808000000000001,201809000000000006)

                        //日志
                        _logRecord.LogType = LogRecordLogType.Permission_Update.GetHashCode();
                        _logRecord.LogLevel = (sbyte)LogLevel.Success.GetHashCode();
                        _logRecord.CreateDate = DateTime.Now;
                        _logRecord.LogRemark = $"付款记录转成功成功,付款订单编号：{reqeust.OrderNo},真实付款记录编号：{reqeust.RecordRealOrderNo}";
                        _logDao.Insert(_logRecord);

                        result.Success = true;
                        //tran.Commit();
                    }
                    else
                    {
                        _logRecord.LogType = LogRecordLogType.Permission_Update.GetHashCode();
                        _logRecord.LogLevel = (sbyte)LogLevel.Failure.GetHashCode();
                        _logRecord.CreateDate = DateTime.Now;
                        _logRecord.LogRemark = $"真实付款记录不存在,付款订单编号：{reqeust.OrderNo},真实付款记录编号：{reqeust.RecordRealOrderNo}";
                        _logDao.Insert(_logRecord);

                        throw new Exception("真实付款记录不存在！");
                    }
                }
                catch (Exception ex)
                {
                    //tran.Rollback();
                    try
                    {
                        _logRecord.LogType = LogRecordLogType.Permission_Update.GetHashCode();
                        _logRecord.LogLevel = (sbyte)LogLevel.Error.GetHashCode();
                        _logRecord.CreateDate = DateTime.Now;
                        _logRecord.LogRemark = $"操作失败,付款订单编号：{reqeust.OrderNo},真实付款记录编号：{reqeust.RecordRealOrderNo}";
                        _logDao.Insert(_logRecord);
                    }
                    catch
                    {
                    }

                    result.ErrorMessage = ex.Message;
                }
            }

            return result;
        }

        /// <summary>
        /// 转失败
        /// </summary>
        /// <param name="reqeust">参数</param>
        /// <returns></returns>
        public JResult TurnFailure(TurnReqeust reqeust)
        {
            var result = new JResult()
            {
                Success = false
            };

            System.Threading.Thread.Sleep(500);

            lock (_lock)
            {
                using (var tran = _context.Database.BeginTransaction())
                {
                    try
                    {
                        var month = GetOrderMonth(reqeust.OrderNo);
                        if (month != DateTime.Now.ToString("MM"))
                        {
                            _context.ReloadModelCreating(month);
                        }


                        var orderRecord = _context.PaymentRecord.FirstOrDefault(p => p.OrderNo == reqeust.OrderNo);
                        if (orderRecord == null)
                        {
                            throw new Exception("订单记录不存在！");
                        }

                        //状态验证
                        if (orderRecord.PaymentStatus == (sbyte)PaymentRecordPaymentStatus.付款失败.GetHashCode())
                        {
                            throw new Exception("该付款订单状态已发生改变！");
                        }

                        orderRecord.PaymentStatus = (sbyte)PaymentRecordPaymentStatus.付款失败.GetHashCode();

                        _context.Entry<PaymentRecord>(orderRecord);
                        _context.SaveChanges();

                        //日志
                        _logRecord.LogType = LogRecordLogType.Permission_Update.GetHashCode();
                        _logRecord.LogLevel = (sbyte)LogLevel.Success.GetHashCode();
                        _logRecord.CreateDate = DateTime.Now;
                        _logRecord.LogRemark = $"付款记录转失败成功,付款订单编号：{reqeust.OrderNo},真实付款记录编号：{reqeust.RecordRealOrderNo}";
                        _logDao.Insert(_logRecord);

                        result.Success = true;
                        tran.Commit();
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        try
                        {
                            _logRecord.LogType = LogRecordLogType.Permission_Update.GetHashCode();
                            _logRecord.LogLevel = (sbyte)LogLevel.Error.GetHashCode();
                            _logRecord.CreateDate = DateTime.Now;
                            _logRecord.LogRemark = $"付款记录转失败失败,付款订单编号：{reqeust.OrderNo},真实付款记录编号：{reqeust.RecordRealOrderNo}";
                            _logDao.Insert(_logRecord);
                        }
                        catch
                        {
                        }
                        result.ErrorMessage = ex.Message;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// 获取所有记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<UserInfo></returns>
        public List<RecordReal> GetList(RecordRealQuery query)
        {
            //多条件查询
            var where = PredicateBuilder.True<RecordReal>();

            var list = _context.RecordReal.Where(where.Compile()).ToList();

            return list;
        }

        /// <summary>
        /// 获取银行卡前四位和后四位
        /// </summary>
        /// <param name="bankCardNumber"></param>
        /// <returns></returns>
        private string GetBankCardNumber(string bankCardNumber)
        {
            if (string.IsNullOrEmpty(bankCardNumber)){
                return "";
            }else {
                if (bankCardNumber.Length >= 8) {
                    return bankCardNumber.Substring(0, 4) + bankCardNumber.Substring(bankCardNumber.Length - 4);
                }
                else {
                    return "";
                }
            }
        }

        /// <summary>
        /// 获取付款记录的真实付款记录
        /// </summary>
        /// <returns></returns>
        public List<PaymentRecordRealResponse> GetPaymentRecordReals(PaymentRecordRealQuery query) {

            var month = GetOrderMonth(query.OrderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }

            var paymentRecord = _context.PaymentRecord.FirstOrDefault(p => p.OrderNo == query.OrderNo && p.RecordRealOrderNo==null);
            if (paymentRecord != null)
            {
                var readDateAddMinutes = paymentRecord.ReadDate.Value.AddMinutes(query.Minutes);

                var q = from rr in _context.RecordReal
                        join
                        c in _context.Company on rr.CompanyId equals c.CompanyId
                        join
                        bc in _context.BankCard on rr.CardBcid equals bc.Bcid
                        where
                        rr.MatchOrderNo == null &&
                        rr.OperatingDate > paymentRecord.CreateDbdate &&
                        rr.OperatingDate <= readDateAddMinutes &&
                        rr.CardBcid == paymentRecord.PaymentCardId &&
                        rr.Amount == paymentRecord.WithdrawalAmount &&
                        rr.ClientAccountName == paymentRecord.WithdrawalAccountName &&
                        rr.CompanyId == paymentRecord.CompanyId
                        select new PaymentRecordRealResponse
                        {
                            OrderNo = rr.OrderNo.ToString(),
                            AfterBalance = rr.AfterBalance.ToString("#0.00"),
                            CompanyId = rr.CompanyId,
                            CompanyName = c.CompanyName,

                            OperatingDate = rr.OperatingDate.ToString("yyyy-MM-dd HH:mm:ss"),
                            CardBcid = rr.CardBcid,
                            CardBankName = bc.BankName,
                            Amount = rr.Amount.ToString("#0.00"),
                            ClientBankName = rr.ClientBankName,
                            ClientAccountName = rr.ClientAccountName,
                            ClientCardNumber = GetBankCardNumber(rr.ClientCardNumber)
                        };

                //付款记录客户卡号
                var withdrawalCardNumber = GetBankCardNumber(paymentRecord.WithdrawalCardNumber);


                var list = q.ToList();
                if (!string.IsNullOrEmpty(withdrawalCardNumber)) {
                    return list.Where(p => p.ClientCardNumber == withdrawalCardNumber).ToList();
                }
                return list;
            }
            else {
                return null;
            }
        }

        /// <summary>
        /// 已实际付款记录(未入账收款记录)
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public DataGrid<RecordRealResponse> GetPaymentRecordPager(RecordRealQuery query)
        {
            var companyIds = string.Join(", ", query.CompanyIds);

            var sql = $"call sp_SelectRecordReal('{query.StartTime}', '{query.EndTime}', '{companyIds}','{query.RecordType}');";
            var q = _context.RecordReal.FromSql(sql);

            #region 模型转换
            var companys = _context.Company.ToList();
            var bankCards = _context.BankCard.ToList();


            //公司名称
            if (!string.IsNullOrEmpty(query.CompanyName))
            {
                var comSearch = companys.Where(p => p.CompanyName.Contains(query.CompanyName)).ToList();
                q = q.Where(c => comSearch.Select(p => p.CompanyId).Contains(c.CompanyId));
            }

            //收款卡用户名
            if (!string.IsNullOrEmpty(query.CardName))
            {
                var cardSearch = bankCards.Where(p => p.CardName.Contains(query.CardName)).ToList();
                if (cardSearch != null && cardSearch.Any())
                {
                    q = q.Where(c => cardSearch.Select(p => p.Bcid).Contains(c.CardBcid));
                }
                else
                {
                    q = q.Where(c => c.CardBcid==-1);
                }
            }

            //付款卡用户名
            if (!string.IsNullOrEmpty(query.PaymentCradName))
            {
                var cardSearch = bankCards.Where(p => p.CardName.Contains(query.PaymentCradName)).ToList();
                if (cardSearch != null && cardSearch.Any())
                {
                    q = q.Where(c => cardSearch.Select(p => p.Bcid).Contains(c.CardBcid));
                }
                else
                {
                    q = q.Where(c => c.CardBcid == -1);
                }
            }

            //收款金额
            if (query.StartAmount>0)
            {
                q = q.Where(c => c.Amount>= query.StartAmount);
            }
            if (query.EndAmount > 0)
            {
                q = q.Where(c => c.Amount <= query.EndAmount);
            }

            //客户姓名
            if (!string.IsNullOrEmpty(query.ClientAccountName))
            {
                q = q.Where(c => c.ClientAccountName.Contains(query.ClientAccountName));
            }

            var list = q.OrderByDescending(e=> e.OperatingDate).Skip((query.Page.Value - 1) * query.Rows.Value).Take(query.Rows.Value).ToList();
            var recordRealResponses = new List<RecordRealResponse>();

            list.ForEach(item =>
            {
                var depositOrPaymentRecordResponse = new RecordRealResponse();

                #region 公司
                var companyName = "";
                var companyNameEn = "";
                if (companys != null && companys.Any())
                {
                    var company = companys.FirstOrDefault(p => p.CompanyId == item.CompanyId);
                    if (company != null)
                    {
                        companyName = company.CompanyName;
                        companyNameEn = company.CompanyNameEn;
                    }
                }
                #endregion

                #region 银行卡
                var bankName = "";
                var cardNumber = "";
                var cardName = "";
                if (bankCards != null && bankCards.Any())
                {
                    var bankCard = bankCards.FirstOrDefault(p => p.Bcid == item.CardBcid);
                    if (bankCard != null)
                    {
                        bankName = bankCard.BankName;
                        cardNumber = bankCard.CardNumber;
                        cardName = bankCard.CardName;
                    }
                }
                #endregion

                depositOrPaymentRecordResponse.OrderNo = item.OrderNo.ToString();
                depositOrPaymentRecordResponse.ClientOrderNo = item.ClientOrderNo;
                depositOrPaymentRecordResponse.AfterBalance = item.AfterBalance.ToString("#0.00");
                depositOrPaymentRecordResponse.CompanyName = companyName;
                depositOrPaymentRecordResponse.CompanyNameEn = companyNameEn;
                depositOrPaymentRecordResponse.BankName = bankName;
                depositOrPaymentRecordResponse.CardName = cardName;
                depositOrPaymentRecordResponse.CardNumber = cardNumber;
                depositOrPaymentRecordResponse.Amount = item.Amount.ToString("#0.00");
                depositOrPaymentRecordResponse.OperatingDate = item.OperatingDate;
                depositOrPaymentRecordResponse.ClientBankName = item.ClientBankName;
                depositOrPaymentRecordResponse.ClientAccountName = item.ClientAccountName;
                depositOrPaymentRecordResponse.ClientCardNumber = item.ClientCardNumber;
                depositOrPaymentRecordResponse.MatchOrderNo = item.MatchOrderNo.HasValue ? item.MatchOrderNo.Value.ToString():null;
                depositOrPaymentRecordResponse.VmClientID = item.VmClientId;
                depositOrPaymentRecordResponse.Remark = item.Remark;

                recordRealResponses.Add(depositOrPaymentRecordResponse);
            });
            #endregion

            return new DataGrid<RecordRealResponse>()
            {
                Total = q.Count(),
                Rows = recordRealResponses,
                Success = true
            };
        }
    }
}
