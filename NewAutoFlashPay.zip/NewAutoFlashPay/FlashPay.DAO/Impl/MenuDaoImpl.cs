﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Collections.Generic;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;
    using FlashPay.EF;

    using FlashPay.EF.Models;
    using FlashPay.Entity.Request.Menu;

    /// <summary>
    /// 菜单数据接口实现
    /// </summary>
    /// <remarks>2018-07-09 immi 创建</remarks>
    public class MenuDaoImpl:IDisposable,MenuDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public MenuDaoImpl(FlashPayContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        public Menu Get(int id)
        {
            var model = _context.Menu.Where(x => x.Mid == id).FirstOrDefault();
            return model;
        }

        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        public EF.Models.Company GetById(int id)
        {
            var model = _context.Company.Where(x => x.CompanyId == id).FirstOrDefault();
            return model;
        }

        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        public BankInfo GetBankInfoByBankCode(string bankCode)
        {
            var model = _context.BankInfo.Where(x => x.BankCode == bankCode).FirstOrDefault();
            return model;
        }

        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        public OrderRecord GetOrderRecordByOrderNo(long orderNo)
        {
            var model = _context.OrderRecord.Where(x => x.OrderNo == orderNo).FirstOrDefault();
            return model;
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        public int Add(Menu model)
        {
            _context.Menu.Add(model);
            _context.SaveChanges();
            return model.Mid;
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        public bool Update(Menu model)
        {
            bool result = false;

            var menu = _context.Menu.Find(model.Mid);
            if (menu != null)
            {
                menu.MParent = model.MParent;
                menu.MName = model.MName;
                menu.MUrl = model.MUrl;
                menu.NodeType = model.NodeType;
                menu.SortNo = model.SortNo;
                menu.MType = menu.MType;
                menu.Hide = model.Hide;
                _context.SaveChangesAsync();
                result = true;
            }
            return result;
        }

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        public bool UpdateStatus(int id, sbyte status)
        {
            //官方推荐的修改方式（先查询，再修改）
            var model = _context.Menu.Where(p => p.Mid.Equals(id)).FirstOrDefault();
            if (model != null)
            {
                model.Hide = status;
                _context.SaveChangesAsync();
                return true;
            }
            else
            {
                throw new Exception("当前记录不存在！");
            }
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <returns></returns>
        public bool Delete(int mId)
        {

            var model = _context.Menu.Find(mId);
            if (model != null)
            {
                _context.Menu.Remove(model);
                if (_context.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 获取菜单列表
        /// </summary>
        /// <param name="ids">系统编号列表</param>
        /// <returns>菜单列表</returns>
        public List<Menu> GetListByIds(List<int> ids)
        {
            return _context.Menu.Where(p => ids.Contains(p.Mid)).ToList();
        }

        /// <summary>
        /// 获取所有用户记录
        /// </summary>
        /// <param name="request">查询条件</param>
        /// <returns>List<UserInfo></returns>
        public List<Menu> GetList(MenuQueryRequest request)
        {
            //多条件查询
            var where = PredicateBuilder.True<Menu>();

            //编号
            if (request.Mid.HasValue)
            {
                where = where.And(c => c.Mid == request.Mid.Value);
            }
            //编号
            if (request.NotEqualMid.HasValue)
            {
                where = where.And(c => c.Mid != request.NotEqualMid.Value);
            }
            //登录名称搜索
            if (!string.IsNullOrEmpty(request.MName))
            {
                where = where.And(c => c.MName.Equals(request.MName));
            }
            //父类编号
            if (request.MParent.HasValue)
            {
                where = where.And(c => c.MParent.Equals(request.MParent.Value));
            }
            //节点类型
            if (request.NodeType.HasValue)
            {
                where = where.And(c => c.NodeType == request.NodeType.Value);
            }
            //功能分类
            if (request.MType.HasValue)
            {
                where = where.And(c => c.MType == request.MType.Value);
            }
            //隐藏
            if (request.Hide.HasValue)
            {
                where = where.And(c => c.Hide == request.Hide.Value);
            }


            var list = _context.Menu.Where(where.Compile()).OrderBy(p=>p.SortNo).ToList();

            return list;
        }

    }
}
