﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity.Parameter;
    using System.Linq;
    using System.Linq.Expressions;

    /// <summary>
    /// 授权数据接口实现
    /// </summary>
    public class ExtApiCompatDaoImpl: ExtApiCompatDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public ExtApiCompatDaoImpl(FlashPayContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 获取
        /// </summary>
        /// <param name="id">编号</param>
        public ExtApiCompat Get(int id)
        {
            return _context.ExtApiCompat.Where(x => x.Id == id).FirstOrDefault();
        }

        /// <summary>
        /// 获取
        /// </summary>
        /// <param name="id">编号</param>
        public ExtApiCompat Get(int id,int type)
        {
            return _context.ExtApiCompat.Where(x => x.Id == id && x.Type == type).FirstOrDefault();
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(ExtApiCompat model, FlashPayContext flashPayContext = null)
        {
            var _flashPayContext = (flashPayContext ?? _context);
            _flashPayContext.ExtApiCompat.Add(model);
            //调用数据上下文的保存方法，将对象存数数据库
            var resultId = _flashPayContext.SaveChanges();

            return resultId;
        }

        /// <summary>
        /// 更新授权
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        public bool Update(ExtApiCompat model, FlashPayContext flashPayContext = null)
        {
            bool result = false;
            var eac = flashPayContext.ExtApiCompat.Find(model.Id);
            if (eac != null)
            {
                eac.ApiKey = model.ApiKey;
                eac.SecretKey = model.SecretKey;
                eac.Status = model.Status;

                _context.Entry<ExtApiCompat>(eac);
                _context.SaveChanges();
                result = true;
            }
            return result;
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public List<ExtApiCompat> GetList(ExtApiCompatQuery query)
        {
            //多条件查询
            var where = PredicateBuilder.True<ExtApiCompat>();

            if (query.Id.HasValue)
            {
                where = where.And(c => c.Id == query.Id.Value);
            }

            if (query.Type.HasValue)
            {
                where = where.And(c => c.Type == query.Type.Value);
            }

            if (query.CompanyId.HasValue)
            {
                where = where.And(c => c.CompanyId == query.CompanyId.Value);
            }

            var list = _context.ExtApiCompat.Where(where.Compile()).ToList();

            return list;
        }
    }
}
