﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Shared;
    using FlashPay.DAO.Interface;
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Enum;
    using FlashPay.Entity.Response.Logs;



    /// <summary>
    ///日志数据接口实现
    /// </summary>
    public class LogDaoImpl : BaseDAO, LogDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public LogDaoImpl(FlashPayContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 新增日志
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        public long Insert(LogRecord model)
        {
            //将对象加入到数据上下文的LogRecord集合中
            _context.LogRecord.Add(model);
            //调用数据上下文的保存方法，将对象存数数据库
            _context.SaveChanges();
            return model.LogId;
        }


        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="logId">编号</param>
        /// <returns></returns>
        public int Delete(int logId)
        {
            var model = _context.LogRecord.Where(p => p.LogId == logId).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
            }
            return _context.SaveChanges();
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<LogRecordResponse></returns>
        public PagedList<LogRecordResponse> GetPager(LogQuery query)
        {
            PagedList<LogRecordResponse> result = new PagedList<LogRecordResponse>();
            int logType = 0;
            if (!string.IsNullOrEmpty(query.LogType))
            {
                logType = (int)Enum.Parse(typeof(LogRecordLogType), query.LogType);
            }

            var bank = from u in _context.LogRecord
                       join c in _context.Company on u.CompanyId equals c.CompanyId
                       orderby u.LogId descending
                       where u.CompanyId == query.CompanyId
                       && (string.IsNullOrEmpty(query.LogType) ? true : u.LogType == logType)
                       && (string.IsNullOrEmpty(query.CreateName) ? true : u.CreateName == query.CreateName)
                       && (string.IsNullOrEmpty(query.IP) ? true : u.Ip.Contains(query.IP))
                       && (query.CreateDate == DateTime.MinValue ? true : u.CreateDate.Date == query.CreateDate.Date)
                       select new LogRecordResponse
                       {
                           LogId = u.LogId,
                           Ip = u.Ip,
                           LogType = GetLogType(u.LogType),
                           CreateName = u.CreateName,
                           CreateDate = u.CreateDate,
                           LogRemark = u.LogRemark,
                           CompanyName = c.CompanyName,
                           RequestUrl = u.RequestUrl,
                           RequestData = u.RequestData
                       };

            List<LogRecordResponse> list = Split(bank, query.CurrentPageIndex.Value, query.PageSize.Value);
            result.TotalCount = bank.Count();
            result.TData = list;
            result.Success = true;

            return result;
        }


        public string GetLogType(int logType)
        {
            return Enum.GetName(typeof(LogRecordLogType), logType);
        }

        /// <summary>
        /// 日志类型列表
        /// </summary>
        /// <returns>List<string></returns>
        public List<string> GetLogTypes()
        {
            return Enum.GetNames(typeof(LogRecordLogType)).ToList();
        }

        /// <summary>
        /// 列表查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <param name="type">类型</param>
        /// <param name="num">数量</param>
        /// <returns>List<string></returns>
        public List<string> GetList(LogQuery query, int type, int num)
        {
            List<string> result = new List<string>();
            int logType = 0;
            if (!string.IsNullOrEmpty(query.LogType))
            {
                logType = (int)Enum.Parse(typeof(LogRecordLogType), query.LogType);
            }

            var bank = from u in _context.LogRecord
                       join c in _context.Company on u.CompanyId equals c.CompanyId
                       orderby u.LogId descending
                       where u.CompanyId == query.CompanyId
                       && (string.IsNullOrEmpty(query.LogType) ? true : u.LogType == logType)
                       && (string.IsNullOrEmpty(query.CreateName) ? true : u.CreateName == query.CreateName)
                       && (string.IsNullOrEmpty(query.IP) ? true : u.Ip.Contains(query.IP))
                       && (query.CreateDate == DateTime.MinValue ? true : u.CreateDate.Date == query.CreateDate.Date)
                       select new LogRecordResponse
                       {
                           LogId = u.LogId,
                           Ip = u.Ip,
                           LogType = GetLogType(u.LogType),
                           CreateName = u.CreateName,
                           CreateDate = u.CreateDate,
                           LogRemark = u.LogRemark,
                           CompanyName = c.CompanyName,
                           RequestUrl = u.RequestUrl,
                           RequestData = u.RequestData
                       };
            if (bank != null)
            {
                if (type == 1)
                {
                    result = bank.Select(b => b.Ip).Distinct().Take(num).ToList();
                }
            }
            return result;
        }
    }
}
