﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Enum;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.Payment;
    using FlashPay.Entity.Response.Company;
    using FlashPay.Entity.Response.Payment;
    using FlashPay.Util;
    using Microsoft.EntityFrameworkCore;
    using System.Collections.Generic;

    /// <summary>
    /// 付款记录数据接口实现
    /// </summary>
    /// <remarks>2018-07-06 immi 创建</remarks>
    public class PaymentRecordDaoImpl : IDisposable,PaymentRecordDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public PaymentRecordDaoImpl(FlashPayContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 获取订单月份
        /// </summary>
        /// <param name="month"></param>
        /// <returns></returns>
        private string GetOrderMonth(long orderNo)
        {
            return orderNo.ToString().Substring(4, 2);
        }

        /// <summary>
        /// 根据编号获取余额变化记录
        /// </summary>
        /// <param name="orderNo">编号</param>
        /// <returns>Company</returns>
        public PaymentRecord Get(long orderNo)
        {
            var month = GetOrderMonth(orderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }
            return _context.PaymentRecord.Where(x => x.OrderNo == orderNo).FirstOrDefault();
        }



        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        public long Add(PaymentRecord model, FlashPayContext flashPayContext = null)
        {
            _context.PaymentRecord.Add(model);
            _context.SaveChanges();

            return model.OrderNo;
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        public bool Update(PaymentRecord model, FlashPayContext flashPayContext = null)
        {
            bool result = false;

            var adjustBalance = _context.PaymentRecord.Find(model.OrderNo);
            if (adjustBalance != null)
            {
                _context.SaveChanges();
                result = true;
            }
            return result;
        }

        /// <summary>
        /// UpdateRecordRealOrderNo
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        public bool UpdateRecordRealOrderNo(long orderNo,long recordRealOrderNo, FlashPayContext flashPayContext = null)
        {
            var month = GetOrderMonth(orderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }

            var model = _context.PaymentRecord.Where(p => p.OrderNo.Equals(orderNo)).FirstOrDefault();
            if (model != null)
            {
                model.RecordRealOrderNo = recordRealOrderNo;
                int row = _context.SaveChanges();
                return true;
            }
            else
            {
                throw new Exception("当前记录不存在！");
            }
        }

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="orderNo">编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        public bool UpdatePaymentStatus(long orderNo, SByte paymentStatus)
        {
            var month = GetOrderMonth(orderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }

            var model = _context.PaymentRecord.Where(p => p.OrderNo.Equals(orderNo)).FirstOrDefault();
            if (model != null)
            {
                model.PaymentStatus = paymentStatus;
                int row = _context.SaveChanges();
                return true;
            }
            else
            {
                throw new Exception("当前记录不存在！");
            }
        }

        /// <summary>
        /// 更新通知状态
        /// </summary>
        /// <param name="orderNo">编号</param>
        /// <param name="status">状态</param>
        /// <param name="noticeTimes">通知次数</param>
        /// <returns></returns>
        public bool UpdateNoticeStatus(long orderNo, SByte noticeStatus,int noticeTimes)
        {
            var month = GetOrderMonth(orderNo);
            if (month != DateTime.Now.ToString("MM")) {
                _context.ReloadModelCreating(month);
            }

            var model = _context.PaymentRecord.Where(p => p.OrderNo.Equals(orderNo)).FirstOrDefault();
            if (model != null)
            {
                model.NoticeStatus = noticeStatus;
                model.NoticeTimes = noticeTimes;
                int row = _context.SaveChanges();
                return true;
            }
            else
            {
                throw new Exception("当前记录不存在！");
            }
        }

        /// <summary>
        /// 付款确认
        /// </summary>
        /// <param name="request">参数</param>
        public bool PaymentConfirm(PaymentConfirmRequest request)
        {
            var month = GetOrderMonth(request.OrderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }

            var model = _context.PaymentRecord.Where(p => p.OrderNo.Equals(request.OrderNo)).FirstOrDefault();
            if (model != null)
            {
                model.ConfirmUid = request.ConfirmUID;
                model.ConfirmName = request.ConfirmName;
                model.ConfirmStatus = request.ConfirmStatus;
                model.ConfirmDate = request.ConfirmDate;
                int row = _context.SaveChanges();
                return true;
            }
            else
            {
                throw new Exception("当前记录不存在！");
            }
        }

        /// <summary>
        /// 获取所有记录
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<UserInfo></returns>
        public List<PaymentRecord> GetList(PaymentRecordQuery query)
        {
            //多条件查询
            var where = PredicateBuilder.True<PaymentRecord>();

            //公司编号
            if (query.CompanyId.HasValue)
            {
                where = where.And(c => c.CompanyId == query.CompanyId.Value);
            }
            if (!string.IsNullOrEmpty(query.WithdrawalOrderNo))
            {
                where = where.And(c => c.WithdrawalOrderNo == query.WithdrawalOrderNo);
            }
            var list = _context.PaymentRecord.Where(where.Compile()).ToList();


            return list;
        }

        /// <summary>
        ///  获取付款卡公司
        /// </summary>
        public List<CompanyResponse> GetPaymentRecordCompanys(PaymentRecordCompanyQuery query)
        {
            var paymentRecords = _context.PaymentRecord.ToList();

            var companyIds = paymentRecords.MyDistinct(p => p.CompanyId).ToList();

            var companys = _context.Company.ToList();

            #region 模型转换
            var companyResponses = new List<CompanyResponse>();

            companys.ForEach(item => {
                companyResponses.Add(new CompanyResponse() {
                    CompanyID = item.CompanyId,
                    CompanyName = item.CompanyName
                });
            });
            #endregion

            return companyResponses;
        }

        /// <summary>
        /// 付款卡查询
        /// </summary>
        /// <param name="query">查询参数</param>
        public PagedList<PaymentCardResponse> GetPaymentCardPager(PaymentCardQuery query) {

            var q = from bc in _context.BankCard
                    join
                    c in _context.Company on bc.CompanyId equals c.CompanyId
                    join
                    ui in _context.UserInfo on bc.CreateUid equals ui.UId
                    where bc.CardType == (sbyte)CardType.付款卡.GetHashCode() && bc.CompanyId>0
                    select new
                    {
                        bc.Bcid,
                        c.CompanyId,
                        CreateCompanyId = ui.UCompanyId,
                        c.CompanyName,
                        c.CompanyNameEn,
                        bc.BankName,
                        bc.CardNumber,
                        bc.CardName,
                        bc.CardType,
                        bc.UsingStatus,
                        bc.EnableStatus,
                        bc.Balance,
                        bc.PaymentStart,
                        bc.PaymentEnd,
                        //PaymentInterval
                        bc.PayFeeRatio,
                        bc.BalanceLastUpdate,
                        //TimeDifference
                        bc.DepositType,
                        bc.CrossBankPay,
                        bc.DepositFeeRatio,
                        bc.IpAddress
                    };
            //公司编号
            if (query.CompanyId.HasValue)
            {
                q = q.Where(c => c.CompanyId == query.CompanyId.Value);
            }
            //银行卡启用状态
            if (query.CompanyIds != null && query.CompanyIds.Any())
            {
                q = q.Where(c => query.CompanyIds.Contains(c.CreateCompanyId));
            }
            //公司名称
            if (!string.IsNullOrEmpty(query.CompanyName))
            {
                q = q.Where(c => c.CompanyName.Contains(query.CompanyName));
            }
            //银行卡
            if (!string.IsNullOrEmpty(query.BankName))
            {
                q = q.Where(c => c.BankName.Contains(query.BankName));
            }
            //银行卡用戶名
            if (!string.IsNullOrEmpty(query.CardName))
            {
                q = q.Where(c => c.CardName.Contains(query.CardName));
            }
            //銀行卡号
            if (!string.IsNullOrEmpty(query.CardNumber))
            {
                q = q.Where(c => c.CardNumber.Contains(query.CardNumber));
            }
            //银行卡使用状态
            if (query.UsingStatus.HasValue)
            {
                q = q.Where(c => c.UsingStatus == query.UsingStatus.Value);
            }
            //银行卡启用状态
            if (query.EnableStatus.HasValue)
            {
                q = q.Where(c => c.EnableStatus == query.EnableStatus.Value);
            }

            var list = q.Skip((query.CurrentPageIndex.Value - 1) * query.PageSize.Value).Take(query.PageSize.Value).ToList();
            var total = q.Count();

            #region 数据转换
            var paymentCardResponses = new List<PaymentCardResponse>();

            list.ForEach(item => {
                var ipAddress = item.IpAddress;
                if (!query.UserPermission.Contains("PaymentCard0004"))
                {
                    ipAddress = "*.*.*.*";
                }
                var paymentCardResponse = new PaymentCardResponse() {
                    BcId = item.Bcid,
                    CompanyId = item.CompanyId,
                    CompanyName = item.CompanyName,
                    CompanyNameEn = item.CompanyNameEn,
                    BankName = item.BankName,
                    CardNumber = item.CardNumber,
                    CardName = item.CardName,
                    CardType = item.CardType,
                    UsingStatus = item.UsingStatus,
                    EnableStatus = item.EnableStatus,
                    Balance = item.Balance.HasValue ? item.Balance.Value.ToString("#0.00") : null,
                    PaymentStart = item.PaymentStart,
                    PaymentEnd = item.PaymentEnd,
                    PaymentInterval = $"{item.PaymentStart.ToString("#0.00")} - {item.PaymentEnd.ToString("#0.00")}",
                    PayFeeRatio = item.PayFeeRatio*100,
                    BalanceLastUpdate = item.BalanceLastUpdate.HasValue ? item.BalanceLastUpdate.Value.ToString("yyyy-MM-dd HH:mm:ss"):null,
                    //TimeDifference
                    DepositType = item.DepositType,
                    CrossBankPay = item.CrossBankPay,
                    DepositFeeRatio = item.DepositFeeRatio,
                    IpAddress = ipAddress,

                };
                if (item.BalanceLastUpdate.HasValue)
                {
                    var balanceLastUpdate = item.BalanceLastUpdate.Value;
                    var ts = DateTime.Now.Subtract(balanceLastUpdate).TotalMinutes;
                    if (ts > 0) {
                        paymentCardResponse.TimeDifference = ts;
                    }
                }

                paymentCardResponses.Add(paymentCardResponse);
            });
            #endregion

            return new PagedList<PaymentCardResponse>() {
                TotalCount = total,
                TData = paymentCardResponses,
                Success = true,
            };
        }

        /// <summary>
        /// 收付款记录查询
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public DataGrid<PaymentRecordResponse> GetPaymentRecordPager(PaymentRecordQuery query)
        {
            var startTime = query.StartTime;
            var endTime = query.EndTime;
            //公司列表
            var companys = _context.Company.ToList();
            //银行卡列表
            var bankCards = _context.BankCard.ToList();

            var spName = query.PaymentType.Equals(PaymentType.存款) ? "sp_SelectDepositRecord" : "sp_SelectPaymentRecord";

            var sql = string.Format("call {0}('{1}', '{2}', '{3}');", spName, startTime, endTime, string.Join(", ", query.CompanyIds));


            var q = _context.PaymentRecord
                    .FromSql(sql).OrderByDescending(x => x.CreateDbdate)
                    .ToList();
            //订单号
            if (query.OrderNo.HasValue) {
                q = q.Where(c => c.OrderNo == query.OrderNo.Value).ToList();
            }
            //公司名称
            if (!string.IsNullOrEmpty(query.CompanyName))
            {
                var companySearch = companys.Where(p => p.CompanyName.Contains(query.CompanyName)).ToList();
                q = q.Where(c => companySearch.Select(p => p.CompanyId).Contains(c.CompanyId)).ToList();
            }
            //客户姓名
            if (!string.IsNullOrEmpty(query.WithdrawalAccountName))
            {
                q = q.Where(c => c.WithdrawalAccountName.Contains(query.WithdrawalAccountName)).ToList();
            }
            //客户卡号
            if (!string.IsNullOrEmpty(query.WithdrawalCardNumber))
            {
                q = q.Where(c => c.WithdrawalCardNumber.Contains(query.WithdrawalCardNumber)).ToList();
            }
            //付款状态
            if (query.PaymentStatus.HasValue)
            {
                q = q.Where(c => c.PaymentStatus == query.PaymentStatus.Value).ToList();
            }
            //通知状态
            if (query.NoticeStatus.HasValue)
            {
                q = q.Where(c => c.NoticeStatus == query.NoticeStatus.Value).ToList();
            }
            //付款名称
            if (!string.IsNullOrEmpty(query.CardName)) {
                var bankCredIds = _context.BankCard.Where(p => p.CardName.Contains(query.CardName)).Select(p=>p.Bcid).ToList();
                if (bankCredIds != null && bankCredIds.Any()) {
                    q = q.Where(c => bankCredIds.Contains(c.PaymentCardId.HasValue? c.PaymentCardId.Value:0)).ToList();
                }
            }

            var list = q.Skip((query.Page.Value - 1) * query.Rows.Value).Take(query.Rows.Value).OrderByDescending(p=>p.CreateDate).ToList();

            #region 模型转换
            var paymentRecordResponses = new List<PaymentRecordResponse>();

            list.ForEach(item => {
                var paymentRecordResponse = new PaymentRecordResponse();

                #region 公司
                var companyName = "";
                var companyNameEn = "";
                if (companys != null && companys.Any()) {
                    var company = companys.FirstOrDefault(p => p.CompanyId == item.CompanyId);
                    if (company != null) {
                        companyName = company.CompanyName;
                        companyNameEn = company.CompanyNameEn;
                    }
                }
                #endregion

                #region 银行卡
                var bankName = "";
                var cardName = "";
                var cardNumber = "";
                if (bankCards != null && bankCards.Any()){
                    var bankCard = bankCards.FirstOrDefault(p => p.Bcid == item.PaymentCardId);
                    if (bankCard != null){
                        bankName = bankCard.BankName;
                        cardName = bankCard.CardName;
                        cardNumber = bankCard.CardNumber;
                    }
                }
                #endregion

                paymentRecordResponse.OrderNo = item.OrderNo.ToString();
                paymentRecordResponse.CompanyName = companyName;
                paymentRecordResponse.CompanyNameEn = companyNameEn;
                paymentRecordResponse.WithdrawalOrderNo = item.WithdrawalOrderNo;
                paymentRecordResponse.BankName = bankName;
                paymentRecordResponse.CardName = cardName;
                paymentRecordResponse.CardNumber = cardNumber;
                paymentRecordResponse.WithdrawalAmount = item.WithdrawalAmount.ToString("#0.00");
                paymentRecordResponse.PaymentDate = item.PaymentDate;
                paymentRecordResponse.PaymentStatus = item.PaymentStatus;
                paymentRecordResponse.WithdrawalAccountName = item.WithdrawalAccountName;
                paymentRecordResponse.WithdrawalBankName = item.WithdrawalBankName;
                paymentRecordResponse.WithdrawalCardNumber = item.WithdrawalCardNumber;
                paymentRecordResponse.NoticeStatus = item.NoticeStatus;
                paymentRecordResponse.ConfirmStatus = item.ConfirmStatus;

                if (item.NoticeLastDate != null) {
                    paymentRecordResponse.NoticeLastDate = item.NoticeLastDate.Value.ToString("yyyy-MM-dd HH:mm:ss");
                }

                paymentRecordResponse.NoticeTimes = item.NoticeTimes;
                paymentRecordResponse.DepositType = item.DepositType;
                paymentRecordResponse.CreateDbdate = item.CreateDbdate;
                //(分钟)(当前时间-付款记录创建时间)>20   显示查询按钮
                var ts = DateTime.Now.Subtract(item.CreateDbdate).TotalMinutes;
                if (ts > 0)
                {
                    paymentRecordResponse.TimeDifference = ts;
                }
                paymentRecordResponse.ReadDate = item.ReadDate.HasValue ? item.ReadDate.Value.ToString("yyyy-MM-dd HH:mm:ss") : "";
                paymentRecordResponses.Add(paymentRecordResponse);
            });
            #endregion

            return new DataGrid<PaymentRecordResponse>() {
                Total = q.Count(),
                Rows = paymentRecordResponses,
                Success = true
             };
        }

        /// <summary>
        /// 补单
        /// </summary>
        /// <param name="request"></param>
        public JResult ReceiptMakeUp(ReceiptMakeUpRequest request)
        {
            var result = new JResult() {
                Success = false
            };
            //重新初始化上下文
            var month = GetOrderMonth(request.OrderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }

            var recordReal = _context.RecordReal.FirstOrDefault(p => p.OrderNo == request.OrderNo);
            if (recordReal == null) {
                throw new Exception("未入账收款记录不存在！");
            }

            //类型验证
            if (recordReal.RecordType != RecordType.存款.GetHashCode())
            {
                throw new Exception("改订单收、付款类型错误！");
            }

            //匹配单号验证
            if (recordReal.MatchOrderNo.HasValue)
            {
                throw new Exception("改收款单已匹配单号！");
            }

            //获取银行卡
            var bankCard = _context.BankCard.FirstOrDefault(p => p.Bcid == recordReal.CardBcid);
            if (bankCard == null)
            {
                throw new Exception("实际存款记录的银行卡不存在！");
            }

            //获取公司
            var company = _context.Company.FirstOrDefault(p => p.CompanyId == recordReal.CompanyId);
            if (bankCard == null)
            {
                throw new Exception("实际存款记录的公司不存在！");
            }

            if (request.Transstype <= 0)
            {
                throw new Exception("请选择补单类型！");
            }
            //获取配置
            var configs = _context.SysConfig.Where(p => p.ConfigCode == "Transtype" && p.CompanyId == 2).ToList();
            if (configs == null)
            {
                throw new Exception("获取配置信息失败！");
            }

            var sysConfig = configs.FirstOrDefault(p => p.ConfigValue == request.Transstype);
            if (sysConfig == null) {
                throw new Exception("被单类型不合法！");
            }
            using (var tran = _context.Database.BeginTransaction()) {
                try
                {
                    var feeRatio = bankCard.DepositFeeRatio <= 0 ? company.DepositRate.Value : bankCard.DepositFeeRatio;
                    var feeTotal = feeRatio * recordReal.Amount;
                    //收款明细
                    var depositRecord = new DepositRecord()
                    {
                        DepositNo = recordReal.ClientOrderNo,
                        FeeRatio = feeRatio,
                        FeeTotal = feeTotal,
                        BeforeBalance = recordReal.AfterBalance - recordReal.Amount,
                        AfterBalance = recordReal.AfterBalance,
                        CompanyId = recordReal.CompanyId,
                        DepositRemark = recordReal.Remark,
                        CreateDate = DateTime.Now,
                        NoticeStatus = (sbyte)DepositRecordNoticeStatus.通知中.GetHashCode(),
                        NoticeTimes = 1,
                        DepositDate = recordReal.CreateDbdate,
                        DepositCardId = recordReal.CardBcid,
                        CardNumber = bankCard.CardNumber,
                        DepositAmount = recordReal.Amount,
                        ClientBankName = recordReal.ClientBankName,
                        ClientAccountName = recordReal.ClientAccountName,
                        ClientCardNumber = recordReal.ClientCardNumber,
                        BankSerialNo = recordReal.BankSerialNo,
                        PostScript = "",
                        Transtype = request.Transstype,
                    };
                    //新增收款明细
                    _context.DepositRecord.Add(depositRecord);
                    int DepositRecordId = _context.SaveChanges();

                    if (depositRecord.OrderNo <= 0)
                    {
                        throw new Exception("新增收款明细成功！");
                    }

                    var updateRecordReal = _context.RecordReal.FirstOrDefault(p => p.OrderNo == request.OrderNo);
                    if (updateRecordReal == null)
                    {
                        throw new Exception("未入账收款记录不存在！");
                    }
                    updateRecordReal.MatchOrderNo = depositRecord.OrderNo;
                    int updateStatus = _context.SaveChanges();
                    if (updateStatus <= 0)
                    {
                        throw new Exception("更新实际存款记录匹配单号失败！");
                    }

                    result.Success = true;
                    tran.Commit();
                }
                catch (Exception ex) {
                    tran.Rollback();

                    result.ErrorMessage = ex.Message;
                }
            }

            return result;
        }
    }
}
