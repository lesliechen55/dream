﻿using FlashPay.DAO.Shared;
using FlashPay.EF;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using FlashPay.Util;
using FlashPay.Entity.DAORequest.Company;
using System.Linq.Expressions;
using FlashPay.DAO.Interface;
using FlashPay.EF.Models;
using FlashPay.Entity.Parameter;

namespace FlashPay.DAO.Impl
{
    /// <summary>
    /// 公司DAO
    /// </summary>
    public class CompanyDaoImpl : BaseDAO, CompanyDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _flashPayContext { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public CompanyDaoImpl(FlashPayContext context)
        {
            _context = (FlashPayContext)context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }

            if (_flashPayContext != null)
            {
                _flashPayContext.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 获取公司
        /// </summary>
        public EF.Models.Company GetById(int companyId, FlashPayContext flashPayContext = null)
        {
            var _flashPayContext = (flashPayContext ?? _context);
            return _flashPayContext.Company.Where(x => x.CompanyId == companyId).FirstOrDefault();
        }

        /// <summary>
        /// 公司新增
        /// </summary>
        public void Add(BaseModel<String> result, Company model)
        {
            /* 呼叫資料庫 */
            _context.Company.Add(model);
            _context.SaveChanges();

            /* 結果複製 */
            result.Success = true;
        }

        /// <summary>
        /// 公司修改
        /// </summary>
        public void EditUseCompanyIdAndCompanyPid(BaseModel<String> result, Company model)
        {
            /* 確認資料存在 */
            Int32 companyID = model.CompanyId;
            Int32 companyPID = model.CompanyPid;
            IQueryable<Company> _result = _context.Company.Where(x => x.CompanyId == companyID && x.CompanyPid == companyPID);
            if (_result.Count() != 1)
                return;

            /* 轉換Model */
            EF.Models.Company company = _result.First();
            company.CompanyName = model.CompanyName;
            company.CompanyBossName = model.CompanyBossName;
            company.CompanyTel = model.CompanyTel;
            company.CompanyAddress = model.CompanyAddress;
            company.CompanyNameEn = model.CompanyNameEn;
            company.DepositRate = model.DepositRate/100;
            company.PayRate = model.PayRate/100;
            company.TransportRate = model.TransportRate / 100;
            company.UpdateUid = model.UpdateUid;
            company.UpdateDate = model.UpdateDate;


            if (model.CompanyStatus > 0)
            {
                company.CompanyStatus = model.CompanyStatus;
            }

            /* 呼叫資料庫 */
            _context.SaveChanges();

            /* 結果複製 */
            result.Success = true;
        }

        /// <summary>
        /// 公司列表
        /// </summary>
        public BaseModel<List<Company>> Get()
        {
            BaseModel<List<Company>> model = new BaseModel<List<Company>>();
            model.PageSize = Int32.MaxValue;

            CompanyRequest request = new CompanyRequest();
            request.CompanyPid = -1;

            Get(model, request);

            return model;
        }

        /// <summary>
        /// 公司列表
        /// </summary>
        public void Get(BaseModel<List<Company>> result, Company model, Int32 level = 1)
        {
            CompanyRequest request = new CompanyRequest();
            request.CompanyId = model.CompanyId;
            request.CompanyPid = model.CompanyPid;
            request.CompanyName = model.CompanyName;
            request.CompanyStatus = model.CompanyStatus;
            request.CompanyTel = model.CompanyTel;
            request.CompanyNameEn = model.CompanyNameEn;
            Get(result, request, level);
        }

        /// <summary>
        /// 公司列表
        /// </summary>
        public void Get(BaseModel<List<Company>> result, CompanyRequest model, Int32 level = 1)
        {
            /* 呼叫資料庫 */
            IQueryable<Company> _result = _context.Company.Where(
                company =>
                    (model.CompanyPid < 0 || company.CompanyPid == model.CompanyPid) &&
                    (model.CompanyId < 1 || company.CompanyId == model.CompanyId) &&
                    (model.CompanyIds == null || model.CompanyIds.Contains(company.CompanyId)) &&
                    (model.CompanyStatus < 1 || company.CompanyStatus == model.CompanyStatus) &&
                    (model.NotCompanyStatus < 1 || company.CompanyStatus != model.NotCompanyStatus) &&
                    (model.CompanyTel == null || company.CompanyTel.Contains(model.CompanyTel)) &&
                    (
                        String.IsNullOrWhiteSpace(model.CompanyName) ||
                        (model.ExactMatch ?
                            company.CompanyName.Equals(model.CompanyName) :
                            company.CompanyName.Contains(model.CompanyName))
                    ) &&
                    (
                        String.IsNullOrWhiteSpace(model.CompanyNameEn) || 
                        (model.ExactMatch ? 
                            company.CompanyNameEn.Equals(model.CompanyNameEn) : 
                            company.CompanyNameEn.Contains(model.CompanyNameEn))
                    )
            );

            List<Company> list = Split(_result.OrderByDescending(company => company.CompanyId), result.PageIndex, result.PageSize);
            Int32 totalCount = _result.Count();

            /* 查找多層 */
            if (level > 1)
            {
                List<Int32> temp = list.Select(data => data.CompanyId).ToList();
                List<Company> temp2;
                while (level > 1 && temp.Count > 0)
                {
                    _result = _context.Company.Where(
                        company => 
                            temp.Contains(company.CompanyPid) &&
                            (model.CompanyStatus < 1 || company.CompanyStatus == model.CompanyStatus)
                    );

                    temp2 = _result.ToList();

                    temp = temp2.Select(data => data.CompanyId).ToList();

                    list.AddRange(temp2);

                    level--;
                }
            }

            /* 結果複製 */
            result.Success = true;
            result.TotalCount = totalCount;
            result.Result = list;
        }

        /// <summary>
        /// 获取所有公司
        /// </summary>
        /// <returns>List<Company></returns>
        public List<Company> GetList(CompanyQuery query)
        {
            //多条件查询
            var where = PredicateBuilder.True<Company>();

            //订单号
            if (query.CompanyIds !=null)
            {
                where = where.And(c => query.CompanyIds.Contains(c.CompanyId));
            }

            var list = _context.Company.Where(where.Compile()).ToList();

            return list;
        }

        /// <summary>
        /// 根据ID集合获取所有公司列表
        /// </summary>
        /// <returns>List<Company></returns>
        public List<Company> GetCompanyListByIds(List<int> ids)
        {
            var list = _context.Company.Where(e=>ids.Contains(e.CompanyId)).ToList();
            return list;
        }

    }
}