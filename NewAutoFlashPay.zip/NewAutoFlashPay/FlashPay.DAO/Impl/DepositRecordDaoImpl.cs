﻿using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity.Parameter;
    using System.Linq;
    using System.Linq.Expressions;

    /// <summary>
    /// 收款记录数据接口实现
    /// </summary>
    /// <remarks>2018-07-06 immi 创建</remarks>
    public class DepositRecordDaoImpl : DepositRecordDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 默认当前月份
        /// </summary>
        /// <param name="context"></param>
        public DepositRecordDaoImpl(FlashPayContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 根据编号获取余额变化记录
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>Company</returns>
        public DepositRecord Get(long id)
        {
            return _context.DepositRecord.Where(x => x.DepositCardId == id).FirstOrDefault();
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        public long Add(DepositRecord model)
        {
            _context.DepositRecord.Add(model);
            _context.SaveChanges();
            return 0;
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        public bool Update(DepositRecord model)
        {
            bool result = false;

            var adjustBalance = _context.DepositRecord.Find(model.OrderNo);
            if (adjustBalance != null)
            {
                _context.SaveChanges();
                result = true;
            }
            return result;
        }

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="orderNo">系统编号</param>
        /// <param name="status">状态</param>
        /// <returns></returns>
        public bool UpdateStatus(long orderNo, SByte status)
        {
            //官方推荐的修改方式（先查询，再修改）
            var model = _context.DepositRecord.Where(p => p.OrderNo.Equals(orderNo)).FirstOrDefault();
            if (model != null)
            {
                return _context.SaveChanges()>0;
            }
            else
            {
                throw new Exception("当前记录不存在！");
            }
        }
    }
}
