﻿using FlashPay.DAO.Shared;
using FlashPay.DAO.Order;
using FlashPay.EF;
using FlashPay.EF.Models;
using FlashPay.Entity.DAORequest.Order;
using FlashPay.Util;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Response.Order;

namespace FlashPay.DAO.Impl.Order
{
    /// <summary>
    /// 訂單DAO
    /// </summary>
    public class OrderRecordDAOImpl : BaseDAO, OrderRecordDAO
    {
        public FlashPayContext dbContext { set; get; }

        public OrderRecordDAOImpl()
        {
            this.dbContext = new FlashPayContext();
        }

        public OrderRecordDAOImpl(DbContext dbContext)
        {
            this.dbContext = (FlashPayContext)dbContext;
        }

        public void Dispose()
        {
            if (this.dbContext != null)
            {
                this.dbContext.Dispose();
            }
        }

        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        public OrderRecord Get(long orderNo)
        {
            var model = dbContext.OrderRecord.Where(x => x.OrderNo == orderNo).FirstOrDefault();
            return model;
        }

        /// <summary>
        /// 获取当前登录人未完成订单
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<CardMerchant></returns>
        public List<OrderRecord> GetFinishOrderNo(BankCardQuery query)
        {
            List<OrderRecord> result = new List<OrderRecord>();
            var CList = dbContext.OrderRecord.Where(a => a.PayUid == 0 && a.CreateUid==query.CreateUid).ToList();
            result = CList;
            return result;
        }
        /// <summary>
        /// 获取所有未完成订单
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>List<CardMerchant></returns>
        public List<OrderRecord> GetNoFinishOrderNo(BankCardQuery query)
        {
            List<OrderRecord> result = new List<OrderRecord>();
            var CList = dbContext.OrderRecord.Where(a => a.PayUid == 0).ToList();
            result = CList;
            return result;
        }

        /// <summary>
        /// 訂單新增
        /// </summary>
        public void Add(BaseModel<String> result, OrderRecord model)
        {
            /* 呼叫資料庫 */
            dbContext.OrderRecord.Add(model);
            dbContext.SaveChanges();

            /* 結果複製 */
            result.Success = true;
        }

        /// <summary>
        /// 訂單修改
        /// </summary>
        public void EditUseOrderNo(BaseModel<String> result, OrderRecord model)
        {
            /* 確認資料存在 */
            Int64 orderNo = model.OrderNo;
            IQueryable<OrderRecord> _result = dbContext.OrderRecord.Where(x => x.OrderNo == orderNo);
            if (_result.Count() != 1)
                return;

            /* 轉換Model */
            OrderRecord orderRecord = _result.First();
            orderRecord.OrderDate = model.OrderDate;
            orderRecord.DepositUid = model.DepositUid;
            orderRecord.DepositDate = model.DepositDate;
            orderRecord.DepositAmount = model.DepositAmount;
            orderRecord.ReceiptDate = model.ReceiptDate;
            orderRecord.PayUid = model.PayUid;
            orderRecord.PayDate = model.PayDate;
            orderRecord.PayAmount = model.PayAmount;
            orderRecord.Cmid = model.Cmid;
            orderRecord.DeliveryNo = model.DeliveryNo;

            /* 呼叫資料庫 */
            dbContext.SaveChanges();

            /* 結果複製 */
            result.Success = true;
        }

        /// <summary>
        /// 訂單刪除
        /// </summary>
        public void DeleteUseOrderNo(BaseModel<String> result, OrderRecord model)
        {
            /* 確認資料存在 */
            Int64 orderNo = model.OrderNo;
            IQueryable<OrderRecord> _result = dbContext.OrderRecord.Where(x => x.OrderNo == orderNo);
            if (_result.Count() != 1)
                return;

            /* 呼叫資料庫 */
            dbContext.OrderRecord.Remove(_result.First());
            dbContext.SaveChanges();

            /* 結果複製 */
            result.Success = true;
        }

        /// <summary>
        /// 訂單列表
        /// </summary>
        public void Get(BaseModel<List<OrderRecord>> result, OrderRecordRequest model)
        {
            Boolean flag = false;
            HashSet<Int32> ids = new HashSet<Int32>();

            if (model.PayUID != null)
            {
                flag = true;
                ids.UnionWith(model.PayUID);
            }

            if (model.DepositUID != null)
            {
                flag = true;
                ids.UnionWith(model.PayUID);
            }

            Boolean flag2 = false;
            HashSet<Int32> ids2 = new HashSet<Int32>();
            if (model.CMID != null)
            {
                flag2 = true;
                ids2.UnionWith(model.CMID);
            }

            /* 呼叫資料庫 */
            IQueryable<OrderRecord> _result = dbContext.OrderRecord.Where(
                orderRecord => 
                    (
                        model.OrderNo == null || 
                        (model.ExactMatch ?
                            orderRecord.OrderNo == model.OrderNo :
                            Convert.ToString(orderRecord.OrderNo).Contains(Convert.ToString(model.OrderNo)))
                    ) &&
                     //(model.CMID == 0 || orderRecord.Cmid == model.CMID) &&
                     (!flag2 || ids2.Contains(orderRecord.Cmid)) &&
                     (model.DeliveryNo == null || orderRecord.DeliveryNo.Contains(model.DeliveryNo)) &&
                    (model.OrderDate == null || orderRecord.OrderDate >= model.OrderDate) &&
                    (model.EndOrderDate == null || orderRecord.OrderDate <= model.EndOrderDate) &&
                    (model.PayDate == null || orderRecord.PayDate >= model.PayDate) &&
                    (model.EndPayDate == null || orderRecord.PayDate <= model.EndPayDate) &&
                    (!flag || ids.Contains(orderRecord.PayUid) || ids.Contains(orderRecord.DepositUid)) &&
                    (model.CreateUID == null || model.CreateUID.Contains(orderRecord.CreateUid)) &&
                    (
                        model.Status == 0 ||
                        (model.Status == 1 && orderRecord.DepositUid == 0) ||
                        (model.Status == 2 && orderRecord.DepositUid != 0 && orderRecord.ReceiptUid == 0) ||
                        (model.Status == 3 && orderRecord.ReceiptUid != 0 && orderRecord.PayUid == 0) ||
                        (model.Status == 4 && orderRecord.PayUid != 0) ||
                        (model.Status == 5 && orderRecord.PayUid<=0)
                    )
            );

            List <OrderRecord> list = Split(_result.OrderByDescending(orderRecord => orderRecord.OrderNo), result.PageIndex, result.PageSize);

            /* 結果複製 */
            result.Success = true;
            result.TotalCount = _result.Count();
            result.Result = list;
        }

        /// <summary>
        /// 查询(押金审核人>0 And 收货审核人=0 And 付款审核人=0 )
        /// </summary>
        /// <param name="companyIds"></param>
        public List<OrderRecord> GetAuditingOrderRecord(List<int> companyIds)
        {
            var q = from or in dbContext.OrderRecord
                    join ui in dbContext.UserInfo on or.CreateUid equals ui.UId
                    where or.DepositUid > 0 && or.ReceiptUid == 0 && or.PayUid == 0 && companyIds.Contains(ui.UCompanyId)
                    select new OrderRecord
                    {
                        OrderNo = or.OrderNo
                    };


            return q.ToList();
        }
    }
}
