﻿using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;

    using FlashPay.EF;

    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.EF.Models;
    using System.Linq.Expressions;
    using FlashPay.Util;
    using FlashPay.DAO.Shared;
    using System.Linq;
    using FlashPay.Entity.Enum;

    public class AuthorizeDaoImpl : BaseDAO, AuthorizeDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _flashPayContext { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public AuthorizeDaoImpl(FlashPayContext context)
        {
            _context = (FlashPayContext)context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }

            if (_flashPayContext != null)
            {
                _flashPayContext.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 获取功能权限列表
        /// </summary>
        /// <param name="roleId">角色编号</param>
        /// <returns>功能权限列表</returns>
        public IList<Authorize> GetPermissionListRoleSysNo(int roleId)
        {
            var list = _context.Authorize.Where(c => c.AuthRid == roleId).ToList();

            return list;
        }

        /// <summary>
        /// 获取功能权限列表
        /// </summary>
        /// <param name="roleId">角色编号</param>
        /// <returns>功能权限列表</returns>
        public IList<Authorize> GetPermissionListRole(int userId)
        {
            var roles = from r in _context.SysRole
                        join
                        ur in _context.UserRole on r.RId equals ur.UrRid
                        where ur.UrUid == userId
                        select new {
                            r.RId
                        };

            var ids = new List<int>();
            foreach (var item in roles) {
                ids.Add(item.RId);
            }

            var list = _context.Authorize.Where(p=> ids.Contains(p.AuthRid)).ToList();

            return list;
        }

        /// <summary>
        /// 获取功能权限列表
        /// </summary>
        /// <param name="roleId">角色编号</param>
        /// <param name="authType">授权类型</param>
        /// <returns>功能权限列表</returns>
        public IList<Authorize> GetPermissionByRoleSysNo(List<int> roleId, List<int> unselectedPIds,int authType, FlashPayContext flashPayContext = null)
        {
            var _flashPayContext = (flashPayContext ?? _context);

            return _flashPayContext.Authorize.Where(c => roleId.Contains(c.AuthRid) && unselectedPIds.Contains(c.AuthPid) && c.AuthType == (sbyte)authType).ToList();
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        public int Add(Authorize model, FlashPayContext flashPayContext = null)
        {
            var _flashPayContext = (flashPayContext ?? _context);
            _flashPayContext.Authorize.Add(model);
            _flashPayContext.SaveChanges();
            return model.AuthId;
        }

        /// <summary>
        /// 删除角色所有数据
        /// </summary>
        /// <param name="roleSysNo">角色编号</param>
        /// <returns></returns>
        public bool DeleteByRoleSysNo(int roleId, FlashPayContext flashPayContext = null)
        {

            var result = false;

            var _flashPayContext = (flashPayContext ?? _context);

            var authorizeList = _flashPayContext.Authorize.Where(p => p.AuthRid.Equals(roleId)).ToList();
            authorizeList.ForEach(item => {
                _flashPayContext.Authorize.Remove(item);
                if (_flashPayContext.SaveChanges() > 0)
                {
                    result = true;
                }
            });
            return result;
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="authPId">系统编号</param>
        /// <returns></returns>
        public bool DeleteByAuthId(int authId, FlashPayContext flashPayContext = null)
        {
            var _flashPayContext = (flashPayContext ?? _context);

            
            var model = _flashPayContext.Authorize.Find(authId);
            if (model != null)
            {
                _flashPayContext.Authorize.Remove(model);
                if (_flashPayContext.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="authPId">系统编号</param>
        /// <returns></returns>
        public bool DeleteByAuthId(List<int> authIds, FlashPayContext flashPayContext = null)
        {
            var _flashPayContext = (flashPayContext ?? _context);


            var list = _flashPayContext.Authorize.Where(p=> authIds.Contains(p.AuthId)).ToList();

            _flashPayContext.Authorize.RemoveRange(list);
            if (_flashPayContext.SaveChanges() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 获取所有用户记录
        /// </summary>
        /// <param name="request">查询条件</param>
        /// <returns>List<UserInfo></returns>
        public List<Authorize> GetList(AuthorizeQuery request)
        {
            //角色
            var roleStatusIds = _context.SysRole.Where(p => p.RStatus == RoleStatus.显示.GetHashCode()).Select(p=>p.RId).ToList();
            //用户角色
            var roleIds = _context.UserRole.Where(p => p.UrUid == request.UserSysNo.Value).Where(p=> roleStatusIds.Contains(p.UrRid)).Select(p=>p.UrRid).ToList();
            //权限列表
            //var authorizes = _context.Authorize.Where(p => roleIds.Contains(p.AuthRid)).Where(p=>p.AuthType == request.AuthorizeType.Value).ToList();
            var authorizes = _context.Authorize.Where(p => roleIds.Contains(p.AuthRid)).Where(p => p.AuthType == request.AuthorizeType.Value).ToList();

            return authorizes;
        }

        /// <summary>
        /// 获取所有用户记录
        /// </summary>
        /// <param name="request">查询条件</param>
        /// <returns>List<UserInfo></returns>
        public List<Authorize> GetMenuAuthorizes(AuthorizeQuery request)
        {
            //角色
            var roleStatusIds = _context.SysRole.Where(p => p.RStatus == RoleStatus.显示.GetHashCode()).Select(p => p.RId).ToList();
            //用户角色
            var roleIds = _context.UserRole.Where(p => p.UrUid == request.UserSysNo.Value).Where(p => roleStatusIds.Contains(p.UrRid)).Select(p => p.UrRid).ToList();
            //权限列表
            var authorizes = _context.Authorize.Where(p => roleIds.Contains(p.AuthRid)).Where(p => p.AuthType == request.AuthorizeType.Value).ToList();

            return authorizes;
        }
    }
}
