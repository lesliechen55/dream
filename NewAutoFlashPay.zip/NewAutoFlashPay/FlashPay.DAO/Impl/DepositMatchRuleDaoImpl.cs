﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity;
    using FlashPay.Entity.Enum;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.DepositMatchRule;
    using Microsoft.EntityFrameworkCore;
    using System.Linq;
    using System.Linq.Expressions;

    /// <summary>
    /// 收款匹配规则数据接口实现
    /// </summary>
    public class DepositMatchRuleDaoImpl : DepositMatchRuleDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public DepositMatchRuleDaoImpl(FlashPayContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 获取
        /// </summary>
        /// <param name="id">编号</param>
        public DepositMatchRule Get(int id)
        {
            return _context.DepositMatchRule.Where(x => x.Id == id).FirstOrDefault();
        }

        /// <summary>
        /// 根据companyId、bankcode查询匹配规则
        /// </summary>
        /// <param name="companyId"></param>
        /// <returns></returns>
        public DepositMatchRule GetRuleByCompanyId(int companyId, string bankcode)
        {
            var t = _context.DepositMatchRule.Where(x =>
            (x.MatchBankCode.Contains(bankcode) || string.IsNullOrEmpty(x.MatchBankCode)) && x.CompanyId == companyId
            ).OrderByDescending(x => x.MatchBankCode).ToList();

            DepositMatchRule newMatchRule = new DepositMatchRule();
            for (int i = 0; i < t.Count; i++)
            {
                if (string.IsNullOrEmpty(t[i].MatchBankCode))
                {
                    newMatchRule = t[i];
                    break;
                }
                string[] ss = t[i].MatchBankCode.Split(",");
                for (int j = 0; j < ss.Length; j++)
                {
                    if (ss[j] == bankcode)
                    {
                        newMatchRule = t[i];
                        break;
                    }
                }
            }
            return newMatchRule;
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(DepositMatchRule model, FlashPayContext flashPayContext = null)
        {
            var _flashPayContext = (flashPayContext ?? _context);
            _flashPayContext.DepositMatchRule.Add(model);
            //调用数据上下文的保存方法，将对象存数数据库
            var resultId = _flashPayContext.SaveChanges();

            return resultId;
        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        public bool Update(DepositMatchRule model, FlashPayContext flashPayContext = null)
        {
            var _flashPayContext = (flashPayContext ?? _context);

            _flashPayContext.Entry<DepositMatchRule>(model);
            _flashPayContext.SaveChanges();
            return true;
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id">系统编号</param>
        /// <returns></returns>
        public bool Delete(int id)
        {
            var model = _context.DepositMatchRule.Find(id);
            if (model != null)
            {
                _context.DepositMatchRule.Remove(model);
                if (_context.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public List<DepositMatchRule> GetList(DepositMatchRuleQuery query)
        {
            //多条件查询
            var where = PredicateBuilder.True<DepositMatchRule>();

            if (query.NotEqualId.HasValue)
            {
                where = where.And(c => c.Id != query.NotEqualId.Value);
            }

            if (query.CompanyId.HasValue)
            {
                where = where.And(c => c.CompanyId == query.CompanyId.Value);
            }

            if (query.CompanyIds != null && query.CompanyIds.Any())
            {
                //where = where.And(c => query.CompanyIds.Contains(""));
            }

            var list = _context.DepositMatchRule.Where(where.Compile()).ToList();

            return list;
        }

        public void GetThisOneCompanyMatchRule()
        {

        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns>PagedList<Permission></returns>
        public PagedList<DepositMatchRuleResponse> GetPager(DepositMatchRuleQuery query)
        {

            var q = from dmr in _context.DepositMatchRule
                    join
                    c in _context.Company on dmr.CompanyId equals c.CompanyId
                    join
                    u in _context.UserInfo on dmr.CreateId equals u.UId
                    select new
                    {
                        dmr.Id,
                        dmr.CompanyId,
                        UserCompanyId = u.UCompanyId,
                        c.CompanyName,
                        c.CompanyNameEn,
                        dmr.MatchMinute,
                        dmr.MatchBankCode,
                        dmr.MatchRule,
                        dmr.MatchRemark,
                        dmr.CreateId,
                        dmr.CreateDate
                    };
            //银行卡启用状态
            if (query.CompanyIds != null && query.CompanyIds.Any())
            {
                q = q.Where(c => query.CompanyIds.Contains(c.UserCompanyId));
            }

            var list = q.Skip((query.CurrentPageIndex.Value - 1) * query.PageSize.Value).OrderByDescending(p => p.CreateDate).Take(query.PageSize.Value).ToList();
            var total = q.Count();

            #region 数据转换
            var bankInfos = _context.BankInfo.ToList();

            var depositMatchRuleResponses = new List<DepositMatchRuleResponse>();
            list.ForEach(item =>
            {

                var matchRule = "";
                var matchBankCode = "";

                #region 媒合规则
                if (!string.IsNullOrEmpty(item.MatchRule))
                {

                    var matchRules = new List<string>();

                    var matchRuleArray = item.MatchRule.Split(',');
                    if (matchRuleArray != null && matchRuleArray.Any())
                    {
                        foreach (var rule in matchRuleArray)
                        {
                            var ruleText = (MatchRule)int.Parse(rule);

                            matchRules.Add(ruleText.ToString());
                        }
                    }

                    if (matchRules != null && matchRules.Count > 0)
                    {
                        matchRule = string.Join(",", matchRules);
                    }
                }
                #endregion

                #region 收款银行
                if (!string.IsNullOrEmpty(item.MatchBankCode))
                {
                    var matchBankCodes = new List<string>();

                    var matchBankCodeArray = item.MatchBankCode.Split(',');
                    if (matchBankCodeArray != null && matchBankCodeArray.Any())
                    {
                        foreach (var bankCode in matchBankCodeArray)
                        {
                            var bankInfo = bankInfos.FirstOrDefault(p => p.BankCode == bankCode);
                            if (bankInfo != null)
                            {
                                matchBankCodes.Add(bankInfo.BankName);
                            }
                        }

                        if (matchBankCodes != null && matchBankCodes.Count > 0)
                        {
                            matchBankCode = string.Join(",", matchBankCodes);
                        }
                    }
                }
                #endregion

                depositMatchRuleResponses.Add(new DepositMatchRuleResponse()
                {
                    Id = item.Id,
                    CompanyId = item.CompanyId,
                    CompanyName = item.CompanyName,
                    CompanyNameEn = item.CompanyNameEn,
                    MatchMinute = item.MatchMinute,
                    MatchBankCode = matchBankCode,
                    MatchRule = matchRule,
                    MatchRemark = item.MatchRemark,
                    CreateId = item.CreateId,
                    CreateDate = item.CreateDate
                });
            });
            #endregion

            return new PagedList<DepositMatchRuleResponse>()
            {
                TotalCount = total,
                TData = depositMatchRuleResponses,
                Success = true,
            };
        }
    }
}
