﻿using FlashPay.DAO.Interface;
using FlashPay.DAO.Shared;
using FlashPay.EF;
using FlashPay.EF.Models;
using FlashPay.Entity.Parameter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlashPay.DAO.Impl
{
    public class BankCardTypeRecordDaoImpl : BaseDAO, IDisposable, BankCardTypeRecordDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext dbContext { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public BankCardTypeRecordDaoImpl(FlashPayContext context)
        {
            dbContext = context;
        }

        public void Dispose()
        {
            if (dbContext != null)
            {
                dbContext.Dispose();
            }
        }
        #endregion

        public List<BankCardTypeRecord> GetCardTypeRecordList(BankCardTypeRecordQuery query) {
           return dbContext.BankCardTypeRecord.Where(e => e.CardNumber == query.CardNumber)
                .OrderByDescending(e=>e.RecordType).OrderByDescending(e=>e.Id).ToList();
        }

    }
}
