﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;
    using FlashPay.EF;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Response.Transfer;
    using Microsoft.EntityFrameworkCore;
    using System.Collections.Generic;

    /// <summary>
    /// 中转卡数据接口实现
    /// </summary>
    /// <remarks>2018-10-01 immi 创建</remarks>
    public class TransferDaoImpl :TransferDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context">EF上下文</param>
        public TransferDaoImpl(FlashPayContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 获取中转卡
        /// </summary>
        /// <param name="query">查看参数</param>
        public PagedList<TransferCardResponse> TransferCardPager(TransferCardQuery query)
        {
            var q = from bc in _context.BankCard
                    join
                    c in _context.Company on bc.CompanyId equals c.CompanyId
                    where query.CardType.Contains(bc.CardType) && bc.CompanyId > 0
                    select new
                    {
                        bc.Bcid,
                        c.CompanyId,
                        c.CompanyName,
                        c.CompanyNameEn,
                        bc.BankName,
                        bc.CardNumber,
                        bc.CardName,
                        bc.CardType,
                        bc.UsingStatus,
                        bc.EnableStatus,
                        bc.Balance,
                        bc.BalanceLastUpdate,
                        //TimeDifference
                        bc.DepositFeeRatio,
                        bc.IpAddress
                    };
            //银行卡启用状态
            if (query.CompanyIds != null && query.CompanyIds.Any())
            {
                q = q.Where(c => query.CompanyIds.Contains(c.CompanyId));
            }
            //公司名称
            if (!string.IsNullOrEmpty(query.CompanyName))
            {
                q = q.Where(c => c.CompanyName.Contains(query.CompanyName));
            }
            //银行卡用戶名
            if (!string.IsNullOrEmpty(query.CardName))
            {
                q = q.Where(c => c.CardName.Contains(query.CardName));
            }
            //銀行卡号
            if (!string.IsNullOrEmpty(query.CardNumber))
            {
                q = q.Where(c => c.CardNumber.Contains(query.CardNumber));
            }
            //银行卡启用状态
            if (query.EnableStatus.HasValue)
            {
                q = q.Where(c => c.EnableStatus == query.EnableStatus.Value);
            }
            var list = q.Skip((query.CurrentPageIndex.Value - 1) * query.PageSize.Value).Take(query.PageSize.Value).ToList();
            var total = q.Count();

            var transferCardResponses = new List<TransferCardResponse>();

            list.ForEach(item => {

                var transferCardResponse = new TransferCardResponse()
                {
                    BcId = item.Bcid,
                    CompanyId = item.CompanyId,
                    CompanyName = item.CompanyName,
                    CompanyNameEn = item.CompanyNameEn,
                    BankName = item.BankName,
                    CardNumber = item.CardNumber,
                    CardName = item.CardName,
                    CardType = item.CardType,
                    UsingStatus = item.UsingStatus,
                    EnableStatus = item.EnableStatus,
                    Balance = item.Balance.HasValue ? item.Balance.Value.ToString("#0.00") : null,
                    BalanceLastUpdate = item.BalanceLastUpdate.HasValue ? item.BalanceLastUpdate.Value.ToString("yyyy-MM-dd HH:mm:ss") : null,
                    TimeDifference = 0,
                    DepositFeeRatio = (item.DepositFeeRatio * 100).ToString("#0.00"),
                    IpAddress = item.IpAddress
                };

                if (item.BalanceLastUpdate.HasValue) {
                    var balanceLastUpdate = item.BalanceLastUpdate.Value;
                    var ts = DateTime.Now.Subtract(balanceLastUpdate).TotalMinutes;
                    if (ts > 0)
                    {
                        transferCardResponse.TimeDifference = ts;
                    }
                }

                transferCardResponses.Add(transferCardResponse);

            });

            return new PagedList<TransferCardResponse>()
            {
                TotalCount = total,
                TData = transferCardResponses,
                Success = true,
            };
        }

        /// <summary>
        /// 获取中转卡记录
        /// </summary>
        /// <param name="query">查看参数</param>
        public DataGrid<TransferCardRecordResponse> TransferCardRecordPager(TransferCardRecordQuery query)
        {
            var sql = string.Format("call sp_SelectTransportRecord('{0}', '{1}', '{2}');", query.StartTime, query.EndTime, string.Join(", ", query.CompanyIds));
            
            //公司列表
            var companys = _context.Company.ToList();
            //银行卡列表
            var bankCards = _context.BankCard.ToList();

            var q = _context.TransportRecord
                    .FromSql(sql)
                    .ToList();

            var list = q.Skip((query.Page.Value - 1) * query.Rows.Value).Take(query.Rows.Value).OrderByDescending(p => p.CreateDate).ToList();

            #region 模型转换
            var transferCardRecordResponses = new List<TransferCardRecordResponse>();

            list.ForEach(item => {

                #region 公司
                var companyName = "";
                var companyNameEn = "";
                if (companys != null && companys.Any())
                {
                    var company = companys.FirstOrDefault(p => p.CompanyId == item.CompanyId);
                    if (company != null)
                    {
                        companyName = company.CompanyName;
                        companyNameEn = company.CompanyNameEn;
                    }
                }
                #endregion

                #region 银行卡
                var bankName = "";
                var cardName = "";
                var cardNumber = "";
                if (bankCards != null && bankCards.Any())
                {
                    var bankCard = bankCards.FirstOrDefault(p => p.Bcid == item.TransportCardId);
                    if (bankCard != null)
                    {
                        bankName = bankCard.BankName;
                        cardName = bankCard.CardName;
                        cardNumber = bankCard.CardNumber;
                    }
                }
                #endregion

                var transferCardRecordResponse = new TransferCardRecordResponse();

                transferCardRecordResponse.OrderNo = item.OrderNo.ToString();
                transferCardRecordResponse.CompanyName = companyName;
                transferCardRecordResponse.CompanyNameEn = companyNameEn;
                transferCardRecordResponse.WithdrawalOrderNo = item.WithdrawalOrderNo;
                transferCardRecordResponse.BankName = bankName;
                transferCardRecordResponse.CardName = cardName;
                transferCardRecordResponse.CardNumber = cardNumber;
                transferCardRecordResponse.WithdrawalAmount = item.WithdrawalAmount.ToString("#0.00");
                transferCardRecordResponse.TransportDate = item.TransportDate.HasValue ? item.TransportDate.Value.ToString("yyyy-MM-dd HH:mm:ss") : null;
                transferCardRecordResponse.TransportStatus = item.TransportStatus;
                transferCardRecordResponse.NoticeStatus = item.NoticeStatus;
                transferCardRecordResponse.NoticeLastDate = item.NoticeLastDate.HasValue ? item.NoticeLastDate.Value.ToString("yyyy-MM-dd HH:mm:ss") : null;
                transferCardRecordResponse.NoticeTimes = item.NoticeTimes;
                transferCardRecordResponse.WithdrawalAccountName = item.WithdrawalAccountName;
                transferCardRecordResponse.WithdrawalBankName = item.WithdrawalBankName;
                transferCardRecordResponse.WithdrawalCardNumber = item.WithdrawalCardNumber;
                transferCardRecordResponse.CreateDBDate = item.CreateDbdate.ToString("yyyy-MM-dd HH:mm:ss");

                transferCardRecordResponses.Add(transferCardRecordResponse);
            });
            #endregion

            return new DataGrid<TransferCardRecordResponse>()
            {
                Total = q.Count(),
                Rows = transferCardRecordResponses,
                Success = true,
            };
        }
    }
}
