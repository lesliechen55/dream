﻿using System;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using System.Linq;

    /// <summary>
    /// 付款接口实现
    /// </summary>
    public class PaymentInterfaceDaoImpl : IDisposable, PaymentInterfaceDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 公司数据接口
        /// </summary>
        private readonly CompanyDao _companyDao;

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context">EF上下文</param>
        /// <param name="companyDao">公司</param>
        public PaymentInterfaceDaoImpl(FlashPayContext context, CompanyDao companyDao)
        {
            _context = context;
            _companyDao = companyDao;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 根据付款接口
        /// </summary>
        public PaymentInterface GetById(int companyId)
        {
            return _context.PaymentInterface.Where(x => x.CompanyID == companyId).FirstOrDefault();
        }

        /// <summary>
        /// 新增付款接口
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        public int Add(PaymentInterface model)
        {
            _context.PaymentInterface.Add(model);
            _context.SaveChanges();
            return model.CompanyID;
        }

        /// <summary>
        /// 更新付款接口
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        public bool Update(PaymentInterface model)
        {
            _context.Entry<PaymentInterface>(model);
            _context.SaveChanges();
            return true;
        }
    }
}
