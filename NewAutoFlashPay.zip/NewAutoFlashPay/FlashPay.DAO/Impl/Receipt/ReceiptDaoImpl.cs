﻿using FlashPay.DAO.Interface;
using FlashPay.DAO.Interface.Receipt;
using FlashPay.DAO.Shared;
using FlashPay.EF;
using FlashPay.EF.Models;
using FlashPay.Entity;
using FlashPay.Entity.Enum;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Response.Payment;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlashPay.DAO.Impl.Receive
{
    public class ReceiptDaoImpl : BaseDAO, ReceiptDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        //private FlashPayDynamicContext _context { set; get; }
        //public ReceiptDaoImpl()
        //{
        //    _context = new FlashPayDynamicContext(DateTime.Now.ToString("MM"));
        //}

        private FlashPayContext _context { set; get; }
        public ReceiptDaoImpl(FlashPayContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 获取订单月份
        /// </summary>
        /// <param name="orderNo">订单号</param>
        /// <returns></returns>
        private string GetOrderMonth(long orderNo)
        {
            return orderNo.ToString().Substring(4, 2);
        }

        // 获取收款卡管理
        public PagedList<PaymentCardResponse> GetList(PaymentCardQuery query)
        {
            PagedList<PaymentCardResponse> result = new PagedList<PaymentCardResponse>()
            {
                Success = false
            };

            try
            {
                var q = from bc in _context.BankCard
                        join c in _context.Company on bc.CompanyId equals c.CompanyId

                        //只有已分配公司，且是收款卡
                        where bc.CardType == query.CardType 
                        && query.CompanyIds.Contains(bc.CompanyId)

                        select new
                        {
                            c.CompanyName,
                            c.CompanyNameEn,
                            bc.Bcid,
                            bc.BankName,
                            bc.CardNumber,
                            bc.CardName,
                            bc.CardType,
                            bc.UsingStatus,
                            bc.EnableStatus,
                            bc.PaymentStart,
                            bc.PaymentEnd,
                            bc.PayFeeRatio,
                            bc.DepositType,
                            bc.CrossBankPay,
                            bc.DepositFeeRatio,
                            //,AdjustBalanceResponses =x
                            bc.Balance,
                            bc.BalanceLastUpdate,
                            bc.IpAddress,
                            bc.CreateDate
                        };

                #region 搜索条件
                //公司名称
                if (!string.IsNullOrEmpty(query.CompanyName))
                {
                    q = q.Where(c => c.CompanyName.Contains(query.CompanyName));
                }
                //銀行名称
                if (!string.IsNullOrEmpty(query.BankName))
                {
                    q = q.Where(c => c.BankName.Contains(query.BankName));
                }
                //銀行卡號
                if (!string.IsNullOrEmpty(query.CardNumber))
                {
                    q = q.Where(c => c.CardNumber.Contains(query.CardNumber));
                }
                //銀行卡用戶名
                if (!string.IsNullOrEmpty(query.CardName))
                {
                    q = q.Where(c => c.CardName.Contains(query.CardName));
                }
                //启用状态
                if (query.EnableStatus == 1 || query.EnableStatus == 2)
                {
                    q = q.Where(c => c.EnableStatus == query.EnableStatus);
                }
                #endregion

                #region 模型转换

                var paymentCardResponses = new List<PaymentCardResponse>();

                var list = q.Skip((query.CurrentPageIndex.Value - 1) * query.PageSize.Value).Take(query.PageSize.Value).ToList();
                list.ForEach(item =>
                {
                    var paymentCardResponse = new PaymentCardResponse()
                    {
                        CompanyName = item.CompanyName,
                        CompanyNameEn = item.CompanyNameEn,
                        Bcid = item.Bcid,
                        BankName = item.BankName,
                        CardNumber = Util.WebUtil.SetCardNumber(item.CardNumber),
                        CardName = item.CardName,
                        CardType = item.CardType,
                        UsingStatus = item.UsingStatus,
                        EnableStatus = item.EnableStatus,
                        PayFeeRatio = item.PayFeeRatio,
                        DepositType = item.DepositType,
                        CrossBankPay = item.CrossBankPay,
                        DepositFeeRatio = item.DepositFeeRatio,
                        Balance = item.Balance.HasValue ? item.Balance.Value.ToString("#0.0000") : null,
                        BalanceLastUpdate = item.BalanceLastUpdate.HasValue ? item.BalanceLastUpdate.Value.ToString("yyyy-MM-dd HH:mm:ss") : null,
                        IpAddress = item.IpAddress
                    };
                    if (item.BalanceLastUpdate.HasValue)
                    {
                        var balanceLastUpdate = item.BalanceLastUpdate.Value;
                        var ts = DateTime.Now.Subtract(balanceLastUpdate).TotalMinutes;
                        if (ts > 0)
                        {
                            paymentCardResponse.TimeDifference = ts;
                        }
                    }
                    paymentCardResponses.Add(paymentCardResponse);
                });
                #endregion

                result.TotalCount = q.Count();
                result.TData = paymentCardResponses;
                result.Success = true;
            }
            catch (Exception ex)
            {
                result.ErrorMessage = "服务器异常";
            }
            return result;
        }

        // 获取付款记录列表
        public PagedList<DepositOrPaymentRecordResponse> GetReceiptRecordList(PaymentRecordQuery query)
        {
            PagedList<DepositOrPaymentRecordResponse> result = new PagedList<DepositOrPaymentRecordResponse>()
            {
                Success = false
            };
            try
            {
                if (query.StartTime == null || query.EndTime == null || query.CompanyIds == null)
                {
                    result.ErrorMessage = "参数错误";
                    return result;
                }

                var sql = string.Format("call {0}('{1}', '{2}', '{3}');", "sp_SelectDepositRecord", query.StartTime, query.EndTime, string.Join(", ", query.CompanyIds));

                var q = _context.DepositRecord.FromSql(sql);

                //订单号
                if (query.OrderNo.HasValue)
                {
                    q = q.Where(c => c.OrderNo == query.OrderNo.Value);
                }

                //客户姓名
                if (!string.IsNullOrEmpty(query.WithdrawalAccountName))
                {
                    q = q.Where(c => c.ClientAccountName.Contains(query.WithdrawalAccountName));
                }

                //通知状态
                if (query.NoticeStatus > -1)
                {
                    q = q.Where(c => c.NoticeStatus == query.NoticeStatus);
                }

                var companys = _context.Company.ToList();
                var bankCards = _context.BankCard.ToList();

                //收款名称
                if (!string.IsNullOrEmpty(query.CardName))
                {
                    var cardSearch = bankCards.Where(p => p.CardName.Contains(query.CardName)).ToList();
                    if (cardSearch != null && cardSearch.Any())
                    {
                        q = q.Where(c => cardSearch.Select(p => p.Bcid).Contains(c.DepositCardId));
                    }
                    else
                    {
                        q = q.Where(c => c.DepositCardId == -1);
                    }
                }

                #region 新增搜索条件
                //匹配流水号
                if (query.Type == 1)
                {
                    q = q.Where(c => c.DepositMatchID == null);
                }

                //收款金额
                if (query.DepositAmount > 0)
                {
                    q = q.Where(c => c.DepositAmount == query.DepositAmount);
                }

                //银行卡编号
                if (!string.IsNullOrEmpty(query.BankCode))
                {
                    var cardSearch = bankCards.Where(p => p.BankCode.Contains(query.BankCode)).ToList();
                    if (cardSearch != null && cardSearch.Any())
                    {
                        q = q.Where(c => cardSearch.Select(p => p.Bcid).Contains(c.DepositCardId));
                    }
                    else
                    {
                        q = q.Where(c => c.DepositCardId == -1);
                    }
                }
                #endregion

                var list = q.OrderByDescending(e => e.CreateDbdate).Skip((query.Page.Value - 1) * query.Rows.Value).Take(query.Rows.Value).ToList();

                #region 模型转换
                var depositOrPaymentRecordResponses = new List<DepositOrPaymentRecordResponse>();

                list.ForEach(item =>
                {
                    var depositOrPaymentRecordResponse = new DepositOrPaymentRecordResponse();

                    #region 公司
                    var companyName = "";
                    var companyNameEn = "";
                    if (companys != null && companys.Any())
                    {
                        var company = companys.FirstOrDefault(p => p.CompanyId == item.CompanyId);
                        if (company != null)
                        {
                            companyName = company.CompanyName;
                            companyNameEn = company.CompanyNameEn;
                        }
                    }
                    #endregion

                    #region 银行卡
                    var bankName = "";
                    var cardName = "";
                    var cardNumber = "";
                    if (bankCards != null && bankCards.Any())
                    {
                        var bankCard = bankCards.FirstOrDefault(p => p.Bcid == item.DepositCardId);
                        if (bankCard != null)
                        {
                            bankName = bankCard.BankName;
                            cardName = bankCard.CardName;
                            cardNumber = bankCard.CardNumber;
                        }
                    }
                    #endregion

                    depositOrPaymentRecordResponse.OrderNo = item.OrderNo.ToString();
                    depositOrPaymentRecordResponse.CompanyName = companyName;
                    depositOrPaymentRecordResponse.CompanyNameEn = companyNameEn;
                    depositOrPaymentRecordResponse.BankName = bankName;
                    depositOrPaymentRecordResponse.CardName = cardName;
                    depositOrPaymentRecordResponse.CardNumber = Util.WebUtil.SetCardNumber(cardNumber);

                    depositOrPaymentRecordResponse.WithdrawalOrderNo = item.DepositNo;
                    depositOrPaymentRecordResponse.WithdrawalAmount = item.DepositAmount.ToString("#0.00");//收款余额
                    depositOrPaymentRecordResponse.PaymentDate = item.DepositDate;       //收款时间
                    //存款等级这个字段没啥用，用来显示交易类型
                    depositOrPaymentRecordResponse.DepositType = GetTransType(item.Transtype);
                    depositOrPaymentRecordResponse.WithdrawalAccountName = item.ClientAccountName;
                    depositOrPaymentRecordResponse.WithdrawalBankName = item.ClientBankName;
                    depositOrPaymentRecordResponse.WithdrawalCardNumber = item.ClientCardNumber;

                    depositOrPaymentRecordResponse.PostScript = item.PostScript;
                    depositOrPaymentRecordResponse.NoticeStatus = item.NoticeStatus;
                    if (item.NoticeLastTime != null)
                    {
                        depositOrPaymentRecordResponse.NoticeLastDate = item.NoticeLastTime.Value.ToString("yyyy-MM-dd HH:mm:ss");
                    }
                    depositOrPaymentRecordResponse.NoticeTimes = item.NoticeTimes;
                    depositOrPaymentRecordResponse.CreateDbdate = item.CreateDbdate;
                    //(分钟)(当前时间-收款记录创建时间)>20
                    var ts = DateTime.Now.Subtract(item.CreateDate).TotalMinutes;
                    if (ts > 0)
                    {
                        depositOrPaymentRecordResponse.TimeDifference = ts;
                    }

                    depositOrPaymentRecordResponses.Add(depositOrPaymentRecordResponse);
                });
                #endregion

                result.TotalCount = q.Count();
                result.TData = depositOrPaymentRecordResponses;
                result.Success = true;
            }
            catch (Exception ex)
            {
                result.ErrorMessage = "服务器异常";
            }
            return result;
        }

        /// <summary>
        /// 存款记录查询
        /// </summary>
        /// <param name="query">查询条件</param>
        public DataGrid<DepositRecordResponse> GetReceiptRecord(DepositRecordQuery query)
        {
            var result = new DataGrid<DepositRecordResponse>()
            {
                Success = false
            };

            try
            {
                if (query.StartTime == null || query.EndTime == null || query.CompanyIds == null)
                {
                    throw new Exception("参数错误");
                }

                var sql = string.Format("call {0}('{1}', '{2}', '{3}');", "sp_SelectDepositRecord", query.StartTime, query.EndTime, string.Join(", ", query.CompanyIds));

                var q = _context.DepositRecord.FromSql(sql);

                //订单号
                if (query.OrderNo.HasValue)
                {
                    q = q.Where(c => c.OrderNo == query.OrderNo.Value);
                }

                //客户姓名
                if (!string.IsNullOrEmpty(query.WithdrawalAccountName))
                {
                    q = q.Where(c => c.ClientAccountName.Contains(query.WithdrawalAccountName));
                }

                //通知状态
                if (query.NoticeStatus > -1)
                {
                    q = q.Where(c => c.NoticeStatus == query.NoticeStatus);
                }

                var companys = _context.Company.ToList();
                var bankCards = _context.BankCard.ToList();

                //收款名称
                if (!string.IsNullOrEmpty(query.CardName))
                {
                    var cardSearch = bankCards.Where(p => p.CardName.Contains(query.CardName)).ToList();
                    if (cardSearch != null && cardSearch.Any())
                    {
                        q = q.Where(c => cardSearch.Select(p => p.Bcid).Contains(c.DepositCardId));
                    }
                    else
                    {
                        q = q.Where(c => c.DepositCardId == -1);
                    }
                }

                #region 新增搜索条件
                //匹配流水号
                if (query.Type == 1)
                {
                    q = q.Where(c => c.DepositMatchID == null);
                }

                //收款金额
                if (query.DepositAmount > 0)
                {
                    q = q.Where(c => c.DepositAmount == query.DepositAmount);
                }

                //银行卡编号
                if (!string.IsNullOrEmpty(query.BankCode))
                {
                    var cardSearch = bankCards.Where(p => p.BankCode.Contains(query.BankCode)).ToList();
                    if (cardSearch != null && cardSearch.Any())
                    {
                        q = q.Where(c => cardSearch.Select(p => p.Bcid).Contains(c.DepositCardId));
                    }
                    else
                    {
                        q = q.Where(c => c.DepositCardId == -1);
                    }
                }
                #endregion

                var list = q.OrderByDescending(e => e.CreateDbdate).Skip((query.Page.Value - 1) * query.Rows.Value).Take(query.Rows.Value).ToList();

                #region 模型转换
                var depositOrPaymentRecordResponses = new List<DepositRecordResponse>();

                list.ForEach(item =>
                {
                    var depositOrPaymentRecordResponse = new DepositRecordResponse();

                    #region 公司
                    var companyName = "";
                    var companyNameEn = "";
                    if (companys != null && companys.Any())
                    {
                        var company = companys.FirstOrDefault(p => p.CompanyId == item.CompanyId);
                        if (company != null)
                        {
                            companyName = company.CompanyName;
                            companyNameEn = company.CompanyNameEn;
                        }
                    }
                    #endregion

                    #region 银行卡
                    var bankName = "";
                    var cardName = "";
                    var cardNumber = "";
                    if (bankCards != null && bankCards.Any())
                    {
                        var bankCard = bankCards.FirstOrDefault(p => p.Bcid == item.DepositCardId);
                        if (bankCard != null)
                        {
                            bankName = bankCard.BankName;
                            cardName = bankCard.CardName;
                            cardNumber = bankCard.CardNumber;
                        }
                    }
                    #endregion

                    depositOrPaymentRecordResponse.OrderNo = item.OrderNo.ToString();
                    depositOrPaymentRecordResponse.CompanyName = companyName;
                    depositOrPaymentRecordResponse.CompanyNameEn = companyNameEn;
                    depositOrPaymentRecordResponse.BankName = bankName;
                    depositOrPaymentRecordResponse.CardName = cardName;
                    depositOrPaymentRecordResponse.CardNumber = Util.WebUtil.SetCardNumber(cardNumber);

                    depositOrPaymentRecordResponse.WithdrawalOrderNo = item.DepositNo;
                    depositOrPaymentRecordResponse.WithdrawalAmount = item.DepositAmount.ToString("#0.00");//收款余额
                    depositOrPaymentRecordResponse.PaymentDate = item.DepositDate;       //收款时间
                    //存款等级这个字段没啥用，用来显示交易类型
                    depositOrPaymentRecordResponse.DepositType = GetTransType(item.Transtype);
                    depositOrPaymentRecordResponse.WithdrawalAccountName = item.ClientAccountName;
                    depositOrPaymentRecordResponse.WithdrawalBankName = item.ClientBankName;
                    depositOrPaymentRecordResponse.WithdrawalCardNumber = item.ClientCardNumber;

                    depositOrPaymentRecordResponse.PostScript = item.PostScript;
                    depositOrPaymentRecordResponse.NoticeStatus = item.NoticeStatus;
                    if (item.NoticeLastTime != null)
                    {
                        depositOrPaymentRecordResponse.NoticeLastDate = item.NoticeLastTime.Value.ToString("yyyy-MM-dd HH:mm:ss");
                    }
                    depositOrPaymentRecordResponse.NoticeTimes = item.NoticeTimes;
                    depositOrPaymentRecordResponse.CreateDbdate = item.CreateDbdate;
                    //(分钟)(当前时间-收款记录创建时间)>20
                    var ts = DateTime.Now.Subtract(item.CreateDate).TotalMinutes;
                    if (ts > 0)
                    {
                        depositOrPaymentRecordResponse.TimeDifference = ts;
                    }

                    depositOrPaymentRecordResponses.Add(depositOrPaymentRecordResponse);
                });
                #endregion

                result.Total = q.Count();
                result.Rows = depositOrPaymentRecordResponses;
                result.Success = true;
            }
            catch (Exception ex)
            {
                result.ErrorMessage = ex.Message;
            }
            return result;
        }

        /// <summary>
        /// 重置状态
        /// </summary>
        /// <param name="orderNo">订单号</param>
        /// <returns></returns>
        public bool ResetNoticeStatus(long orderNo)
        {
            //通过订单号重新初始化上下文
            var month = GetOrderMonth(orderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }

            var depositRecord = _context.DepositRecord.FirstOrDefault(p => p.OrderNo == orderNo);
            if (depositRecord == null)
            {
                throw new Exception("收款记录不存在！");
            }

            if (depositRecord.NoticeStatus != PaymentRecordNoticeStatus.通知失败.GetHashCode())
            {
                throw new Exception("收款订单通知状态已发生变化，无法重置");
            }

            if (depositRecord.NoticeTimes == 5)
            {
                depositRecord.NoticeTimes = 1;
                _context.SaveChanges();
            }
            else
            {
                throw new Exception("收款订单通知次数有误");
            }
            return true;
        }

        /// <summary>
        /// 补推送
        /// </summary>
        /// <param name="orderNo">订单号</param>
        /// <returns></returns>
        public bool AddPush(long orderNo)
        {
            //通过订单号重新初始化上下文
            var month = GetOrderMonth(orderNo);
            if (month != DateTime.Now.ToString("MM"))
            {
                _context.ReloadModelCreating(month);
            }

            var depositRecord = _context.DepositRecord.FirstOrDefault(p => p.OrderNo == orderNo);
            if (depositRecord == null)
            {
                throw new Exception("收款记录不存在！");
            }
            depositRecord.NoticeTimes = 1;
            depositRecord.NoticeStatus = (int)DepositRecordNoticeStatus.通知失败;
            _context.SaveChanges();

            return true;
        }

        //获取交易类型的值
        private string GetTransType(int configValue)
        {
            var q = _context.SysConfig.Where(e => e.CompanyId == (int)ReceiptTrans.TranCompanyId
            && e.ConfigValue == configValue
            && e.ConfigCode == "Transtype").FirstOrDefault();//把Transtype移到Enum下
            if (q != null)
            {
                return q.ConfigContent;
            }
            return string.Empty;
        }
    }
}
