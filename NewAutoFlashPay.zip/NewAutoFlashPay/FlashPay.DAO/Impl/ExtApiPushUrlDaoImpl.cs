﻿using System;
using System.Collections.Generic;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;
    using FlashPay.EF;
    using FlashPay.EF.Models;
    using FlashPay.Entity.Enum;
    using FlashPay.Entity.Parameter;
    using FlashPay.Entity.Request.ExtApi;
    using System.Linq;
    using System.Linq.Expressions;

    /// <summary>
    /// 推送数据接口实现
    /// </summary>
    public class ExtApiPushUrlDaoImpl : ExtApiPushUrlDao
    {
        #region 注入
        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public ExtApiPushUrlDaoImpl(FlashPayContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 获取
        /// </summary>
        /// <param name="id">编号</param>
        public ExtApiPushUrl Get(int id)
        {
            return _context.ExtApiPushUrl.Where(x => x.Id == id).FirstOrDefault();
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(ExtApiPushUrl model, FlashPayContext flashPayContext = null)
        {
            var _flashPayContext = (flashPayContext ?? _context);

            _flashPayContext.ExtApiPushUrl.Add(model);
            //调用数据上下文的保存方法，将对象存数数据库
            var resultId = _flashPayContext.SaveChanges();

            return resultId;
        }

        /// <summary>
        /// 更新授权
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        public bool Update(ExtApiPushUrl model, FlashPayContext flashPayContext = null)
        {

            try
            {
                var _flashPayContext = (flashPayContext ?? _context);

                var extApiPushUrl = _flashPayContext.ExtApiPushUrl.Find(model.Id);
                extApiPushUrl.Type = model.Type;
                extApiPushUrl.SortNo = model.SortNo;
                extApiPushUrl.Status = model.Status;
                extApiPushUrl.Url = model.Url;
                extApiPushUrl.Description = model.Description;

                _flashPayContext.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public List<ExtApiPushUrl> GetList(ExtApiPushUrlQuery query)
        {
            //多条件查询
            var where = PredicateBuilder.True<ExtApiPushUrl>();

            if (query.Id.HasValue)
            {
                where = where.And(c => c.Id == query.Id.Value);
            }

            if (query.NotEqualId.HasValue)
            {
                where = where.And(c => c.Id != query.NotEqualId.Value);
            }

            if (query.Type.HasValue)
            {
                where = where.And(c => c.Type == query.Type.Value);
            }

            if (query.CompanyId.HasValue)
            {
                where = where.And(c => c.CompanyId == query.CompanyId.Value);
            }

            var list = _context.ExtApiPushUrl.Where(where.Compile()).OrderBy(e=>e.SortNo).ToList();

            return list;
        }


        /// <summary>
        /// 删除授权
        /// </summary>
        /// <param name="CardMerchant">修改对象</param>
        /// <returns></returns>
        public int ExtApiPushUrlDel(ExtApiPushUrlAddOrEditRequest model)
        {
            try
            {
                var extApiPushUrl = _context.ExtApiPushUrl.Find(model.Id);
                _context.ExtApiPushUrl.Remove(extApiPushUrl);
                return _context.SaveChanges();
            }
            catch (Exception ex)
            {
                return -1;
            }
        }

    }
}
