﻿using FlashPay.DAO.Interface;
using FlashPay.EF;
using FlashPay.EF.Models;
using FlashPay.Entity;
using FlashPay.Entity.Parameter;
using FlashPay.Entity.Request.Company;
using FlashPay.Entity.Request.DepositMatchRecord;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace FlashPay.DAO.Impl
{
    public class DepositMatchRecordDAOImpl : DepositMatchRecordDAO, IDisposable
    {
        #region 注入
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public DepositMatchRecordDAOImpl(FlashPayContext context)
        {
            _context = context;
        }
        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 获取收款匹配记录列表
        /// </summary>
        public DataGrid<DepositMatchRecordResponse> GetDepositMatchRecordList(DepositMatchRecordQuery query)
        {
            var pList = new DataGrid<DepositMatchRecordResponse>()
            {
                Success = false
            };

            try
            {
                var q = from c in _context.DepositMatchRecord select c;

                var companys = _context.Company.ToList();

                #region 搜索条件
                //当前登录人所属公司及子公司
                if (query.CompanyIds != null)
                {
                    q = q.Where(c => query.CompanyIds.Contains(c.CompanyId));
                }
                //公司名称
                if (!string.IsNullOrEmpty(query.CompanyName))
                {
                    var companySearch = companys.Where(p => p.CompanyName.Contains(query.CompanyName)).ToList();
                    q = q.Where(c => companySearch.Select(p => p.CompanyId).Contains(c.CompanyId));
                }

                //订单号
                if (query.OrderNo != null)
                {
                    q = q.Where(c => c.MatchOrderNo == query.OrderNo);
                }
                //银行名称
                if (!string.IsNullOrEmpty(query.ClientBankName))
                {
                    q = q.Where(c => c.ClientBankName.Contains(query.ClientBankName));
                }
                //用户名
                if (!string.IsNullOrEmpty(query.ClientAccountName))
                {
                    q = q.Where(c => c.ClientAccountName.Contains(query.ClientAccountName));
                }

                //订单时间
                if (!string.IsNullOrEmpty(query.StartTime) && !string.IsNullOrEmpty(query.EndTime))
                {
                    q = q.Where(c => c.DepositDate >= Convert.ToDateTime(query.StartTime) && c.DepositDate <= Convert.ToDateTime(query.EndTime));
                }
                #endregion

                var list = q.OrderByDescending(r => r.Id).Skip((query.Page.Value - 1) * query.Rows.Value).Take(query.Rows.Value).ToList();

                #region 模型转换
                var dResponseList = new List<DepositMatchRecordResponse>();

                list.ForEach(item =>
                {
                    var dResponse = new DepositMatchRecordResponse();

                    #region 公司
                    var companyName = "";
                    if (companys != null && companys.Any())
                    {
                        var company = companys.FirstOrDefault(p => p.CompanyId == item.CompanyId);
                        if (company != null)
                        {
                            companyName = company.CompanyName;
                        }
                    }
                    #endregion

                    dResponse.Id = item.Id.ToString();
                    dResponse.CompanyId = item.CompanyId;
                    dResponse.CompanyName = companyName;
                    dResponse.BankCode = item.BankCode;
                    dResponse.MatchOrderNo = string.IsNullOrEmpty(item.MatchOrderNo.ToString()) ? null : item.MatchOrderNo.ToString();
                    dResponse.ClientOrderNo = item.ClientOrderNo;
                    dResponse.DepositDate = item.DepositDate;
                    dResponse.DepositAmount = item.DepositAmount;
                    dResponse.ClientBankName = item.ClientBankName;
                    dResponse.ClientAccountName = item.ClientAccountName;
                    dResponse.ClientCardNumber = item.ClientCardNumber;
                    dResponse.PostScript = item.PostScript;
                    dResponse.DepositRemark = item.DepositRemark;

                    if (item.DepositDate != null)
                    {
                        var ts = DateTime.Now.Subtract(item.DepositDate).TotalMinutes;
                        if (ts > 20)
                        {
                            dResponse.IsShowSearch = true;//显示查询按钮
                        }
                        if (ts > 20 && ts <= 2880)
                        {
                            dResponse.IsShowAddPush = true;//显示补推送按钮
                        }
                    }

                    if (item.MatchOrderNo != null && dResponse.IsShowAddPush)
                    {
                        var deposit = _context.DepositRecord.Where(e=>e.OrderNo.ToString().Equals(dResponse.MatchOrderNo)).FirstOrDefault();
                        if (deposit != null)
                        {
                            if (deposit.NoticeStatus == 3 && deposit.NoticeTimes == 1)
                            {
                                dResponse.IsShowAddPush = false;//不显示补推送按钮
                            }
                        }
                    }

                    var userPermission = query.UserPermission.Where(e => e.Contains("ReceiptMatchList00")).ToList();
                    if (userPermission != null && userPermission.Count > 0)
                    {
                        if (userPermission.Where(e => e.Equals(AuthCode.ReceiptMatchList005.ToString())).FirstOrDefault() != null)
                        {
                            dResponse.StatusCode = "100";//是否有查询匹配记录的权限
                        }
                        if (userPermission.Where(e => e.Equals(AuthCode.ReceiptMatchList006.ToString())).FirstOrDefault() != null)
                        {
                            dResponse.ErrorCode = "100";//是否有补推送的权限
                        }
                    }

                    dResponseList.Add(dResponse);
                });

                pList.Success = true;

                pList.Total = q.Count();
                pList.Rows = dResponseList;
                return pList;

                #endregion
            }
            catch (Exception)
            {
                pList.ErrorMessage = "收款匹配记录发生异常";
                return pList;
            }
        }

        /// <summary>
        /// 根据ID查询详细信息
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public DepositMatchRecord GetMatchRecordDetail(DepositMatchRecordQuery query)
        {
            return _context.DepositMatchRecord.Where(e => e.Id.Equals(query.ID)).FirstOrDefault();
        }

        /// <summary>
        /// 设置匹配
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public int SetMatchRule(DepositMatchRecordQuery query) {
            int rows = 0;
            try
            {
                var sql = $"call sp_UpdateMatchDepositRecord('{query.OrderNo}','{query.ID}');";

                var connection = _context.Database.GetDbConnection();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    command.CommandType = CommandType.Text;
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    using (var updateResult = command.ExecuteReader())
                    {
                        if (updateResult.Read())
                        {
                            rows= updateResult.GetInt32(0);
                        }
                    }
                }
                return rows;
            }
            catch (Exception ex)
            {
                throw new Exception("匹配出错");
            }
        }
    }
}
