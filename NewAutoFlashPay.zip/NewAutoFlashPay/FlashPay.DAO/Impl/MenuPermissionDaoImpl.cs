﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.DAO.Impl
{
    using FlashPay.DAO.Interface;
    using FlashPay.EF;

    using FlashPay.EF.Models;
    using FlashPay.EF.View;
    using FlashPay.Entity;
    using FlashPay.Entity.Parameter;
    using FlashPay.Util;
    using System.Linq;
    using System.Linq.Expressions;

    /// <summary>
    /// 菜单功能权限数据接口实现
    /// </summary>
    /// <remarks>2018-07-09 immi 创建</remarks>
    public class MenuPermissionDaoImpl : MenuPermissionDao
    {
        #region 注入

        /// <summary>
        /// EF上下文
        /// </summary>
        private FlashPayContext _context { set; get; }

        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="context"></param>
        public MenuPermissionDaoImpl(FlashPayContext context)
        {
            _context = context;
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }
        #endregion

        /// <summary>
        /// 根据编号获取菜单
        /// </summary>
        /// <param name="id">编号</param>
        /// <returns>菜单</returns>
        public MenuPermission Get(int id)
        {
            return _context.MenuPermission.Where(x => x.MpId == id).FirstOrDefault();
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="userInfo">新增对象</param>
        /// <returns></returns>
        public int Add(MenuPermission model)
        {
            _context.MenuPermission.Add(model);
            _context.SaveChanges();
            return model.MpId;
        }

        /// <summary>
        /// 删除菜单权限
        /// </summary>
        /// <param name="menuId">菜单编号</param>
        /// <returns></returns>
        public bool DeleteByMenuSysNo(int menuId)
        {
            var result = false;

            var menuList = _context.MenuPermission.Where(p => p.MpMid.Equals(menuId)).ToList();
            if (menuList.Count<=0)
            {
                result = true;
            }
            else {
                menuList.ForEach(item => {
                    _context.MenuPermission.Remove(item);
                    if (_context.SaveChanges() > 0)
                    {
                        result = true;
                    }
                });
            }
            return result;
        }

        /// <summary>
        /// 权限菜单编号获取菜单权限列表
        /// </summary>
        /// <param name="menuSysNo">菜单编号</param>
        /// <returns>列表</returns>
        public List<Permission> GetByMenuSysNo(int menuId)
        {
           
           List<int> ids = _context.MenuPermission.Where(p => p.MpMid.Equals(menuId)).Select(p => p.MpPid).ToList();
           return _context.Permission.Where(p=> ids.Contains(p.Pid)).OrderBy(p=>p.SortNo).ToList();
        }

        /// <summary>
        /// 获取菜单权限列表
        /// </summary>
        /// <returns>列表</returns>
        public List<PermissionExt> GetMenuPermissionViewList()
        {
            var q = from mp in _context.MenuPermission
                    join p in _context.Permission on mp.MpPid equals p.Pid
                    select new {
                        mp.MpId,
                        mp.MpMid,
                        p.Pid,
                        p.PParent,
                        p.PName,
                        p.PCode,
                        p.NodeType,
                        p.SortNo,
                        p.Hide
                    };

            var permissionExtList = new List<PermissionExt>();
            q.ToList().ForEach(item => {
                permissionExtList.Add(new PermissionExt() {
                    MpId = item.MpId,
                    MpMid = item.MpMid,
                    Pid = item.Pid,
                    PParent = item.PParent,
                    PName = item.PName,
                    PCode = item.PCode,
                    NodeType = item.NodeType,
                    SortNo = item.SortNo,
                    Hide = item.Hide,
                });
            });

            return permissionExtList;
        }

        /// <summary>
        /// 获取所有用户记录
        /// </summary>
        /// <param name="request">查询条件</param>
        /// <returns>List<UserInfo></returns>
        public List<MenuPermission> GetList(MenuPermissionQuery request)
        {
            //多条件查询
            var where = PredicateBuilder.True<MenuPermission>();


            var list = _context.MenuPermission.Where(where.Compile()).ToList();

            return list;
        }

        /// <summary>
        /// 菜单功能权限分页列表
        /// </summary>
        /// <param name="query">查询条件</param>
        /// <returns></returns>
        public PagedList<Permission> GetMenuPermissionPager(MenuPermissionQuery query)
        {
            var lists = (from p in _context.Permission where !(from mp in _context.MenuPermission select mp.MpPid).Contains(p.Pid) select p).ToList(); 

            var row = lists.Where(p=>p.NodeType == query.NodeType && p.Hide ==1 && (string.IsNullOrEmpty(query.pName) || p.PName.Contains(query.pName))).Skip((query.CurrentPageIndex.Value - 1) * query.PageSize.Value).Take(query.PageSize.Value).ToList();
            var count = lists.Where(p => p.NodeType == query.NodeType && p.Hide == 1 && (string.IsNullOrEmpty(query.pName) || p.PName.Contains(query.pName))).Count();

            var list = new PagedList<Permission>
            {
                TData = row,
                CurrentPageIndex = query.CurrentPageIndex.Value,
                TotalCount = count
            };

            return list;
        }
    }
}
