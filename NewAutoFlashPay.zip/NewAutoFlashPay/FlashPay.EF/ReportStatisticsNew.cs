﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.EF
{
    public class ReportStatisticsNew
    {
        public int CompanyId { get; set; }
        public sbyte ReportType { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal TotalQuantity { get; set; }
        public int Year { get; set; }
    }
}
