﻿using System;
using FlashPay.EF.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace FlashPay.EF
{
    public partial class FlashPayContext : DbContext
    {
        private static ModelBuilder _modelBuilder;

        /// <summary>
        /// 月份 ex： 01，针对分月份表使用
        /// </summary>
        private string _Month = DateTime.Now.ToString("MM");

        private string _Year = DateTime.Now.ToString("yyyy");

        /// <summary>
        /// 预设日期时间 ex：1970-01-01 00:00:00
        /// </summary>
        private string _DateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

        public FlashPayContext()
        {
        }

        public FlashPayContext(DbContextOptions<FlashPayContext> options)
            : base(options)
        {
        }

        /// <summary>
        /// 传入月份 ex：01，针对分月份表使用
        /// </summary>
        /// <param name="Month"></param>
        //public FlashPayContext(string Month)
        //{
        //    if (string.IsNullOrEmpty(Month) || string.IsNullOrWhiteSpace(Month))
        //        Month = DateTime.Now.ToString("MM");
        //    _Month = Month;
        //}

        /// <summary>
        /// 重新建立Model,传入月份，与年份
        /// </summary>
        /// <param name="Month">ex：01，针对分月份表使用</param>
        /// <param name="Year">ex：2018，针对分年份表使用</param>
        public void ReloadModelCreating(string Month = "", string Year = "")
        {
            if (string.IsNullOrEmpty(Month) || string.IsNullOrWhiteSpace(Month))
                Month = DateTime.Now.ToString("MM");
            if (string.IsNullOrEmpty(Year) || string.IsNullOrWhiteSpace(Year))
                Year = DateTime.Now.ToString("yyyy");

            _Month = Month;
            _Year = Year;
            OnModelCreating(_modelBuilder);
        }

        public virtual DbSet<AdjustBalance> AdjustBalance { get; set; }
        public virtual DbSet<Authorize> Authorize { get; set; }
        public virtual DbSet<BankCard> BankCard { get; set; }
        public virtual DbSet<BankCardExtraLimit> BankCardExtraLimit { get; set; }
        public virtual DbSet<BankCardTypeRecord> BankCardTypeRecord { get; set; }
        public virtual DbSet<BankInfo> BankInfo { get; set; }
        public virtual DbSet<CardMerchant> CardMerchant { get; set; }
        public virtual DbSet<Company> Company { get; set; }
        public virtual DbSet<DepositRecord> DepositRecord { get; set; }
        public virtual DbSet<DepositMatchRecord> DepositMatchRecord { get; set; }
        public virtual DbSet<DepositMatchRule> DepositMatchRule { get; set; }
        public virtual DbSet<ExtApiCompat> ExtApiCompat { get; set; }
        public virtual DbSet<ExtApiPushUrl> ExtApiPushUrl { get; set; }
        public virtual DbSet<LogRecord> LogRecord { get; set; }
        public virtual DbSet<Menu> Menu { get; set; }
        public virtual DbSet<MenuPermission> MenuPermission { get; set; }
        public virtual DbSet<OrderRecord> OrderRecord { get; set; }
        public virtual DbSet<OrderRecordDetail> OrderRecordDetail { get; set; }
        public virtual DbSet<PaymentInterface> PaymentInterface { get; set; }
        public virtual DbSet<PaymentRecord> PaymentRecord { get; set; }
        public virtual DbSet<Permission> Permission { get; set; }
        public virtual DbSet<RecordReal> RecordReal { get; set; }
        public virtual DbSet<ReportStatistics> ReportStatistics { get; set; }
        public virtual DbSet<SysConfig> SysConfig { get; set; }
        public virtual DbSet<SysRole> SysRole { get; set; }
        public virtual DbSet<TransportCard> TransportCard { get; set; }
        public virtual DbSet<TransportRecord> TransportRecord { get; set; }
        public virtual DbSet<UserInfo> UserInfo { get; set; }
        public virtual DbSet<UserRole> UserRole { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql(Base.Mydb);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AdjustBalance>(entity =>
            {
                entity.HasKey(e => e.Rid);

                entity.ToTable("AdjustBalance_" + _Month);

                entity.HasIndex(e => e.CardBcid)
                    .HasName("CardBCID");

                entity.HasIndex(e => e.CreateDate)
                    .HasName("CreateDate");

                entity.HasIndex(e => e.CreateDbdate)
                    .HasName("CreateDBDate");

                entity.Property(e => e.Rid)
                    .HasColumnName("RID")
                    .HasColumnType("bigint(20)");

                entity.Property(e => e.AdjustStatus).HasColumnType("tinyint(4)");

                entity.Property(e => e.AfterBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.Amount).HasColumnType("decimal(16,4)");

                entity.Property(e => e.BeforeBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.CardBcid)
                    .HasColumnName("CardBCID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(30)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateDbdate)
                    .HasColumnName("CreateDBDate")
                    .HasDefaultValueSql("'current_timestamp(6)'");

                entity.Property(e => e.CreateName).HasColumnType("varchar(128)");

                entity.Property(e => e.CreateRemark).HasColumnType("text");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)");
            });

            modelBuilder.Entity<Authorize>(entity =>
            {
                entity.HasKey(e => e.AuthId);

                entity.HasIndex(e => e.AuthRid)
                    .HasName("ix_authRid");

                entity.Property(e => e.AuthId)
                    .HasColumnName("authId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.AuthPid)
                    .HasColumnName("authPid")
                    .HasColumnType("int(11)");

                entity.Property(e => e.AuthRid)
                    .HasColumnName("authRid")
                    .HasColumnType("int(11)");

                entity.Property(e => e.AuthType)
                    .HasColumnName("authType")
                    .HasColumnType("tinyint(4)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.HasOne(d => d.AuthR)
                    .WithMany(p => p.Authorize)
                    .HasForeignKey(d => d.AuthRid)
                    .HasConstraintName("FK_Authorize_authRid");
            });

            modelBuilder.Entity<BankCard>(entity =>
            {
                entity.HasKey(e => e.Bcid);

                entity.HasIndex(e => e.CardNumber)
                    .HasName("ix_CardNumber")
                    .IsUnique();

                entity.HasIndex(e => e.CompanyId)
                    .HasName("ix_CompanyID");

                entity.Property(e => e.Bcid)
                    .HasColumnName("BCID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.AccountBank)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.Balance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.BankCode)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.BankName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CardName)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.CardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(100)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.CardType)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'4'");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CrossBankPay)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'3'");

                entity.Property(e => e.DepositType)
                    .IsRequired()
                    .HasDefaultValueSql("''");

                entity.Property(e => e.DepositFeeRatio)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.DocumentNumber)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.EnableStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'4'");

                entity.Property(e => e.IpAddress).HasColumnType("varchar(50)");

                entity.Property(e => e.LoginName)
                    .IsRequired()
                    .HasColumnType("varchar(128)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.OrderNo)
                    .HasColumnType("bigint(20)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.OriginalPassword)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.PasswordLogin)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.PasswordPay).HasColumnType("varchar(50)");

                entity.Property(e => e.PasswordQuery).HasColumnType("varchar(50)");

                entity.Property(e => e.PasswordShield).HasColumnType("varchar(50)");

                entity.Property(e => e.PayFeeRatio)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.PaymentEnd)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.PaymentStart)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.PaymentType)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.PhoneNumber)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.Remark).HasColumnType("text");

                entity.Property(e => e.SecCardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(100)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.TransportRate)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.UpdateDate).HasColumnType("datetime");

                entity.Property(e => e.UsbType)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.UsingStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");
            });

            modelBuilder.Entity<BankCardExtraLimit>(entity =>
            {
                entity.HasKey(e => e.CardNumber);

                entity.Property(e => e.CardNumber).HasColumnType("varchar(100)");

                entity.Property(e => e.LimitChangetoDeposit)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");

                entity.Property(e => e.LimitChangetoPay)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");

                entity.Property(e => e.LimitCloseDate).HasColumnType("datetime");

                entity.Property(e => e.LimitDepositAmount).HasColumnType("decimal(16,4)");

                entity.Property(e => e.LimitOpenDate).HasColumnType("datetime");

                entity.Property(e => e.LimitPayAmount).HasColumnType("decimal(16,4)");

                entity.Property(e => e.LimitRepeat)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");

                entity.Property(e => e.LimitStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");
            });

            modelBuilder.Entity<BankCardTypeRecord>(entity =>
            {
                entity.HasIndex(e => e.CardNumber)
                    .HasName("ix_CardNumber");

                entity.HasIndex(e => e.RecordType)
                    .HasName("ix_RecordType");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.AfterCardType).HasColumnType("tinyint(4)");

                entity.Property(e => e.BeforeCardType).HasColumnType("tinyint(4)");

                entity.Property(e => e.CardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.CreateDbdate)
                    .HasColumnName("CreateDBDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("'current_timestamp()'");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.RecordType)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");
            });

            modelBuilder.Entity<BankInfo>(entity =>
            {
                entity.HasKey(e => e.BankCode);

                entity.Property(e => e.BankCode).HasColumnType("varchar(50)");

                entity.Property(e => e.BankAddress).HasColumnType("varchar(150)");

                entity.Property(e => e.BankEnglishName).HasColumnType("varchar(50)");

                entity.Property(e => e.BankFullName).HasColumnType("varchar(50)");

                entity.Property(e => e.BankName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.BankRemark).HasColumnType("text");

                entity.Property(e => e.BankTel).HasColumnType("varchar(50)");

                entity.Property(e => e.BankUrl).HasColumnType("varchar(500)");

                entity.Property(e => e.SortNo).HasColumnType("int(11)");
            });

            modelBuilder.Entity<CardMerchant>(entity =>
            {
                entity.HasKey(e => e.Cmid);

                entity.Property(e => e.Cmid)
                    .HasColumnName("CMID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Cmcredit)
                    .IsRequired()
                    .HasColumnName("CMCredit")
                    .HasMaxLength(1)
                    .HasDefaultValueSql("'A'");

                entity.Property(e => e.CardCommissionerUid)
                    .HasColumnName("CardCommissionerUID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Cmcode)
                    .IsRequired()
                    .HasColumnName("CMCode")
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.Cmname)
                    .IsRequired()
                    .HasColumnName("CMName")
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.DelayRate)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Remark)
                    .IsRequired()
                    .HasColumnType("varchar(200)")
                    .HasDefaultValueSql("''");
            });

            modelBuilder.Entity<Company>(entity =>
            {
                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompanyAddress).HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyBossName).HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyNameEn)
                    .HasColumnName("CompanyNameEN")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyPid)
                    .HasColumnName("CompanyPID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompanyStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.CompanyTel).HasColumnType("varchar(50)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.DepositRate)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.TransportRate)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.PayRate)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.UpdateDate).HasColumnType("datetime");

                entity.Property(e => e.UpdateUid)
                    .HasColumnName("UpdateUID")
                    .HasColumnType("int(11)");
            });

            modelBuilder.Entity<DepositMatchRecord>(entity =>
            {
                entity.ToTable("DepositMatchRecord_" + _Month);

                entity.HasIndex(e => e.DepositDate)
                    .HasName("ix_DepositDate");

                entity.HasIndex(e => e.MatchOrderNo)
                    .HasName("ix_MatchOrderNo")
                    .IsUnique();

                entity.HasIndex(e => new { e.CompanyId, e.ClientOrderNo })
                    .HasName("ix_CompanyID_ClientOrderNo")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("bigint(20)");

                entity.Property(e => e.BankCode)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.ClientAccountName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.ClientBankName)
                    .IsRequired()
                    .HasColumnType("varchar(150)");

                entity.Property(e => e.ClientCardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.ClientOrderNo)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDbdate)
                    .HasColumnName("CreateDBDate")
                    .HasDefaultValueSql("'current_timestamp(6)'");

                entity.Property(e => e.DepositAmount).HasColumnType("decimal(16,4) unsigned");

                entity.Property(e => e.DepositDate).HasColumnType("datetime");

                entity.Property(e => e.DepositRemark).HasColumnType("text");

                entity.Property(e => e.MatchOrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.PostScript).HasColumnType("varchar(1024)");

                entity.Property(e => e.UpdateDate).HasColumnType("datetime");

                entity.Property(e => e.UpdateId)
                    .HasColumnName("UpdateID")
                    .HasColumnType("int(11)");
            });

            modelBuilder.Entity<DepositMatchRule>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("'current_timestamp()'");

                entity.Property(e => e.CreateId)
                    .HasColumnName("CreateID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.MatchBankCode).HasColumnType("varchar(500)");

                entity.Property(e => e.MatchRule)
                      .IsRequired()
                      .HasDefaultValueSql("'1,2'");

                entity.Property(e => e.MatchMinute)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'30'");

                entity.Property(e => e.MatchRemark)
                    .IsRequired()
                    .HasColumnType("text");
            });

            modelBuilder.Entity<DepositRecord>(entity =>
            {
                entity.HasKey(e => e.OrderNo);

                entity.ToTable("DepositRecord_" + _Month);

                entity.HasIndex(e => e.CompanyId)
                    .HasName("ix_CompanyID");

                entity.HasIndex(e => e.CreateDate)
                    .HasName("ix_CreateDate");

                entity.HasIndex(e => e.DepositCardId)
                    .HasName("ix_DepositCardID");

                entity.HasIndex(e => e.DepositDate)
                    .HasName("ix_DepositDate");

                entity.HasIndex(e => e.DepositNo)
                    .HasName("ix_DepositNo")
                    .IsUnique();

                entity.Property(e => e.OrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.AfterBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.BankSerialNo).HasColumnType("varchar(50)");

                entity.Property(e => e.BeforeBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.CardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(30)");

                entity.Property(e => e.ClientAccountName).HasColumnType("varchar(50)");

                entity.Property(e => e.ClientBankName).HasColumnType("varchar(150)");

                entity.Property(e => e.ClientCardNumber).HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateDbdate)
                    .HasColumnName("CreateDBDate")
                    .HasDefaultValueSql("'current_timestamp(6)'");

                entity.Property(e => e.DepositAmount).HasColumnType("decimal(16,4) unsigned");

                entity.Property(e => e.DepositCardId)
                    .HasColumnName("DepositCardID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.DepositDate).HasColumnType("datetime");

                entity.Property(e => e.DepositMatchID).HasColumnType("bigint(20)");

                entity.Property(e => e.DepositNo)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.DepositRemark).HasColumnType("text");

                entity.Property(e => e.FeeRatio).HasColumnType("decimal(12,8)");

                entity.Property(e => e.FeeTotal).HasColumnType("decimal(16,4)");

                entity.Property(e => e.NoticeLastTime).HasColumnType("datetime");

                entity.Property(e => e.NoticeStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.NoticeTimes)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.PostScript).HasColumnType("varchar(1024)");

                entity.Property(e => e.Transtype).HasColumnType("int(11)");
            });

            modelBuilder.Entity<ExtApiCompat>(entity =>
            {
                entity.HasIndex(e => e.ApiKey)
                    .HasName("ix_ApiKey");

                entity.HasIndex(e => new { e.CompanyId, e.Type })
                    .HasName("ix_CompanyId_Type")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.ApiKey)
                    .IsRequired()
                    .HasColumnType("char(32)");

                entity.Property(e => e.CompanyId)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.SecretKey)
                    .IsRequired()
                    .HasColumnType("char(64)");

                entity.Property(e => e.Status)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Type)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");
            });

            modelBuilder.Entity<ExtApiPushUrl>(entity =>
            {
                entity.HasIndex(e => e.Url)
                    .HasName("ix_Url");

                entity.HasIndex(e => new { e.CompanyId, e.Type, e.SortNo })
                    .HasName("ix_CompanyId_Type_SortNo")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.CompanyId)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Description).HasColumnType("varchar(128)");

                entity.Property(e => e.SortNo).HasColumnType("tinyint(4)");

                entity.Property(e => e.Status)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Type)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Url)
                    .IsRequired()
                    .HasColumnType("varchar(256)");
            });

            modelBuilder.Entity<LogRecord>(entity =>
            {
                entity.HasKey(e => e.LogId);

                entity.HasIndex(e => e.CompanyId)
                    .HasName("ix_CompanyID");

                entity.HasIndex(e => e.CreateDate)
                    .HasName("ix_CreateDate");

                entity.Property(e => e.LogId)
                    .HasColumnName("LogID")
                    .HasColumnType("bigint(20)");

                entity.Property(e => e.AffectData).HasColumnType("longtext");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Ip)
                    .HasColumnName("IP")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.LogLevel).HasColumnType("tinyint(4)");

                entity.Property(e => e.LogRemark).HasColumnType("text");

                entity.Property(e => e.LogType).HasColumnType("int(11)");

                entity.Property(e => e.RequestData).HasColumnType("text");

                entity.Property(e => e.RequestUrl)
                    .IsRequired()
                    .HasColumnType("text");
            });

            modelBuilder.Entity<Menu>(entity =>
            {
                entity.HasKey(e => e.Mid);

                entity.Property(e => e.Mid)
                    .HasColumnName("mid")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Hide)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.MName)
                    .IsRequired()
                    .HasColumnName("mName")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.MParent)
                    .HasColumnName("mParent")
                    .HasColumnType("int(11)");

                entity.Property(e => e.MType)
                    .HasColumnName("mType")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.MUrl)
                    .HasColumnName("mUrl")
                    .HasColumnType("text");

                entity.Property(e => e.NodeType).HasColumnType("int(11)");

                entity.Property(e => e.SortNo)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'1'");
            });

            modelBuilder.Entity<MenuPermission>(entity =>
            {
                entity.HasKey(e => e.MpId);

                entity.Property(e => e.MpId)
                    .HasColumnName("mpId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.MpMid)
                    .HasColumnName("mpMid")
                    .HasColumnType("int(11)");

                entity.Property(e => e.MpPid)
                    .HasColumnName("mpPid")
                    .HasColumnType("int(11)");
            });

            modelBuilder.Entity<OrderRecord>(entity =>
            {
                entity.HasKey(e => e.OrderNo);

                entity.HasIndex(e => e.CreateDate)
                    .HasName("ix_CreateDate");

                entity.HasIndex(e => e.OrderDate)
                    .HasName("ix_OrderDate");

                entity.HasIndex(e => e.PayDate)
                    .HasName("ix_PayDate");

                entity.Property(e => e.OrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.Cmid)
                    .HasColumnName("CMID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.DeliveryNo).HasColumnType("varchar(100)");

                entity.Property(e => e.DepositAmount)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.DepositCardNumber).HasColumnType("varchar(30)");

                entity.Property(e => e.DepositDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql(_DateTime);

                entity.Property(e => e.DepositUid)
                    .HasColumnName("DepositUID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.OrderDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql(_DateTime);

                entity.Property(e => e.PayAmount)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.PayCardNumber).HasColumnType("varchar(30)");

                entity.Property(e => e.PayDate).HasColumnType("datetime");

                entity.Property(e => e.PayUid)
                    .HasColumnName("PayUID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ReceiptDate).HasColumnType("datetime");

                entity.Property(e => e.ReceiptUid)
                    .HasColumnName("ReceiptUID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");
            });

            modelBuilder.Entity<OrderRecordDetail>(entity =>
            {
                entity.HasKey(e => e.DetailId);

                entity.HasIndex(e => e.OrderNo)
                    .HasName("ix_OrderNo");

                entity.Property(e => e.DetailId)
                    .HasColumnName("DetailID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.ActualQuantity).HasColumnType("int(11)");

                entity.Property(e => e.ActualUnitPrice).HasColumnType("decimal(16,4)");

                entity.Property(e => e.BankCode)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.OrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.OrderQuantity).HasColumnType("int(11)");

                entity.Property(e => e.Remark)
                    .IsRequired()
                    .HasColumnType("varchar(200)");

                entity.Property(e => e.UnitPrice).HasColumnType("decimal(16,4)");

                entity.HasOne(d => d.OrderNoNavigation)
                    .WithMany(p => p.OrderRecordDetail)
                    .HasForeignKey(d => d.OrderNo)
                    .HasConstraintName("OrderRecordDetail_ibfk_1");
            });

            modelBuilder.Entity<PaymentInterface>(entity =>
            {
                entity.HasKey(e => new { e.CompanyID, e.PaymentType });

                entity.Property(e => e.CompanyID)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompanyName).HasColumnType("varchar(50)");

                entity.Property(e => e.DepositType)
                    .IsRequired()
                    .HasDefaultValueSql("''");

                entity.Property(e => e.LimitCloseDate).HasColumnType("datetime");

                entity.Property(e => e.LimitOpenDate).HasColumnType("datetime");

                entity.Property(e => e.LimitRepeat)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");

                entity.Property(e => e.LimitStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");

                entity.Property(e => e.PaymentEnd)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.PaymentMax)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.PaymentStart)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.PaymentType).HasColumnType("tinyint(4)");

                entity.Property(e => e.SecretKey).HasColumnType("text");

                entity.Property(e => e.WithdrawalBank).HasColumnType("varchar(500)");
            });

            modelBuilder.Entity<PaymentRecord>(entity =>
            {
                entity.HasKey(e => e.OrderNo);

                entity.ToTable("PaymentRecord_" + _Month);

                entity.HasIndex(e => e.CreateDate)
                    .HasName("ix_CreateDate");

                entity.HasIndex(e => e.PaymentCardId)
                    .HasName("ix_PaymentCardID");

                entity.HasIndex(e => e.PaymentDate)
                    .HasName("ix_PaymentDate");

                entity.HasIndex(e => new { e.CompanyId, e.WithdrawalOrderNo })
                    .HasName("ix_CompanyID_WithdrawalOrderNo")
                    .IsUnique();

                entity.Property(e => e.OrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.AfterBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.BankSerialNo).HasColumnType("varchar(50)");

                entity.Property(e => e.BeforeBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.CardNumber).HasColumnType("varchar(30)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.ConfirmDate).HasColumnType("datetime");

                entity.Property(e => e.ConfirmName).HasColumnType("varchar(128)");

                entity.Property(e => e.ConfirmStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ConfirmUid)
                    .HasColumnName("ConfirmUID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateDbdate)
                    .HasColumnName("CreateDBDate")
                    .HasDefaultValueSql("'current_timestamp(6)'");

                entity.Property(e => e.DepositType).HasColumnType("char(1)");

                entity.Property(e => e.FeeRatio).HasColumnType("decimal(12,8)");

                entity.Property(e => e.FeeTotal).HasColumnType("decimal(16,4)");

                entity.Property(e => e.NoticeLastDate).HasColumnType("datetime");

                entity.Property(e => e.NoticeStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.NoticeTimes)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.PaymentCardId)
                    .HasColumnName("PaymentCardID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.PaymentDate).HasColumnType("datetime");

                entity.Property(e => e.PaymentFailInfo).HasColumnType("text");

                entity.Property(e => e.PaymentRemark).HasColumnType("text");

                entity.Property(e => e.PaymentStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.ReadDate).HasColumnType("datetime");

                entity.Property(e => e.RecordRealOrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.WithdrawalAccountName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.WithdrawalAmount).HasColumnType("decimal(16,4) unsigned");

                entity.Property(e => e.WithdrawalBankAddress).HasColumnType("varchar(1024)");

                entity.Property(e => e.WithdrawalBankName)
                    .IsRequired()
                    .HasColumnType("varchar(150)");

                entity.Property(e => e.WithdrawalCardBankFlag)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.WithdrawalCardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(64)");

                entity.Property(e => e.WithdrawalOrderNo)
                    .IsRequired()
                    .HasColumnType("varchar(128)");
            });

            modelBuilder.Entity<Permission>(entity =>
            {
                entity.HasKey(e => e.Pid);

                entity.Property(e => e.Pid)
                    .HasColumnName("pid")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Hide)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.NodeType).HasColumnType("int(11)");

                entity.Property(e => e.PCode)
                    .HasColumnName("pCode")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.PName)
                    .IsRequired()
                    .HasColumnName("pName")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.PParent)
                    .HasColumnName("pParent")
                    .HasColumnType("int(11)");

                entity.Property(e => e.SortNo)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'1'");
            });

            modelBuilder.Entity<RecordReal>(entity =>
            {
                entity.HasKey(e => e.OrderNo);

                entity.ToTable("RecordReal_" + _Month);

                entity.HasIndex(e => e.CompanyId)
                    .HasName("ix_CompanyID");

                entity.HasIndex(e => e.OperatingDate)
                    .HasName("ix_OperatingDate");

                entity.HasIndex(e => new { e.ClientOrderNo, e.RecordType })
                    .HasName("ix_ClientOrderNo_RecordType")
                    .IsUnique();

                entity.Property(e => e.OrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.AfterBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.Amount).HasColumnType("decimal(16,4)");

                entity.Property(e => e.BankSerialNo).HasColumnType("varchar(50)");

                entity.Property(e => e.CardBcid)
                    .HasColumnName("CardBCID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.ClientAccountName).HasColumnType("varchar(50)");

                entity.Property(e => e.ClientBankName).HasColumnType("varchar(150)");

                entity.Property(e => e.ClientCardNumber).HasColumnType("varchar(50)");

                entity.Property(e => e.ClientOrderNo)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateDbdate)
                    .HasColumnName("CreateDBDate")
                    .HasDefaultValueSql("'current_timestamp(6)'");

                entity.Property(e => e.MatchOrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.OperatingDate).HasColumnType("datetime");

                entity.Property(e => e.RecordType).HasColumnType("tinyint(4)");

                entity.Property(e => e.Remark).HasColumnType("text");

                entity.Property(e => e.VmClientId)
                    .IsRequired()
                    .HasColumnName("VmClientID")
                    .HasColumnType("char(32)");
            });

            modelBuilder.Entity<ReportStatistics>(entity =>
            {
                entity.HasKey(e => new { e.ReportDate, e.CompanyId, e.CardBcid, e.FeeRatio, e.ReportType });

                entity.HasIndex(e => e.CardBcid)
                    .HasName("ix_CardBCID");

                entity.HasIndex(e => e.CompanyId)
                    .HasName("ix_CompanyID");

                entity.Property(e => e.ReportDate).HasColumnType("date");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CardBcid)
                    .HasColumnName("CardBCID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.FeeRatio).HasColumnType("decimal(12,8)");

                entity.Property(e => e.ReportType).HasColumnType("tinyint(4)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.FeeTotal).HasColumnType("decimal(16,4)");

                entity.Property(e => e.ReportAmount).HasColumnType("decimal(16,4)");

                entity.Property(e => e.ReportQuantity).HasColumnType("int(11)");
            });

            modelBuilder.Entity<SysConfig>(entity =>
            {
                entity.HasKey(e => e.ConfigId);

                entity.HasIndex(e => e.CompanyId)
                    .HasName("ix_CompanyID");

                entity.HasIndex(e => new { e.ConfigCode, e.ConfigValue, e.CompanyId })
                    .HasName("ix_ConfigCode_ConfigValue_CompanyID")
                    .IsUnique();

                entity.Property(e => e.ConfigId)
                    .HasColumnName("ConfigID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.ConfigCode)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.ConfigContent).HasColumnType("text");

                entity.Property(e => e.ConfigValue).HasColumnType("int(11)");

                entity.Property(e => e.Description).HasColumnType("text");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.SysConfig)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SysConfig_CompanyID");
            });

            modelBuilder.Entity<SysRole>(entity =>
            {
                entity.HasKey(e => e.RId);

                entity.HasIndex(e => e.RCompanyId)
                    .HasName("rCompanyId");

                entity.Property(e => e.RId)
                    .HasColumnName("rId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateCid)
                    .HasColumnName("CreateCID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.RCompanyId)
                    .HasColumnName("rCompanyId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.RName)
                    .IsRequired()
                    .HasColumnName("rName")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.RStatus)
                    .HasColumnName("rStatus")
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.HasOne(d => d.RCompany)
                    .WithMany(p => p.SysRole)
                    .HasForeignKey(d => d.RCompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("SysRole_ibfk_1");
            });

            modelBuilder.Entity<TransportCard>(entity =>
            {
                entity.HasKey(e => e.Bcid);

                entity.Property(e => e.Bcid)
                    .HasColumnName("BCID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.ApiTransport)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.LimitAmount)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'25.0000'");

                entity.Property(e => e.LimitBalance)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'25.0000'");

                entity.Property(e => e.LimitBankCode).HasColumnType("varchar(50)");

                entity.Property(e => e.LimitMaxAmount)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'50000.0000'");

                entity.Property(e => e.LimitCardType);

                entity.Property(e => e.LimitOrderSideBalance)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'30000.0000'");

                entity.Property(e => e.LimitTransFerAmount)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");
            });

            modelBuilder.Entity<TransportRecord>(entity =>
            {
                entity.HasKey(e => e.OrderNo);

                entity.ToTable("TransportRecord_" + _Year);

                entity.HasIndex(e => e.CreateDate)
                    .HasName("ix_CreateDate");

                entity.HasIndex(e => e.TransportCardId)
                    .HasName("ix_TransportCardID");

                entity.HasIndex(e => e.TransportDate)
                    .HasName("ix_TransportDate");

                entity.HasIndex(e => new { e.CompanyId, e.WithdrawalOrderNo })
                    .HasName("ix_CompanyID_WithdrawalOrderNo")
                    .IsUnique();

                entity.Property(e => e.OrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.AfterBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.BeforeBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.CardNumber).HasColumnType("varchar(30)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.ConfirmDate).HasColumnType("datetime");

                entity.Property(e => e.ConfirmName).HasColumnType("varchar(128)");

                entity.Property(e => e.ConfirmStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ConfirmUid)
                    .HasColumnName("ConfirmUID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDbdate)
                    .HasColumnName("CreateDBDate")
                    .HasDefaultValueSql("'current_timestamp(6)'");

                entity.Property(e => e.FeeRatio).HasColumnType("decimal(12,8)");

                entity.Property(e => e.FeeTotal).HasColumnType("decimal(16,4)");

                entity.Property(e => e.NoticeLastDate).HasColumnType("datetime");

                entity.Property(e => e.NoticeStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.NoticeTimes)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ReadDate).HasColumnType("datetime");

                entity.Property(e => e.TransportCardId)
                    .HasColumnName("TransportCardID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.TransportDate).HasColumnType("datetime");

                entity.Property(e => e.TransportFailInfo).HasColumnType("text");

                entity.Property(e => e.TransportRemark).HasColumnType("text");

                entity.Property(e => e.TransportStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.WithdrawalAccountName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.WithdrawalAmount).HasColumnType("decimal(16,4) unsigned");

                entity.Property(e => e.WithdrawalBankAddress).HasColumnType("varchar(1024)");

                entity.Property(e => e.WithdrawalBankName)
                    .IsRequired()
                    .HasColumnType("varchar(150)");

                entity.Property(e => e.WithdrawalCardBankFlag)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.WithdrawalCardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(64)");

                entity.Property(e => e.WithdrawalOrderNo)
                    .IsRequired()
                    .HasColumnType("varchar(128)");
            });

            modelBuilder.Entity<UserInfo>(entity =>
            {
                entity.HasKey(e => e.UId);

                entity.HasIndex(e => e.UCompanyId)
                    .HasName("uCompanyID");

                entity.HasIndex(e => e.ULoginName)
                    .HasName("uLoginName")
                    .IsUnique();

                entity.Property(e => e.UId)
                    .HasColumnName("uID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.UCompanyId)
                    .HasColumnName("uCompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.UCreateId)
                    .HasColumnName("uCreateID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.UDescription)
                    .HasColumnName("uDescription")
                    .HasColumnType("text");

                entity.Property(e => e.UEmail)
                    .HasColumnName("uEMail")
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.ULoggedIn)
                    .HasColumnName("uLoggedIn")
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");

                entity.Property(e => e.ULoginName)
                    .IsRequired()
                    .HasColumnName("uLoginName")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.UPwd)
                    .IsRequired()
                    .HasColumnName("uPwd")
                    .HasColumnType("char(64)");

                entity.Property(e => e.USecretKey)
                    .HasColumnName("uSecretKey")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.UShowQR)
                    .HasColumnName("uShowQR")
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");

                entity.Property(e => e.UStatus)
                    .HasColumnName("uStatus")
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.UTelephone)
                    .HasColumnName("uTelephone")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.UUiconfig)
                    .HasColumnName("uUIConfig")
                    .HasColumnType("text");

                entity.HasOne(d => d.UCompany)
                    .WithMany(p => p.UserInfo)
                    .HasForeignKey(d => d.UCompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("UserInfo_ibfk_1");
            });

            modelBuilder.Entity<UserRole>(entity =>
            {
                entity.HasKey(e => e.UrId);

                entity.HasIndex(e => e.UrRid)
                    .HasName("urRid");

                entity.HasIndex(e => e.UrUid)
                    .HasName("urUid");

                entity.Property(e => e.UrId)
                    .HasColumnName("urId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.UrRid)
                    .HasColumnName("urRid")
                    .HasColumnType("int(11)");

                entity.Property(e => e.UrUid)
                    .HasColumnName("urUid")
                    .HasColumnType("int(11)");

                entity.HasOne(d => d.UrR)
                    .WithMany(p => p.UserRole)
                    .HasForeignKey(d => d.UrRid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("UserRole_ibfk_1");

                entity.HasOne(d => d.UrU)
                    .WithMany(p => p.UserRole)
                    .HasForeignKey(d => d.UrUid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("UserRole_ibfk_2");
            });

            _modelBuilder = modelBuilder;
        }
    }
}
