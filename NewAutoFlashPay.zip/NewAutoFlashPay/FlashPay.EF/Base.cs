﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.EF
{
    public class Base
    {
        //.Net Core
        public static readonly string Mydb = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build()["ConnectionStrings:sqlconnection"];
        /*
          请在appsetting.json 增加以下字串 
         
          "ConnectionStrings": {
            "sqlconnection": "server=172.16.39.215;database=FlashPay_old;uid=t_user;password=t_password"
          }
         */
    }
}
