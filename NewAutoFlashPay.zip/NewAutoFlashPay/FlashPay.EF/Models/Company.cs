﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class Company
    {
        public Company()
        {
            SysConfig = new HashSet<SysConfig>();
            SysRole = new HashSet<SysRole>();
            UserInfo = new HashSet<UserInfo>();
        }

        public int CompanyId { get; set; }
        public int CompanyPid { get; set; }
        public string CompanyName { get; set; }
        public sbyte CompanyStatus { get; set; }
        public string CompanyBossName { get; set; }
        public string CompanyTel { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyNameEn { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }
        public int? UpdateUid { get; set; }
        public DateTime? UpdateDate { get; set; }
        public decimal? DepositRate { get; set; }
        public decimal? PayRate { get; set; }
        public decimal? TransportRate { get; set; }

        [JsonIgnore]
        public ICollection<SysConfig> SysConfig { get; set; }
        [JsonIgnore]
        public ICollection<SysRole> SysRole { get; set; }
        [JsonIgnore]
        public ICollection<UserInfo> UserInfo { get; set; }
    }
}
