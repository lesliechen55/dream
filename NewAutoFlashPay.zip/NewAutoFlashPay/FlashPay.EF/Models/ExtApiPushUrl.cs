﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class ExtApiPushUrl
    {
        public int Id { get; set; }
        public int CompanyId { get; set; }
        public sbyte Type { get; set; }
        public sbyte SortNo { get; set; }
        public sbyte Status { get; set; }
        public string Url { get; set; }
        public string Description { get; set; }
        public Company Company { get; set; }
    }
}
