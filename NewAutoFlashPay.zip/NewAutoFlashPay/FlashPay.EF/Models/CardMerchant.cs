﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class CardMerchant
    {
        public int Cmid { get; set; }
        public string Cmname { get; set; }
        public string Cmcode { get; set; }
        public string Cmcredit { get; set; }
        public sbyte DelayRate { get; set; }
        public string Remark { get; set; }
        public int CardCommissionerUid { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
