﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class DepositRecord
    {
        public long OrderNo { get; set; }
        public string DepositNo { get; set; }
        public decimal FeeRatio { get; set; }
        public decimal FeeTotal { get; set; }
        public decimal BeforeBalance { get; set; }
        public decimal AfterBalance { get; set; }
        public int CompanyId { get; set; }
        public string DepositRemark { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime CreateDbdate { get; set; }
        public sbyte NoticeStatus { get; set; }
        public DateTime? NoticeLastTime { get; set; }
        public int NoticeTimes { get; set; }
        public DateTime DepositDate { get; set; }
        public int DepositCardId { get; set; }
        public string CardNumber { get; set; }
        public decimal DepositAmount { get; set; }
        public string ClientBankName { get; set; }
        public string ClientAccountName { get; set; }
        public string ClientCardNumber { get; set; }
        public string BankSerialNo { get; set; }
        public string PostScript { get; set; }
        public int Transtype { get; set; }
        public long? DepositMatchID { get; set; }
    }
}
