﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.EF.Models
{
  public class PaymentInterfaceMany
    {
        public PaymentInterface PaymentInterface { get; set; }
        public List<BankInfo> BankList { get; set; }
        public List<Company> CompanyList { get; set; }
        public List<SysConfig> SysConfigTypeList { get; set; }
    }
}
