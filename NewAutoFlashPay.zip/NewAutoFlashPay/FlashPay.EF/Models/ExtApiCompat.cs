﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class ExtApiCompat
    {
        public int Id { get; set; }
        public sbyte Type { get; set; }
        public int CompanyId { get; set; }
        public string ApiKey { get; set; }
        public string SecretKey { get; set; }
        public sbyte Status { get; set; }
    }
}
