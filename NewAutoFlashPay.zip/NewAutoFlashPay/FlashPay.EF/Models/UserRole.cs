﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class UserRole
    {
        public int UrId { get; set; }
        public int UrUid { get; set; }
        public int UrRid { get; set; }
        public DateTime CreateDate { get; set; }

        public SysRole UrR { get; set; }
        public UserInfo UrU { get; set; }
    }
}
