﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class Authorize
    {
        public int AuthId { get; set; }
        public int AuthRid { get; set; }
        public int AuthPid { get; set; }
        public sbyte AuthType { get; set; }
        public DateTime CreateDate { get; set; }

        public SysRole AuthR { get; set; }
    }
}
