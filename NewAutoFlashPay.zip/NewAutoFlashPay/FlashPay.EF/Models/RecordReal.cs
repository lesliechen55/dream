﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class RecordReal
    {
        public long OrderNo { get; set; }
        public string ClientOrderNo { get; set; }
        public decimal AfterBalance { get; set; }
        public int CompanyId { get; set; }
        public string Remark { get; set; }
        public sbyte RecordType { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime CreateDbdate { get; set; }
        public DateTime OperatingDate { get; set; }
        public int CardBcid { get; set; }
        public decimal Amount { get; set; }
        public string ClientBankName { get; set; }
        public string ClientAccountName { get; set; }
        public string ClientCardNumber { get; set; }
        public string BankSerialNo { get; set; }
        public string VmClientId { get; set; }
        public long? MatchOrderNo { get; set; }
    }
}
