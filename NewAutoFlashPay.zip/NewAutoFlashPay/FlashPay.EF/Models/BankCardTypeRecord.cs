﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class BankCardTypeRecord
    {
        public int Id { get; set; }
        public string CardNumber { get; set; }
        public sbyte BeforeCardType { get; set; }
        public sbyte AfterCardType { get; set; }
        public sbyte RecordType { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDbdate { get; set; }
    }
}
