﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class ReportStatistics
    {
        public int CompanyId { get; set; }
        public int CardBcid { get; set; }
        public sbyte ReportType { get; set; }
        public decimal ReportAmount { get; set; }
        public int ReportQuantity { get; set; }
        public DateTime ReportDate { get; set; }
        public decimal FeeRatio { get; set; }
        public decimal FeeTotal { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
