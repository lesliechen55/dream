﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class UserInfo
    {
        public UserInfo()
        {
            UserRole = new HashSet<UserRole>();
        }

        public int UId { get; set; }
        public int UCompanyId { get; set; }
        public string ULoginName { get; set; }
        public string UPwd { get; set; }
        public DateTime CreateDate { get; set; }
        public string UEmail { get; set; }
        public string UTelephone { get; set; }
        public sbyte UStatus { get; set; }
        public string UDescription { get; set; }
        public string UUiconfig { get; set; }
        public string USecretKey { get; set; }
        public sbyte ULoggedIn { get; set; }
        public sbyte UShowQR { get; set; } //是否已经显示过二维码
        public int UCreateId { get; set; }

        public Company UCompany { get; set; }
        public ICollection<UserRole> UserRole { get; set; }
    }
}
