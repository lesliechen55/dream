﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class Permission
    {
        public int Pid { get; set; }
        public int? PParent { get; set; }
        public string PName { get; set; }
        public string PCode { get; set; }
        public int NodeType { get; set; }
        public int SortNo { get; set; }
        public sbyte Hide { get; set; }
    }
}
