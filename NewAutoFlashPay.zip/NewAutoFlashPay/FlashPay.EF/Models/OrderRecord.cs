﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class OrderRecord
    {
        public OrderRecord()
        {
            OrderRecordDetail = new HashSet<OrderRecordDetail>();
        }

        public long OrderNo { get; set; }
        public int Cmid { get; set; }
        public string DeliveryNo { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal DepositAmount { get; set; }
        public DateTime DepositDate { get; set; }
        public int DepositUid { get; set; }
        public string DepositCardNumber { get; set; }
        public DateTime? ReceiptDate { get; set; }
        public int ReceiptUid { get; set; }
        public DateTime? PayDate { get; set; }
        public decimal PayAmount { get; set; }
        public int PayUid { get; set; }
        public string PayCardNumber { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }

        public ICollection<OrderRecordDetail> OrderRecordDetail { get; set; }
    }
}
