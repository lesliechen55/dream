﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class PaymentInterface
    {
        public int CompanyID { get; set; }
        public sbyte PaymentType { get; set; }
        public string CompanyName { get; set; }
        public string SecretKey { get; set; }
        public decimal PaymentStart { get; set; }
        public decimal PaymentEnd { get; set; }
        public string WithdrawalBank { get; set; }
        public string DepositType { get; set; }
        public int PaymentMax { get; set; }
        public DateTime? LimitCloseDate { get; set; }
        public DateTime? LimitOpenDate { get; set; }
        public sbyte? LimitRepeat { get; set; }
        public sbyte LimitStatus { get; set; }
    }
}
