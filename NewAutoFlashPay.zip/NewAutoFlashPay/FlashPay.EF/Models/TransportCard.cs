﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class TransportCard
    {
        public int Bcid { get; set; }
        public sbyte ApiTransport { get; set; }
        public decimal LimitAmount { get; set; }
        public decimal LimitTransFerAmount { get; set; }
        public string LimitCardType { get; set; }
        public decimal LimitBalance { get; set; }
        public decimal LimitMaxAmount { get; set; }
        public decimal LimitOrderSideBalance { get; set; }
        public string LimitBankCode { get; set; }
    }
}
