﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class OrderRecordDetail
    {
        public int DetailId { get; set; }
        public long OrderNo { get; set; }
        public string BankCode { get; set; }
        public int OrderQuantity { get; set; }
        public decimal UnitPrice { get; set; }
        public int ActualQuantity { get; set; }
        public decimal ActualUnitPrice { get; set; }
        public string Remark { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }

        public OrderRecord OrderNoNavigation { get; set; }
    }
}
