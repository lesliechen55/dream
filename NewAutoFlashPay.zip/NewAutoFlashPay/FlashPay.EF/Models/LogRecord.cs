﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class LogRecord
    {
        public long LogId { get; set; }
        public string Ip { get; set; }
        public sbyte LogLevel { get; set; }
        public int LogType { get; set; }
        public string CreateName { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }
        public string LogRemark { get; set; }
        public int? CompanyId { get; set; }
        public Company UCompany { get; set; }
        public string RequestUrl { get; set; }
        public string RequestData { get; set; }
        public string AffectData { get; set; }
    }
}
