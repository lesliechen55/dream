﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class Menu
    {
        public int Mid { get; set; }
        public int? MParent { get; set; }
        public string MName { get; set; }
        public string MUrl { get; set; }
        public int NodeType { get; set; }
        public int SortNo { get; set; }
        public int MType { get; set; }
        public sbyte Hide { get; set; }
    }
}
