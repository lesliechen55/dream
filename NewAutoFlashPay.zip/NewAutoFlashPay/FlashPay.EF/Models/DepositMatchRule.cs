﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class DepositMatchRule
    {
        public int Id { get; set; }
        public int CompanyId { get; set; }
        public int MatchMinute { get; set; }
        public string MatchBankCode { get; set; }
        public string MatchRule { get; set; }
        public string MatchRemark { get; set; }
        public int CreateId { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
