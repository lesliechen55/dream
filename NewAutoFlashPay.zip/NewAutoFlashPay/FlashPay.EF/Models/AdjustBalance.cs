﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class AdjustBalance
    {
        public long Rid { get; set; }
        public decimal Amount { get; set; }
        public decimal BeforeBalance { get; set; }
        public decimal AfterBalance { get; set; }
        public int? CardBcid { get; set; }
        public string CardNumber { get; set; }
        public int? CreateUid { get; set; }
        public string CreateName { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime CreateDbdate { get; set; }
        public string CreateRemark { get; set; }
        public sbyte AdjustStatus { get; set; }
        public int CompanyId { get; set; }
    }
}
