﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class BankInfo
    {
        public string BankCode { get; set; }
        public string BankName { get; set; }
        public string BankFullName { get; set; }
        public string BankEnglishName { get; set; }
        public int? SortNo { get; set; }
        public string BankUrl { get; set; }
        public string BankRemark { get; set; }
        public string BankTel { get; set; }
        public string BankAddress { get; set; }
    }
}
