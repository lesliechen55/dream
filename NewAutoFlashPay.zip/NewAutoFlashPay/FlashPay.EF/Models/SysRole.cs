﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class SysRole
    {
        public SysRole()
        {
            Authorize = new HashSet<Authorize>();
            UserRole = new HashSet<UserRole>();
        }

        public int RId { get; set; }
        public int RCompanyId { get; set; }
        public string RName { get; set; }
        public DateTime CreateDate { get; set; }
        public int CreateCid { get; set; }
        public int CreateUid { get; set; }
        public sbyte RStatus { get; set; }

        public Company RCompany { get; set; }
        public ICollection<Authorize> Authorize { get; set; }
        public ICollection<UserRole> UserRole { get; set; }
    }
}
