﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class BankCardExtraLimit
    {
        public string CardNumber { get; set; }
        public DateTime? LimitCloseDate { get; set; }
        public DateTime? LimitOpenDate { get; set; }
        public sbyte? LimitRepeat { get; set; }
        public decimal? LimitDepositAmount { get; set; }
        public sbyte? LimitChangetoPay { get; set; }
        public decimal? LimitPayAmount { get; set; }
        public sbyte? LimitChangetoDeposit { get; set; }
        public sbyte LimitStatus { get; set; }
    }
}
