﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class DepositMatchRecord
    {
        public long Id { get; set; }
        public int CompanyId { get; set; }
        public string BankCode { get; set; }
        public long? MatchOrderNo { get; set; }
        public string ClientOrderNo { get; set; }
        public string DepositRemark { get; set; }
        public DateTime CreateDbdate { get; set; }
        public DateTime DepositDate { get; set; }
        public decimal DepositAmount { get; set; }
        public string ClientBankName { get; set; }
        public string ClientAccountName { get; set; }
        public string ClientCardNumber { get; set; }
        public string PostScript { get; set; }
        public int? UpdateId { get; set; }
        public DateTime? UpdateDate { get; set; }
        //public Company Company { get; set; }
    }
}
