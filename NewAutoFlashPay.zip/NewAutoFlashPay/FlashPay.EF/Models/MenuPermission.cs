﻿using System;
using System.Collections.Generic;

namespace FlashPay.EF.Models
{
    public partial class MenuPermission
    {
        public int MpId { get; set; }
        public int MpMid { get; set; }
        public int MpPid { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
