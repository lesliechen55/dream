﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.EF.Models
{
   public class PaymentInterfaceNew
    {
        public int CompanyID { get; set; }
        public sbyte PaymentType { get; set; }
        public string CompanyName { get; set; }
        public string SecretKey { get; set; }
        public string PaymentTypeName { get; set; }
        public string PaymentStart { get; set; }
        public string PaymentEnd { get; set; }
        public string WithdrawalBank { get; set; }
        public string DepositType { get; set; }
        public int PaymentMax { get; set; }
        public sbyte PaymentStatus { get; set; }
        public string LimitCloseDate { get; set; }
        public string LimitOpenDate { get; set; }

        public sbyte? LimitRepeat { get; set; }
        public sbyte LimitStatus { get; set; }
        public Company Company { get; set; }
    }
}
