﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlashPay.EF
{
    public class BaseContext<T> where T : class, new()
    {
        //Base.flashpayContext dbContext = new Base.flashpayContext();
        //BaseModel<T> bmt = new BaseModel<T>();
        //BaseModel bm = new BaseModel();

        ///// <summary>
        ///// 查询
        ///// </summary>
        //public BaseModel<T> Get(Expression<Func<T, bool>> where)
        //{
        //    bmt = new BaseModel<T>();
        //    bmt.Data = dbContext.Set<T>().Where(where).ToList();
        //    return bmt;
        //}

        ///// <summary>
        ///// 查询全部
        ///// </summary>
        //public BaseModel<T> Get()
        //{
        //    bmt = new BaseModel<T>();
        //    bmt.Data = dbContext.Set<T>().ToList();
        //    return bmt;
        //}

        ///// <summary>
        ///// 分页查询
        ///// </summary>
        ///// <typeparam name="TKey">OrderBy 档位型态</typeparam>
        ///// <param name="where"></param>
        ///// <param name="orderBy"></param>
        ///// <param name="pageSize"></param>
        ///// <param name="pageIndex"></param>
        ///// <param name="isDesc"></param>
        ///// <returns></returns>
        //public BaseModel<T> Get<TKey>(Expression<Func<T, bool>> where, Expression<Func<T, TKey>> orderBy, int pageSize, int pageIndex, bool isDesc = true)
        //{
        //    bmt = new BaseModel<T>();
        //    if (isDesc)
        //        bmt.Data = dbContext.Set<T>().Where(where).OrderByDescending(orderBy).Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
        //    else
        //        bmt.Data = dbContext.Set<T>().Where(where).OrderBy(orderBy).Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();

        //    return bmt;
        //}

        ///// <summary>
        ///// 新增
        ///// </summary>
        ///// <param name="entityModel"></param>
        //public BaseModel Add(T entityModel)
        //{
        //    bm = new BaseModel();
        //    dbContext.Entry<T>(entityModel).State = EntityState.Added;
        //    bm.Success = dbContext.SaveChanges() > 0;
        //    return bm;
        //}

        ///// <summary>
        ///// 修改(根據key)
        ///// </summary>
        ///// <param name="entityModel"></param>
        ///// <param name="KeyValues">T.value</param>
        //public BaseModel Update(T entityModel, params object[] KeyValues)
        //{
        //    bm = new BaseModel();
        //    var entry = dbContext.Entry<T>(entityModel);

        //    if (entry.State == EntityState.Detached)
        //    {
        //        var set = dbContext.Set<T>();

        //        T attachedEntity = set.Find(KeyValues);

        //        if (attachedEntity != null)
        //        {
        //            var attachedEntry = dbContext.Entry(attachedEntity);
        //            attachedEntry.CurrentValues.SetValues(entityModel);
        //        }
        //        else
        //        {
        //            entry.State = EntityState.Modified;
        //        }
        //    }
        //    bm.Success = dbContext.SaveChanges() > 0;
        //    return bm;
        //}

        ///// <summary>
        ///// 删除
        ///// </summary>
        ///// <param name="entityModel"></param>
        //public BaseModel Delete(T entityModel)
        //{
        //    bm = new BaseModel();
        //    dbContext.Entry<T>(entityModel).State = EntityState.Deleted;
        //    bm.Success = dbContext.SaveChanges() > 0;
        //    return bm;
        //}
    }
}
